# 安装环境

## 创建 virtualenv
`conda create -n ce python=3.5.3`

## 激活该环境
`source activate ce`

## 安装requirements.txt依赖
`pip install -r requirements.txt`

## 生成requirements.txt文件
`pip freeze > requirements.txt`
该文件输出到 dockerfiles 目录下

## 配置 redis
设置密码，通过redis.conf, 设置 requirepass "mypassword"


# 使用Docker 启动
## 启动服务
cd ComputeEngine/ && sh scripts/start_dockers.sh

## 让 docker 不再需要 sudo
    sudo gpasswd -a $USER docker  #此处 $USER 为用户名
测试：
    docker run hello-world


## Docker file 编写与使用
全局上拆分成 五个服务
    
    1. nginx：已有 
    1. redis:  已有
    1. celery worker： 依赖 python 
    1. gunicorn flask:  依赖 python
    1. celery flower :  依赖 python
    1. ide : 依赖 python

1. 通过 docker compose 或者 --link 选项衔接各个应用，
1. 通过 entrypoint.sh 脚本 搭配 ENTRYPOINT[“entrypoint.sh”] ; CMD “option"  增加环境自适应能力
1. 通过端口映射，来支持对外服务
1. 通过healthcheck 脚本来自动检查服务的运行状态

## Dockerfile 编写要点
1. 缩小 image 的关键在于 base: alpine
1. 将可能变化的层放在最后层，避免过大的缓存修改
1. 将修改可能性差不多的层合并在一条语句，减少层级，避免超出 docker 限制
1. 将启动入口放入 entrypoint.sh 
1. 将服务运行状况检查 放入 healthcheck
1. 每个 docker 容器内最好只有一个服务，避免多个服务的 stdout 复用，造成混乱
1. 加速镜像：

## Docker 删除 none 的 image
1. docker ps -a 检查 container 存在性，避免已经创建容器，造成删除失败
1. docker container rm containerName
1. docker image rmi image_id

## Docker push 创建公开 image 的要点
1. 登录 docker hub 网站
1. 创建 repo: fandyst/python_gcc_celery
1. 查看本地容器：docker ps -a ，找到 image 对应的 container name.
1. docker commit containerName repoUrl_Name:tagName 容器: docker commit inspiring_goldberg fandyst/python_gcc_celery:gcc_gpp_headers
1. docker login 本地服务登录 docker hub
1. docker push repoUrl_Name:tagName到远程 hub: docker push fandyst/python_gcc_celery:gcc_gpp_headers
1. docker inspect repoUrl_Name
1. 到 docker hub 网站，查看和确认该 repo 的 tags已经存在

参考：https://www.cnblogs.com/wherein/p/6862911.html

## Docker 运行：
1. 端口映射参数
1. 文件 mount 参数
1. 环境变量配置参数
1. 不同 container 的 link 参数
1. 不同依赖服务的注册连接
1. 

## Docker Compose 使用
全局上，docker-compose.yml的配置是可以完全替代 docker run 指令带上的其它所有参数的，比如 -p / image / cmd / link ， 甚至还有依赖关系，启动顺序，多个容器的失败自动检测
1. version 代表的是 docker-compose 不同版本
1. services 代表组合服务
1. 后续的各类参数都可以参考下面的链接

参考：
1. https://blog.csdn.net/pushiqiang/article/details/78682323

## Docker Swarm 使用
Manager节点
启动
1. docker swarm init
1. docker stack deploy --compose-file docker-compose-swarm.yml stackdemo 

关闭
1. docker stack rm stackdemo

滚动更新：
可能是由于 docker volume 挂载源码的原因，对源码进行更新后，使用 docker service update 或者 docker stack deploy 做滚动更新都失效

新worker节点：
加入集群
1. docker swarm join --token SWMTKN-1-5k0c3brh4cwtpj98c2wunlnz0074c3icogl0jcr5fdb5oxyyl0-a8hln8d82bz9p2lvu3puzvhw5 192.168.65.3:2377

启动
1. docker stack deploy --compose-file docker-compose-swarm.yml stackdemo 

关闭
1. docker stack rm stackdemo

退出集群
1. docker swarm leave


参考：https://docs.docker.com/engine/swarm/stack-deploy/#deploy-the-stack-to-the-swarm

## Docker Machine 使用


# sphinx 生成开发文档
#### 配置
 1. 运行如下命令，即可生成 conf.py index.rst  Makefile 三个文件：
    
    `sphinx-quickstart`
 2. conf.py 负责全局配置：
    1. 注意一定要启用 `autodoc`
    2. `autodoc` 对应配置在：
    
        `extensions = ['sphinx.ext.autodoc',
        'sphinx.ext.todo',
        'sphinx.ext.viewcode']
        `
    3. 配置 path 以供sphinx 在 `autodoc` 时能够 `import` 对应的 module
 
        `sys.path.insert(0, os.path.abspath('.'))`
 
 3. index.rst 负责首页的布局， 需要声明 `autodoc`的位置，以及对应的 module
    1. 在module的__init__.py文件中声明好 __all__
    2. 在 index.rst 中加入如下配置，注意空格格式
         
            .. automodule:: data_engineer.bark_engine
               :members:
               :undoc-members:
               :show-inheritance:
 4. 设置主题：ReadTheDocs
     1. 安装:
         
            pip install sphinx_rtd_theme
                  
     2. 配置conf.py：
            
            import sphinx_rtd_theme
            html_theme = "sphinx_rtd_theme"
            html_theme_path = [sphinx_rtd_theme.get_html_theme_path()]
            
 
#### 执行
    - sphinx-build -b html .  _build
#### 参考：
    1. 生成配置文件：sphinx-quickstart
    2. 配置source 扫描：https://www.ctolib.com/topics-46641.html
    3. 设置主题： https://segmentfault.com/a/1190000007233355


## Jenkins自动化部署
### 安装 jenkins
1. yum install sudo yum install java-1.8.0-openjdk-devel   # 安装 jdk
1. sudo vim /etc/profile

    JAVA_HOME=/usr/lib/jvm/jre-1.8.0-openjdk
    JRE_HOME=$JAVA_HOME
    CLASS_PATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar:$JRE_HOME/lib
    PATH=$PATH:$JAVA_HOME/bin:$JRE_HOME/bin
    export JAVA_HOME JRE_HOME CLASS_PATH PATH

### 安装 jenkins
1. sudo wget -O /etc/yum.repos.d/jenkins.repo http://pkg.jenkins-ci.org/redhat-stable/jenkins.repo
1. sudo rpm --import https://jenkins-ci.org/redhat/jenkins-ci.org.key
1. yum install jenkins

### 将 jenkins 加入 docker 用户组
因为 jenkins 安装后自动是以 jenkins 用户运行的，没有加入 docker 用户组，无法在不加 sudo 的情况下启动 docker
1. sudo gpasswd -a jenkins docker

### 启动 jenkins
1. sudo service jenkins start/stop/restart
1. 打开浏览器， 手动配置

### 创建 jenkins 任务 《自由风格的软件项目》
1. 创建名为 auto_restart_dockers 任务

### 配置 gitlab 与 jenkins 的 trigger
1. 进入 jenkins 的 设置 页面，找到当前登录用户的 API Token 隐藏项中的 用户名：fandyst 和 token: xxx
1. 进入 jenkins 的 auto_restart_dockers 任务的配置页，人工设置【触发远程构建】的 token 为 whatthefuckisthis
1. 打开 gitlab 的 webhook 配置项目
1. 将地址配置为： http://fandyst:xxx@172.28.3.80:8080/job/auto_restart_dockers/build?token=whatthefuckisthis

### 自动构建脚本
1. 打开 jenkins 的auto_restart_dockers 任务配置页， 编写 shell 脚本，让其受到触发后，自动构建

参考
1. https://humanwhocodes.com/blog/2015/10/triggering-jenkins-builds-by-url/