# 全局设计思路说明
由于 

NOTE：
1. 注意 DataBean 和 ContextBean 只能是 copy 之后，修改，通过 action()返回值传递给下一个.
2. 

## 需求说明
 - 人行中需要统计overdue 2次、3次、4次的结果: bct_loan_overdue_record_last_months
 - 同盾数据，部分需要从 flatten 的数据list中。捞取出，符合条件的字符串，再经过 mapper ( json 转换成 dict), 然后再取出数据.
 - cached property 问题
 - 偏函数 (应对多参数，但却只能在对应级别才能确认参数)
 - 返回结果的 keyname ? , 多个 name ? 一个 task 一个 name ？

## 概要设计
上游 producer 提供的数据，会被 consumer 转换(隔离上游的 bean 的变化带来的变化)， 提供给各个 celery task 运行必要的信息。即：
celery consumer 处的各个DAG 运行，需要构建一个合适的bark engine task任务的执行上下文。
bark engine task 的context 数据结构统一化：一个context

 - 拆分成三个级别：
  1. dag类：负责全局控制、包含 Pipeline / Group / Chord 等计算方式（并保持接口统一） + aux 辅助类：如cached 缓存的支持和管理
  1. Pipeline/Group执行类：包含 多个task类
  1. aux辅助类：如cache模块，支持单个task / pipeline / dag 的缓存绑定, 具名缓存。
  1. task类：支持缓存标记，缓存 keyname , 以及操作的封装： 具体操作如：filter类（多个、分层） /  mapper类（多个、分层） / reducer类（多个、分层） 
  1. filter、mapper、reducer类：负责筛选、转换、统计； 并且支持任意多个的组合，也可单独存在
     - 其中 filter 比较特殊： 需要考虑 and 和 or 操作

 - 上层：
  1. DagContainers: 包含多个 Dag，并负责：DAG 与 DAG 的顺序执行，以及他们之间的依赖 和 缓存管理
  1. ResultDict : 保存各个 Dag 的衍生结果，k-v 键值对
  1. DagContainer 的宿主是 Handler 类， 因此能取得各种各样的 source data 和 dataname / Dag 作为复杂衍生的支持框架类
  
 - 参数：
  1. 关键参数：各个 task 需要的参数，才是核心参数，主要是计算需要的数据参数，而 filter之类的需要的只有以下： 源数据或源数据名（因为上游可能提供多个源数据/考虑 task 与 handler类的关系），key_name ，and/or 组合。
  1. 

## filter、mapper、reducer类的设计（负责筛选、转换、统计）
 - 父类一致，接口一致。（因为要支持任意多个的组合，也可单独存在）
 - filter: 负责筛选
 - mapper：负责转换
 - reducer： 负责计算、统计

#### filter 、mapper、reducer类的接口设计
 - 接受参数：global_bean, data_bean, extra_bean, **kwargs
 - 输出结果：task_id, task_name, (k-value / list)

 注：无需关心具体的返回结果是否与其它所有的适配， 只需关心在实际应用中的那个后续的 task 是否能接受即可。

一个 task 可以只有以上中的任意一个。 

## task 对外接口设计
 - 接受参数：global_bean, data_bean, extra_bean, **kwargs 
 - 输出结果：task_id, task_name, (k-value / list)
 
 注：无需关心具体的返回结果是否与其它所有的适配， 只需关心在实际应用中的那个后续的 task 是否能接受即可。

## dag 的对外接口设计
 - 
 - 

## task_relations的设计： 负责协调 dag 的 task 关系计算先后


## 详细设计


## 例外说明
 - 部分task结果需要复用，跨层级复用的 cache 策略，参考【4】


灵感:
1. sql 语言
2. spark dag 思路
3. luigi: https://github.com/spotify/luigi
4. dag模式的cached property: http://luiti.github.io/chinese/Processing-data-in-a-DAG-way.html
