"""
0. 持有资源：
    1. DataBean: 多种可选数据类型: BaseDataBean, SingleDataBean, MultiDataBean.
    2.TaskContext中：包含 DBConnectionPool / Data / GlobalInfo / ResultInfo / RequireInfo
1. 维护 executor的执行
2. 维护 cache
3. 触发执行 executor
4. 获得最终的executor 的运行结果: executor.get_result()

"""
from config.json_setting import node_dag_status, node_dag_status_success
from bark_engine.controller.controller import Controller
from bark_engine.task.mappers.castmapper import CastMapper
from bark_engine.task.reducers.stats import Count, Sum
from bark_engine.auxi.cache import CacheManager
from bark_engine.auxi.context_bean import ContextBean
from beans.core.datainfo_bean import BaseDataBean, SingleDataBean
from bark_engine.controller.controller import Controller
from bark_engine.controller.union import Union
from bark_engine.controller.pipeline import Pipeline
from bark_engine.controller.ifelse import IfElse, CaseWhen
from bark_engine.controller.foreach import Foreach
from bark_engine.task.filters.selectfilter import Select, SelectArray, SelectPrefix, SelectRegex, \
    SelectArrayPair
from bark_engine.task.broker.requiredata import RequireCache, RequireData, RequireDB
from bark_engine.task.mappers.jsonmapper import JsonMapper, FlattenMapper
from bark_engine.controller.judge import JudgeValue
from bark_engine.task.base.const_value import ConstValue
from bark_engine.controller.define import Define
from bark_engine.task.mappers.valueMapper import ValueMapper


class Dag(object):
    def __init__(self, data_bean=None, context_bean=None, controller=None, **kwargs):
        """

        :param data_bean:
        :param context_bean:
        :param controller:
        :param kwargs:
        :type data_bean: BaseDataBean
        :type context_bean: ContextBean
        :type controller: Controller
        :type kwargs: dict
        """
        self.__data_bean = data_bean
        self.__context_bean = context_bean
        self.__controller = controller
        self.__result = None
        self.__debug_info = None
        self.__kwargs = kwargs

    def fill(self, data_bean, context_bean, **kwargs):
        """
        根据需求，自己生成
        :param data_bean:
        :type data_bean:
        :param context_bean:
        :type context_bean: ContextBean
        :param kwargs:
        :return:
        """
        self.__data_bean = data_bean
        self.__context_bean = context_bean
        self.__kwargs.update(kwargs)

    def reset_cache(self):
        cache = CacheManager()
        self.__context_bean.set_cache_manager(cache)

    @property
    def controller(self):
        return self.__controller

    @controller.setter
    def controller(self, value):
        """
        支持两种模式，一种是 list,
        另外一种是 controller
        :param value:
        :return:
        """
        if isinstance(value, tuple):
            self.__controller = Union(value)
        elif isinstance(value, Controller):
            self.__controller = value
        else:
            raise TypeError()

    def action(self):
        self.__controller.fill_context(data=self.__data_bean, context_bean=self.__context_bean, **self.__kwargs)
        result, context, kwargs = self.__controller.action()

        # check if dag_fails in any task.

        dag_status = result.get_data_value().get(node_dag_status)
        if dag_status is None:
            result.get_data_value().update({node_dag_status: node_dag_status_success})

        self.__result = result
        self.__debug_info = context.get_debug_info()
        return result, context, kwargs

    def get_result(self):
        return self.__result.get_data_value()

    def get_debug_info(self):
        return self.__debug_info


if __name__ == "__main__":

    from json import loads
    from beans.globalinfo.globalinfo_bean import GlobalBean
    from beans.globalinfo.bizinfo_bean import BizInfoBean
    from beans.globalinfo.appinfo_bean import AppInfoBean
    import json
    # json_dict = loads(td_str)

    file = './test_data/all_in_one_demo_1.json'
    with open(file, encoding='utf-8') as f:
        content = f.readlines()
        td_str = ''.join(content)
        json_dict = json.loads(td_str, encoding='utf-8')
        json_dict = json_dict['data']['td']

    dataname = 'td'
    datarole = 'sqr'
    # 1. data_tasks bean
    databean = SingleDataBean(data_name=dataname, data_role=datarole, data=json_dict)
    # 2. context_bean
    bizbean = BizInfoBean(biz_type='car', biz_prod='shc')
    appbean = AppInfoBean(appcode='appcodeID', idtype=1, idno='362424188809122214', mobile='13177665544')
    ctx_bean = ContextBean(cachemgr=CacheManager(), globalbean=GlobalBean(bizinfo=bizbean, appinfo=appbean), debug=True)

    # 3. Dag
    dag = Dag()
    dag.fill(data_bean=databean, context_bean=ctx_bean)

    # 4. Design controller
    from data_engineer.data_controllers.td_controller import TongDunCtl
    dag.controller = TongDunCtl().controller
    import time
    start = time.time()
    dag.action()
    end = time.time()
    c = end - start

    res = dag.get_result()
    print(res)
    print(c)

