
# bark engine 第2里程碑

 - 异常处理，防止雪崩（确保单个变量的衍生出现问题，不雪崩，造成整体失效）
    - 每个变量的计算出现异常时，不会影响pipeline 的下一级
    - 重点关注：Mapper 类和 Reduce 类操作
    
 - 性能问题
    - 私有成员造成__data成员的数据记录多份的问题
    - 多级继承造成的多成员数据问题
    - log 造成的性能问题
    - 因cps模型，较多时间消耗在网络 IO, cpu 不能充分利用

 - 语法格式的调整：
    - 可否兼容 Sql, 如 avg(cast((select(x), int)))

 - 功能增强：
    - 支持 原始数据与 task 结果的 比较， 以增强 judgevalue。
    - group by 操作的改善设计（支持原始的 json list 结构） ？
    - 增加 Sort
    - 增加 order by
    - 增加 limit 

 - 批量Reduce
    - 时间序列自动生成 （参考47个时间函数）
    - RFM 自动生成
    - Recent 的可以指定阈值

 - 多种数据类型支持
    - DataBean 支持原始的 json 格式（未展平的格式）,方便数组类的 group by 操作
