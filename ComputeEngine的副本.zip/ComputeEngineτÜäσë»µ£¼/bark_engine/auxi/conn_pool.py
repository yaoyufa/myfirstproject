import json
import datetime
import decimal

from sqlalchemy import create_engine, exc
from sqlalchemy.pool import QueuePool

from bark_engine.config import conn_url


class DBPoolManager:
    """
    1. 我们需确保单例，确保连接不会过多，造成服务器不必要的压力.
    """
    __instance = None

    def __new__(cls):
        if DBPoolManager.__instance is None:
            DBPoolManager.__instance = object.__new__(cls)

        return DBPoolManager.__instance

    def __init__(self):
        self.pools = {}
        for name, url in conn_url.urls.items():
            self.pools[name] = ConnPoolOpti(url)


class ConnPoolOpti:
    """

    1. 我们需确保单例，确保连接不会过多，造成服务器不必要的压力.
    2. 乐观连接，意味着系统自动在每次sql 发送前，不会先测试连接可用性，我们需在异常发生后做特殊处理.
    参考：http://docs.sqlalchemy.org/en/latest/core/pooling.html
    """
    __instance = None

    # def __new__(cls, url):
    #     if ConnPoolOpti.__instance is None:
    #         ConnPoolOpti.__instance = object.__new__(cls)
    #
    #     return ConnPoolOpti.__instance

    def __init__(self, url):
        self.url = url
        self.engine = create_engine(self.url, pool_size=10, max_overflow=5, poolclass=QueuePool)

    def execute(self, sql):
        try:
            # suppose the database has been restarted.
            conn = self.engine.connect()

            # actual doing .
            resultProxy = conn.execute(sql)

            obj = [dict(r) for r in resultProxy]

            # it's actually return the connection to pool.
            conn.close()

            return json.loads(json.dumps(obj, default=alchemy_encoder), encoding='utf-8')

        except Exception as e:
            # an exception is raised, Connection is invalidated.
            # if e.connection_invalidated:
            print("Connection was broken!")
            # raise ConnectionError("connection error.")
            return None

    def close(self):
        pass


def convert2json(obj, schema):
    if isinstance(obj, list):
        # get fields
        result =[]
        for row in obj:
            # 注意 dates 和 decimal
            item = {schema[index]:row_field for index, row_field in enumerate(row)}
            result.append(item)
        return result


def alchemy_encoder(obj):
    """JSON encoder function for SQLAlchemy special classes."""
    if isinstance(obj, datetime.date):
        # return obj.strftime("%Y-%m-%d %H:%M:%S")
        return obj.isoformat()
    elif isinstance(obj, decimal.Decimal):
        return float(obj)



if __name__ == "__main__":
    pool = ConnPoolOpti("mysql+pymysql://root:1314521@127.0.0.1:3306/test?charset=utf8")
    x = pool.execute("select * from test where id = 2")
    #print(x)

    # 测试：强行关闭pool中的连接后，是否依然能自动重连
    pool.engine.dispose()
    x = pool.execute("select * from test where id = 1")
    #print(x)

    pool = ConnPoolOpti("mysql+pymysql://root:1314521@127.0.0.1:3306/test?charset=utf8")
    x = pool.execute("select * from test")
    print(x)

    #exit()

    import threading

    class myThread(threading.Thread):
        def __init__(self, func, sql):
            threading.Thread.__init__(self)
            self.func = func
            self.sql = sql

        def run(self):
            print("开启线程：" + self.name)
            self.func(self.sql)
            print("退出线程：" + self.name)

    # 创建多个线程
    try:
        for i in range(105):
            thread = myThread(pool.execute, "select * from test ")
            thread.start()
    except:
        print("Error: unable to start thread")
