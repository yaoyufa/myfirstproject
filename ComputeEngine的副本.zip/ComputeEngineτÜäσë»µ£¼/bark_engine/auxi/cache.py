"""

提供给dag级别 或者 dag container 级别的缓存支持
1. 各自级别的缓存各自管理，仅对该层级可见。
意味着：dag containner 分别各自有一个 cache 对象
2. key 冲突报错
"""
from datetime import datetime
from beans.core.datainfo_bean import BaseDataBean
from bark_engine.config import ins_conf


class CacheNameDuplicatedException(Exception):
    pass


class CacheManager(object):

    def __init__(self):
        self.__cache = {}

    def get_value(self, cache_name):
        return self.__cache.get(cache_name, BaseDataBean(data=None))

    def set_value(self, key, value):
        """
        Raise Exception if cache exists.

        :param key:
        :param value:
        :return:
        """
        if self.__cache.get(key) is not None:
            raise CacheNameDuplicatedException()
        else:
            self.__cache.setdefault(key, value)

    def get_all_keys(self):
        return self.__cache.keys()

    def get_size(self):
        return len(self.__cache)


class GlobalTimerCache(object):
    """
    单例，以确保全局共享
    """
    __instance = None

    def __new__(cls):
        if GlobalTimerCache.__instance is None:
            GlobalTimerCache.__instance = object.__new__(cls)

        return GlobalTimerCache.__instance

    class CacheObj(object):
        def __init__(self, value, lifelong):
            """

            :param value:
            :param lifelong: seconds
            """
            self.value = value
            self.expireTime = lifelong + datetime.now().timestamp()

        def get_value(self):
            if self.expireTime <= datetime.now().timestamp():
                return self.value
            else:
                return None

    def __init__(self):
        self.cache = {}

    def get_value(self, key):
        obj = self.cache.get(key)
        if obj is None:
            return None
        else:
            res = obj.get_value()
            # 如果超时, 删除该对象
            if res is None:
                self.cache.pop(key)
            return res

    def set_value(self, key, value, lifelong):
        obj = self.CacheObj(value, lifelong)
        self.cache.__setitem__(key, obj)


class GlobalPersistCache(object):
    """

    单例，以确保全局共享
    """
    __instance = None

    def __new__(cls):
        if GlobalPersistCache.__instance is None:
            GlobalPersistCache.__instance = object.__new__(cls)

        return GlobalPersistCache.__instance

    def __init__(self):
        if self.__dict__.get('cache') is None:
            self.load_config()

    def load_config(self):
        self.cache = ins_conf.conf_dict

    def get_value(self, key):
        return self.cache.get(key)


if __name__ == "__main__":
    pc1 = GlobalPersistCache()
    pc2 = GlobalPersistCache()
    print(pc1 == pc2)
    print(id(pc1.cache) == id(pc2.cache))

    tc1 = GlobalTimerCache()
    tc2 = GlobalTimerCache()
    print(tc1 == tc2)
    print(tc1.cache is tc2.cache)
