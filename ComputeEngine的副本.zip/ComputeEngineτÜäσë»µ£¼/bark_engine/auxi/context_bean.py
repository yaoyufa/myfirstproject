"""
上游 producer 提供的数据，会被 consumer 转换(隔离上游的 bean 的变化带来的变化)， 提供给各个 celery task 运行必要的信息。即：
celery consumer 处的各个DAG 运行，需要构建一个合适的bark engine task任务的执行上下文。
bark engine task 的context 数据结构统一化：一个context

本context bean中需要包含：
1. dataManager
2. datalistManager
3. globaldataManager
4. cacheManager
5. resultinfoManager
6. extinfoManager
7. 提供可扩展接口

或者

1. 提供给 dag 或者 dag container 以数据
2. 提供 get_data(name) 接口 或者 {name:data_tasks} 字典形式存储多个数据
"""
from .cache import CacheManager
from beans.globalinfo.globalinfo_bean import GlobalBean
from beans.core.requirement_bean import RequirementBean
import collections


class ContextBean(object):

    def __init__(self, cachemgr=None, globalbean=None, requirementbean=None, dbpool=None, **kwargs):
        """
        新增具名参数，全部通过 kwargs dict 中获取， 避免接口受到影响
        :param cachemgr:
        :param globalbean:
        :param requirementbean:
        :param dbpool:
        :param kwargs:

        :type cachemgr: CacheManager
        :type globalbean: GlobalBean
        :type requirementbean: RequirementBean
        :type dbpool:
        :type kwargs: timercache , persistcache
        """
        self.__cache_mgr = cachemgr
        self.__globalinfo = globalbean
        self.__requirement = requirementbean
        self.__dbpool = dbpool
        self.__debug_info = collections.OrderedDict()
        self.__kwargs = kwargs
        self.__log_index = 0

    def get_cache_manager(self):
        return self.__cache_mgr

    def set_cache_manager(self, cache_mgr):
        self.__cache_mgr = cache_mgr

    def set_db_pool(self, pool):
        self.__dbpool = pool

    def get_db_pool(self):
        return self.__dbpool

    def get_global_bean(self):
        return self.__globalinfo

    def set_global_bean(self, value):
        self.__globalinfo = value

    def set_requirement(self, value):
        self.__requirement = value

    def get_reqirement(self):
        return self.__requirement

    def get_appcode(self):
        return self.get_global_bean().get_appinfo().appcode

    def get_idno(self):
        return self.get_global_bean().get_appinfo().idno

    def get_biz_type(self):
        return self.get_global_bean().get_bizinfo().biz_type

    def is_debug_mode(self):
        return self.__kwargs.get('debug')

    def set_debug_info(self, debug_dict):
        key = [i for i in debug_dict.keys()][0]
        if key in self.__debug_info.keys():
            self.__log_index += 1
            new_key = key+'_'+str(self.__log_index)
            self.__debug_info.update({new_key: debug_dict[key]})
        else:
            self.__debug_info.update(debug_dict)

    def get_debug_info(self):
        return self.__debug_info

    def get_timer_cache(self):
        return self.__kwargs.get('timercache')

    def get_persist_cache(self):
        return self.__kwargs.get('persistcache')
