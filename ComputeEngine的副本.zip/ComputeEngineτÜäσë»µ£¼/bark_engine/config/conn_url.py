DB_name_bgrk = "BGRK"
DB_name_app = "APP"

urls={
    DB_name_bgrk: "mysql+pymysql://root:1314521@127.0.0.1:3306/test?charset=utf8",
    DB_name_app: "mysql+pymysql://root:1314521@127.0.0.1:3306/test?charset=utf8"
}
