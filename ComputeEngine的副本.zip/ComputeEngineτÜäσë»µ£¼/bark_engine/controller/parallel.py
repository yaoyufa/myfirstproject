"""
支持分组并发执行task的一个执行器, 但是不会合并结果成一个 flattened dict， 而是一个分组的

"""

from .controller import Controller


class Parallel(Controller):

    def custom_logic(self):
        """
        Union exe mode.

        different Controller has diff running mode.

        :return:
        """

        merged_res = {}
        return merged_res, {}
