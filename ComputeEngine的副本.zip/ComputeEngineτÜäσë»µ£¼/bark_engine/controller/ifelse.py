"""
属于 executor 还是属于 task 呢？
    1. 属于 executor， 为了支持顶级的 ifelse(task, taskTrue, taskFalse)操作，该操作接受的都是 task， 因此应该与 pipeline( task, task) 平级
    2. 属于 task， 因为 是一个操作， 会返回结果，等同于 filter 操作。

"""
from ..task.base.base_task import BarkBaseTask
from .controller import Controller


class IfElse(Controller):

    def __init__(self, task_cond, task_true, task_false, as_cache_name=None):
        super(IfElse, self).__init__(as_cache_name=as_cache_name)
        self.task_cond = task_cond
        self.task_true = task_true
        self.task_false = task_false

    def custom_logic(self):
        if isinstance(self.task_cond, BarkBaseTask):
            self.task_cond.fill_context(data=self.data_bean, context_bean=self.task_context_bean, **self.kwargs)
            self.task_cond.action()
            cond = self.task_cond.get_result().get_data_value()
        elif isinstance(self.task_cond, bool):
            cond = self.task_cond
        else:
            raise TypeError("task_cond is not in a proper type.")

        if cond:
            self.task_true.fill_context(data=self.data_bean, context_bean=self.task_context_bean, **self.kwargs)
            self.task_true.action()

            return self.task_true.get_result(), {}
        else:
            self.task_false.fill_context(data=self.data_bean, context_bean=self.task_context_bean, **self.kwargs)
            self.task_false.action()

            return self.task_false.get_result(), {}


class CaseWhen(IfElse):
    pass
