"""
两个 task 结果的条件判定：
1. 集合
2. 数值
"""

from beans.core.datainfo_bean import BaseDataBean, SingleDataBean
from .controller import Controller


class JudgeValue(Controller):
    def __init__(self, taskA=None, taskB=None, judge_func=None, as_cache_name=None):
        self.taskA = taskA
        self.taskB = taskB
        self.judge_func = judge_func
        super(JudgeValue, self).__init__(as_cache_name=as_cache_name)

    def custom_logic(self):
        # support:
        # 1. baseDatabean's value
        # 2. singledatabean's dict colleciton
        x = None
        y = None

        # 1. run task A
        self.taskA.fill_context(data=self.data_bean, context_bean=self.task_context_bean, **self.kwargs)
        result, task_context, kwargs = self.taskA.action()

        if result.get_data_type() == BaseDataBean.DATA_TYPE:
            x = result.get_data_value()
        elif result.get_data_type() == SingleDataBean.DATA_TYPE:
            res = result.get_data_value()
            if isinstance(res, dict) and len(res) == 1:
                k, v = res.popitem()
                x = v
                # if v is bool:
                #     x = v
                # else:
                #     raise TypeError("value type in databean is not expected.")
        else:
            raise TypeError("type of data bean is not supported yet.")

        # 2. run task B
        self.taskB.fill_context(data=self.data_bean, context_bean=self.task_context_bean, **self.kwargs)
        result, task_context, kwargs = self.taskB.action()

        if result.get_data_type() == BaseDataBean.DATA_TYPE:
            y = result.get_data_value()
        elif result.get_data_type() == SingleDataBean.DATA_TYPE:
            res = result.get_data_value()
            if isinstance(res, dict) and len(res) == 1:
                k, v = res.popitem()
                y = v
                # if v is bool:
                #     y = v
                # else:
                #     raise TypeError("value type in databean is not expected.")
        else:
            raise TypeError("type of data bean is not supported yet.")

        # encapsule result as databean.
        and_result = self.judge_func(x, y)
        data_bean_result = BaseDataBean(and_result)
        return data_bean_result, {}


