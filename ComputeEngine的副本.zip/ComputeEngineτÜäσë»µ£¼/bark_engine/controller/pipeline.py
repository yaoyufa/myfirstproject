from .controller import Controller


class Pipeline(Controller):
    pass

