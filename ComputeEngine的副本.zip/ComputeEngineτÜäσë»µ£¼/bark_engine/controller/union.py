"""
union filters' result or  data_tasks from cache


"""
from beans.core.datainfo_bean import DataBeanType, SingleDataBean
from .controller import Controller


class Union(Controller):

    def custom_logic(self):
        """
        Union exe mode.

        different Controller has diff running mode.

        :return:
        """

        merged_res = {}

        for task in self.task_list:
            # 本模式中，data_tasks 是共用同一个， 初次是从 datalist 中通过 RequireData 类获取的
            task.fill_context(data=self.data_bean, context_bean=self.task_context_bean, **self.kwargs)
            task.action()

            # merge result.
            merged_res.update(task.get_result().get_data_value())
        if self.data_bean.get_data_type() == DataBeanType.Bean or self.data_bean.get_data_type() == DataBeanType.Atom:
            result_bean = self.data_bean.copy_reset_data(merged_res)
            return result_bean, {}
        elif self.data_bean.get_data_type() == DataBeanType.MultiBean:
            return SingleDataBean(data_name=None, data_role=None, data=merged_res, ext_info=None), {}
        else:
            raise Exception("data type not support.")
