"""
ForEach 操作，支持将某个集合内的数据做逐一处理

如：
ForEach(group_regex, Executor)

"""
import re
from .controller import Controller


class Foreach(Controller):
    """
    用法：
    ForEach(group_regex, Executor)
    """
    def __init__(self, task_controller, as_name=None, as_cache_name=None):
        """

        :param group_regex: xxx[\d+]_yyy[\d+]_zzz[\d+]_
        :param task_controller:
        :param as_name:
        :param as_cache_name:
        """
        # self.group_regex = group_regex
        self.task_controller = task_controller
        self.as_name = as_name
        super(Foreach, self).__init__(as_cache_name=as_cache_name)

    def custom_logic(self):
        """
        Foreach running mode.

        将上游的数据根据 row_pattern 过滤，筛选出特定的 数组成员. (仅支持数组类的 pattern, 如：xxx[(\d+)]_yyy[(\d+)]_zzz[(\d+)]_(*) )
        将这些数组成员 封装成一个 Bean, 然后塞入 CaseWhen.

        row_pattern  的思路， 从 regex 中提取数组数字：[\d+] ， 如果包含多层级的 数组，那么取出其中的序号作为分组依据。
        :return:
        """
        # 将分组数据，逐组传入到 task_controller.
        group_kv = self.data_bean.get_data_value()
        merged_res = {}
        for i in group_kv.keys():
            group_dict = group_kv.get(i)
            # databean embeded
            grouped_data_bean = self.data_bean.copy_reset_data(group_dict)
            self.task_controller.fill_context(data=grouped_data_bean, context_bean=self.task_context_bean, **self.kwargs)
            res, context, kwargs = self.task_controller.action()
            # merge result.
            merged_res.update(res.get_data_value())

        res_bean = self.data_bean.copy_reset_data(merged_res)
        return res_bean, {}
