
"""
本 Class 只是为了执行该算子，算子或 Controller 的结果并不传递和保存，
仅仅是为了将跑出的结果保存到 cache

"""
from beans.core.datainfo_bean import SingleDataBean
from .controller import Controller


class Define(Controller):

    def custom_logic(self):
        """
        Union exe mode.

        different Controller has diff running mode.

        :return:
        """

        for task in self.task_list:
            # 本模式中，data_tasks 是共用同一个， 初次是从 datalist 中通过 RequireData 类获取的
            task.fill_context(data=self.data_bean, context_bean=self.task_context_bean, **self.kwargs)
            task.action()

        # return a null dict.
        res = SingleDataBean(data_name=None, data_role=None, data={}, ext_info=None)

        return res, {}
