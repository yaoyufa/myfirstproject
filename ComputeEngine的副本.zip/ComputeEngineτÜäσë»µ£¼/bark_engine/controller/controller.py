"""
1. 是一个提供task 执行的容器
2. 可能包含多个task， task 的执行可能还包含关联关系
3. 按照excutor 的预定的逻辑，启动 task 进行计算。（如 pipeline ， 如并发的 group）
4. 提供 task 之间的cache复用
    4.1 task 需持有 cache 对象引用
    4.2 task 需注明 结果被cached keyname
5. Pipline / Group 需要能接受 task 类型 和 executor 类型两种 (方便嵌套操作)
    5.1 如：Pipeline(task, task2）  Group(Task, Task), Union(task, task), ifelse(task, task, task), Pipeline([Group, Group]),  Group([pipline1, pipeline2, pipeline3])
    5.2 因此，Pipeline 需要有 与 task 一致的操作接口

"""
from ..task.base.base_task import BarkBaseTask


class Controller(BarkBaseTask):

    def __init__(self, *task_list, as_cache_name=None):
        super(Controller, self).__init__(as_cache_name=as_cache_name)
        self.task_list = task_list

    def custom_logic(self):
        """
        default: Pipeline mode.

        different Controller has diff run mode.

        :return:
        """
        res = self.data_bean
        last_result = None
        for task in self.task_list:
            # data_tasks 是上一次的结果， 初次是从 datalist 中通过 RequireData 类获取的
            task.fill_context(data=res, context_bean=self.task_context_bean, **self.kwargs)
            res, self.task_context_bean, self.kwargs = task.action()

            # update result
            res = task.get_result()
            last_result = res

        return last_result, {}
