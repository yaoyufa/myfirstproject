# TODO: CaseWhen 可以被 ForEach 替代， 故本类设计可以废弃了， 或者包含 Foreach( group_regex, task)。
"""
针对一个对象的多个属性的操作，类似 sql 中的一条记录的多个字段，需要在某种情况下做转换。
a[0]_name
a[0]_sex
a[0]_age

a[1]_name
a[1]_sex
a[1]_age

思路1：
eg: casewhen(to_row='a[]', when=lambda row, prefix: lambda_logic, then= , else= lambda row, logic 'age', as_name=)
此处的抽象需要重构，需支持某类 task 的嵌入， 以支持 and or 或 if else 等操作

思路2：
或者： casewhen(row_filter_task, when=each_row_task, then=result_task, else=const_task_or_case_when, as_name)
其中：
    1. row_filter_task:
    [ -- 可以提取出一个： IfElse() # CaseWhen 的思路一致
    2. when
    3. then:
    嵌套模式
    ]
    4. else: ConstTask(value, key=, cache_name=)
"""
