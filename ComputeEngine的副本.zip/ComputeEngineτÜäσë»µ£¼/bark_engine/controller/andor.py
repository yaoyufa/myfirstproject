"""
Controller流程：
    1. And
    2. Or

"""
from beans.core.datainfo_bean import BaseDataBean, SingleDataBean
from .controller import Controller


class And(Controller):

    def custom_logic(self):
        bool_list = []
        for task in self.task_list:
            task.fill_context(data=self.data_bean, context_bean=self.task_context_bean, **self.kwargs)
            result, task_context, kwargs = task.action()
            if result.get_data_type() == BaseDataBean.DATA_TYPE:
                bool_list.append(result.get_data_value())
            elif result.get_data_type() == SingleDataBean.DATA_TYPE:
                res = result.get_data_value()
                if isinstance(res, dict) and len(res) == 1:
                    k, v = res.popitem()
                    if v is bool:
                        bool_list.append(v)
                    else:
                        raise TypeError("value type in databean is not expected.")
            else:
                raise TypeError("type of data bean is not supported yet.")

        # encapsule result as databean.
        and_result = all(bool_list)
        data_bean_result = BaseDataBean(and_result)
        return data_bean_result, {}


class Or(Controller):

    def custom_logic(self):
        bool_list = []
        for task in self.task_list:
            task.fill_context(data=self.data_bean, context_bean=self.task_context_bean, **self.kwargs)
            result, task_context, kwargs = task.action()
            if result.get_data_type() == BaseDataBean.DATA_TYPE:
                bool_list.append(result.get_data_value())
            elif result.get_data_type() == SingleDataBean.DATA_TYPE:
                res = result.get_data_value()
                if isinstance(res, dict) and len(res) == 1:
                    k, v = res.popitem()
                    if v is bool:
                        bool_list.append(v)
                    else:
                        raise TypeError("value type in databean is not expected.")
            else:
                raise TypeError("type of data bean is not supported yet.")

        # encapsule result as databean.
        and_result = any(bool_list)
        data_bean_result = BaseDataBean(and_result)
        return data_bean_result, {}

