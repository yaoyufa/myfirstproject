## 桥接器、黏连器
专门用于获取数据

 - 通常位于 executor 的起始位置，负责数据的初始化，
 - 
 - 后续的 DBConnector之类的数据可以封装成一个 broker，
 - 
 