"""
用于获取数据：
1. 从 cache 中
2. 从 datalistBean
3. 从上游的 result 自动获取（不用考虑），由task 自动来确定
"""
from ..base.base_task import BarkBaseTask
from beans.core.datainfo_bean import DataBeanType, SingleDataBean, BaseDataBean, MultiDataBean


class RequireData(BarkBaseTask):

    def __init__(self, data_name=None, role=None, extra_info=None, as_cache_name=None):

        self.key_of_data_bean = SingleDataBean(data_name=data_name, data_role=role, data={}, ext_info=extra_info).prefix
        super(RequireData, self).__init__(as_cache_name=as_cache_name)

    def custom_logic(self):
        """
        前缀不用考虑，因为当前是 数据源的级别
        1. 先从 cache 中查找响应的 dataname，并以 cache 中为准
        2. 如果没找到再从 data_tasks 中查找对应的 dataname

        :return: k,v
        """
        # 1. get from dataBean.
        # check data type
        if self.get_data_bean().DATA_TYPE == DataBeanType.MultiBean:
            res = self.get_data_bean().get_data_value(self.key_of_data_bean)
        else:
            pass

        return res, {}


class RequireCache(BarkBaseTask):

    def __init__(self, dataname=None, as_cache_name=None):
        self.data_name = dataname
        super(RequireCache, self).__init__(as_cache_name=as_cache_name)

    def custom_logic(self):
        """
        前缀不用考虑，因为当前是 数据源的级别
        1. 先从 cache 中查找响应的 dataname，并以 cache 中为准
        2. 如果没找到再从 data_tasks 中查找对应的 dataname

        :return: k,v
        """
        # 1. get from cache
        if self.cache_manager is not None and self.cache_manager.get_value(self.data_name) is not None:
            self.set_result(self.cache_manager.get_value(self.data_name))
        else:
            pass
        return self.get_result(), {}


class RequireDB(BarkBaseTask):

    def __init__(self, dataname='default', as_cache_name=None):
        self.data_name = dataname
        super(RequireDB, self).__init__(as_cache_name=as_cache_name)

    def custom_logic(self):
        """
        前缀不用考虑，因为当前是 数据源的级别
        1. 先从 cache 中查找响应的 dataname，并以 cache 中为准
        2. 如果没找到再从 data_tasks 中查找对应的 dataname

        :return: k,v
        """
        # TODO: 1. get DBConnections from ContextBean

        return self.get_result(), {}

