"""
负责从 context_bean 中获取数据库连接池，获得接入 Database的一个 connector，以提供数据库访问的能力。


"""
from beans.core.datainfo_bean import BaseDataBean
from bark_engine import BarkBaseTask


class RequireDB(BarkBaseTask):

    def __init__(self, dbname=None):

        self.dbname = dbname
        super(RequireDB, self).__init__()

    def custom_logic(self):
        """
        context中会有一个 connection pool dict , 保存有多个数据库的连接，此处仅需提供 pool 名.

        """
        # 1. get pools dict from context bean.
        pools = self.task_context_bean.get_db_pool()

        # 2. get specified pool
        pool = pools.get(self.dbname)
        if pool is None:
            raise Exception("no such database pool exception.")
        # 3. return db pool as a Atom DataBean
        res = BaseDataBean(pool)

        return res, {}
