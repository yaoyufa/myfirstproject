# -*- coding: utf-8 -*-
"""
@Time : 2018/8/23
@author : pengzhu 
"""

from beans.core.datainfo_bean import DataBeanType
from bark_engine.task.base.base_task import BarkBaseTask


class Inner(BarkBaseTask):
    """
    对于Join类的算子，其data类型必须是MultiDataBean
    """

    def __init__(self, left_on=None,right_on=None,left_select=None,right_select=None, as_cache_name=None):
        super(Inner, self).__init__(as_cache_name=as_cache_name)
        self.left_on = left_on
        self.right_on = right_on
        self.left_select = left_select
        self.right_select = right_select

    def custom_logic(self):
        res = {}
        # 1. type check: Bean
        if self.data_bean.get_data_type() == DataBeanType.MultiBean:

            datanames = self.data_bean.get_data_name()
            if set(datanames) != (['left','right']):
                raise TypeError("For Joiner Task, MultiDataBean prefix must equal ['left', 'right']")

            left_data = self.data_bean.get_data_value(data_prefix='left').get_data_value()
            right_data = self.data_bean.get_data_value(data_prefix='right').get_data_value()

            if left_data.get(self.left_on) == right_data.get_data_value.get(self.right_on):
                if self.left_select is None:
                    res['left'] = left_data
                else:
                    res['left'] = {k:v for k, v in left_data.items if k in self.left_select}

                if self.right_select is None:
                    res['right'] = right_data
                else:
                    res['right'] = {k:v for k, v in right_data.items if k in self.right_select}

        else:
            raise TypeError('the Joiner Tasks data type must be MultiBean.')

        # 2. built result as DataBean.
        result_bean = self.data_bean.copy_reset_data(res)
        return result_bean, {}
