import re
from copy import copy
from beans.core.datainfo_bean import DataBeanType
from bark_engine.task.base.base_task import BarkBaseTask


class ResetPrefix(BarkBaseTask):
    """
    仅为了支持交叉变量的重命名而存在，(以下操作前，先复制， 以免污染上游 databean)
    1. 强制修改 databean 的隐藏变量 __prefix
    2. 强制replace所有变量的 prefix 为 新的 context 中的前缀
    """
    def __init__(self, as_cache_name=None):
        super(ResetPrefix, self).__init__(as_cache_name=as_cache_name)

    def custom_logic(self):
        if self.data_bean.get_data_type() == DataBeanType.Atom:
            pass
        if self.data_bean.get_data_type() == DataBeanType.Bean:
            # 0. append a function which can force to modify the prefix.
            # 1. copy original databean
            copy_data = copy(self.data_bean.get_data_value())
            copy_databean = self.data_bean.copy_reset_data(copy_data)

            # 2. replace the prefix of keys with preset prefix_data in context.
            renamed_data = {}
            new_prefix = self.task_context_bean.get_reqirement().get_prefix()

            origin_data = copy_databean.get_data_value()
            for key in origin_data.keys():
                # notice that there may exists prefix str more than one .
                prefix_len = len(copy_databean.prefix)
                new_key = new_prefix + key[prefix_len:]
                renamed_data[new_key] = origin_data[key]

            # 3. modify the prefix of databean
            copy_databean.data_name = self.task_context_bean.get_reqirement().get_new_name()
            copy_databean.data_role = self.task_context_bean.get_reqirement().get_role_name()
            copy_databean.ext_info = self.task_context_bean.get_reqirement().get_ext_info()
            copy_databean.prefix = self.task_context_bean.get_reqirement().get_prefix()
            copy_databean = copy_databean.copy_reset_data(renamed_data)

        else:
            raise TypeError('the data_tasks type is not supported yet.')
        return copy_databean, {}

