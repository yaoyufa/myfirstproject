"""
支持 keyname 的命名转换， 注意考虑重名
如：
1. groupby( func=count)操作后，出现的 {'case_1': 2, 'case_2': 6} 可能需要进行重命名
2. 重命名的要求是： 提供 name_mapping 关系， 或者 统一前缀
3. 重命名的要求:

"""