
"""
将value 转换成 dict，以支持在内存中做结构化操作。
1. 需要 json.load
2. 需要注意生成的数据是否需要 flatten，或者 prefix 与顶层保持统一的问题，或者 prefix 需要加上当前所处的 节点的 key
3. 
"""
from copy import copy
from json import loads
from utils.json.flatten import flatten_json
from ..base.base_task import BarkBaseTask
from beans.core.datainfo_bean import DataBeanType


class FlattenMapper(BarkBaseTask):
    def __init__(self, parent_path=None, as_cache_name=None):
        self.parent_path = parent_path
        super(FlattenMapper, self).__init__(as_cache_name=as_cache_name)

    def custom_logic(self):
        res = None
        # 1. data_tasks type. if filled Type: SingleDataBean, then handle.
        if self.data_bean.get_data_type() == DataBeanType.Bean:
            # 2. flatten
            prefix_with_parrent = '' if self.parent_path is None else self.data_bean.sep + self.parent_path
            res = flatten_json(self.data_bean.get_data_value(),
                               key_prefix=self.data_bean.prefix[:-1] + prefix_with_parrent,
                               sep=self.data_bean.sep)
        else:
            raise TypeError('the data_tasks type is not supported yet.')

        # 3. built as data_tasks bean. result should be encapsuled in type: BaseDataBean
        # and copy the filled databean's properties.
        result_bean = self.data_bean.copy_reset_data(res)
        # return result_bean, None
        return result_bean, {}


class JsonMapper(BarkBaseTask):
    """
    支持 Atom 直接转 json
    支持 Bean 内部指定 key ?
    支持 Bean 内部指定 prefix ?
    支持 Bean 全部 key
    """
    def __init__(self, key_regex=None, encoding='utf-8', as_cache_name=None):
        """

        :param key_regex: 三类取值， * , 'specific_key', 'key_arr[{}]'
        :param regex_depth:
        :param as_cache_name:
        """
        self.key_regex = key_regex
        self.encoding = encoding
        super(JsonMapper, self).__init__(as_cache_name=as_cache_name)

    def custom_logic(self):
        res = {}
        # 1. data_tasks type: Atom
        if self.data_bean.get_data_type() == DataBeanType.Atom:
            if isinstance(self.data_bean.get_data_value(), str):
                res = loads(self.data_bean.data(), encoding=self.encoding)
            else:
                res = {}
        # 2. data_tasks type: SingleDataBean.
        elif self.data_bean.get_data_type() == DataBeanType.Bean:
            # 2.1 if regex pattern.
            filter_dict = self.data_bean.filter_regex(key_regex=self.key_regex)
            for key in filter_dict.keys():
                if isinstance(filter_dict[key], str):
                    res[key] = loads(filter_dict[key], encoding=self.encoding)

            # update value after mapper to json.
            x = copy(self.data_bean.get_data_value())
            if x is None:
                x = {}
            x.update(res)
            res = x
        else:
            raise TypeError('the data_tasks type is not supported yet.')

        # 3. built as data_tasks bean. result should be encapsuled in type: BaseDataBean
        # and copy the filled databean's properties.
        result_bean = self.data_bean.copy_reset_data(res)
        return result_bean, {}
