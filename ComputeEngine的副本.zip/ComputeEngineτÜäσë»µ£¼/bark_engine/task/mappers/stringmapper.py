"""
包含以下实现
replace
concat
split

"""
from copy import copy
import logging
from ..base.base_task import BarkBaseTask
from beans.core.datainfo_bean import DataBeanType


class StringMapper(BarkBaseTask):

    def __init__(self, func,as_cache_name=None):
        self.func = func
        super(StringMapper, self).__init__(as_cache_name=as_cache_name)

    def custom_logic(self):
        mapped_str = None
        if self.data_bean.get_data_type() == DataBeanType.Atom:
            raw_str = self.data_bean.get_data_value()
            mapped_str = self.func(raw_str)
            return self.data_bean.copy_reset_data(mapped_str), {}
        elif self.data_bean.get_data_type() == DataBeanType.Bean:
            res = copy(self.data_bean.get_data_value())
            # 逐个转换
            for k in res.keys():
                v = res.get(k)
                try:
                    res[k] = self.func(v)
                except Exception as e:
                    # TODO: log
                    #raise ValueError('can not do substring operation.')
                    logging.error('data could not be mapped with self.func' + __name__)
                    continue
            return self.data_bean.copy_reset_data(res), {}
        else:
            raise TypeError('the data_tasks type is not supported yet.')



