
"""
1. 支持将 指定的 key 的 value 做 cast
2. 支持将全部的 key 的 value 都做 cast

"""
from copy import copy
from beans.core.datainfo_bean import DataBeanType
from bark_engine.task.base.base_task import BarkBaseTask


class CastMapper(BarkBaseTask):
    """
    支持
    """
    def __init__(self, to=None, origin=None, as_cache_name=None):
        """

        :param key_regex:
        :param regex_depth:
        :param as_cache_name:
        """
        self.origin = origin
        self.to = to
        super(CastMapper, self).__init__(as_cache_name=as_cache_name)

    def custom_logic(self):
        res = {}
        # 1. str_regex 转换
        if self.data_bean.get_data_type() == DataBeanType.Atom or self.data_bean.get_data_type() == DataBeanType.Bean:
            # 1. 暂时支持 int 转换
            if self.to == 'int':
                # TODO: mapper 类操作都不能修改原始数据
                res = copy(self.data_bean.get_data_value())
                # 逐个转换
                for k in res.keys():
                    v = res.get(k)
                    try:
                        res[k] = int(v)
                    except TypeError as e:
                        # TODO: log
                        raise TypeError('can not cast to int.')
            else:
                raise TypeError('param is not supported yet.')

        # 2. built as data_tasks bean. result should be encapsuled in type: BaseDataBean
        # and copy the filled databean's properties.
        result_bean = self.data_bean.copy_reset_data(res)
        return result_bean, {}
