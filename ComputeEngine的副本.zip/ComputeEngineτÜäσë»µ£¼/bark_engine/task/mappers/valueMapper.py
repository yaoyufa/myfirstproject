"""
将 value 中的值映射转换成某个特定的值，通常用于默认值的转换
如：
1. 某个 key 的 value 本该是数字，但是有些取值却是'',  '-'  或 '缺失'
2. null 值的统一化转换
3.

实现：
1. 指定某个 key
2. 指定某个 key_pattern
3. 全部，不指定参数

value_map = {'': 'new', '_':'', None:'None'}
"""
import re
from copy import copy
from beans.core.datainfo_bean import DataBeanType
from bark_engine.task.base.base_task import BarkBaseTask


class ValueMapper(BarkBaseTask):
    """
    支持
    """
    def __init__(self, kv_map=None, others=None, str_regex_map=None, digit_regex_map=None, as_cache_name=None):
        """

        :param key_regex:
        :param regex_depth:
        :param as_cache_name:
        """
        self.kv_map = kv_map
        self.others = others
        self.str_regex_map = str_regex_map
        self.digit_regex_map = digit_regex_map
        super(ValueMapper, self).__init__(as_cache_name=as_cache_name)

    def custom_logic(self):
        res = {}
        # 1. str_regex 转换
        if self.data_bean.get_data_type() == DataBeanType.Atom or self.data_bean.get_data_type() == DataBeanType.Bean:
            # 1. 暂时仅支持 硬编码的转换
            if self.kv_map is not None:
                res = copy(self.data_bean.get_data_value())
                # 针对每个 value 做 regex pattern 匹配， 符合就 update
                for k in res.keys():
                    v = res.get(k)
                    if v in self.kv_map.keys():
                        res[k] = self.kv_map[v]
                    else:
                        if self.others is not None:
                            res[k] = self.others
            else:
                raise TypeError('param is not supported yet.')

        # 2. built as data_tasks bean. result should be encapsuled in type: BaseDataBean
        # and copy the filled databean's properties.
        result_bean = self.data_bean.copy_reset_data(res)
        return result_bean, {}
