"""
提供各种时间数据类型的转换，
"""
from copy import copy
import logging
from beans.core.datainfo_bean import DataBeanType
from bark_engine.task.base.base_task import BarkBaseTask
from datetime import datetime
import time


class DateTimeMapper(BarkBaseTask):
    """
    支持
    """
    def __init__(self, src_fmt, dst_fmt, as_cache_name=None):
        """

        :param src_fmt: the format of object to be converted. for example , '%m/%d/%y'
        :param dst_fmt: the format of date object to output. for example , '%Y-%m-%d'
        :param as_cache_name:
        """
        self.src_format = src_fmt
        self.dst_format = dst_fmt
        super(DateTimeMapper, self).__init__(as_cache_name=as_cache_name)

    def custom_logic(self):
        result = {}
        # 1. str_regex 转换
        if self.data_bean.get_data_type() == DataBeanType.Atom or self.data_bean.get_data_type() == DataBeanType.Bean:
            # 获取数据项并转化成date object
            res = copy(self.data_bean.get_data_value())
            for k in res.keys():
                try:
                    v = datetime.strptime(res.get(k), self.src_format)
                    result[k] = datetime.strftime(v, self.dst_format)
                except Exception as e:
                    # TODO: log
                    logging.error('DateTimeMapper error' + __name__)

        result_bean = self.data_bean.copy_reset_data(result)
        return result_bean, {}


class DateTimeFormatterMapper(BarkBaseTask):
    """
    支持将数据从 datetime 或 unix timestamp 格式，转换成指定的字符串格式。
    """
    def __init__(self, dst_fmt='%Y-%m-%d', src_type='datetime', as_cache_name=None):
        """

        :param dst_fmt: %Y-%m-%d or %Y/%m/%d ....
        :param src_type: datetime  or timestamp
        :param as_cache_name: cache name.
        :rtype SingleDataBean
        """
        self.dst_format = dst_fmt
        self.src_type = src_type
        super(DateTimeFormatterMapper, self).__init__(as_cache_name=as_cache_name)

    def custom_logic(self):
        result = {}
        # 1. str_regex 转换
        if self.data_bean.get_data_type() == DataBeanType.Atom or self.data_bean.get_data_type() == DataBeanType.Bean:
            # 获取数据项并转化成date object
            res = copy(self.data_bean.get_data_value())
            for k in res.keys():
                try:
                    if self.src_type == 'datetime':
                        result[k] = datetime.strftime(res.get(k), self.dst_format)
                    elif self.src_type == 'timestamp':
                        result[k] = datetime.strftime(datetime.fromtimestamp(int(res.get(k))), self.dst_format)
                    else:
                        pass
                except Exception as e:
                    # TODO: log
                    logging.error("can not convert to date object." + __name__)

        result_bean = self.data_bean.copy_reset_data(result)
        return result_bean, {}


class FromUnixTimeMapper(BarkBaseTask):
    """
    支持数据从 unix timestamp 转换到 datetime.
    """
    def __init__(self, as_cache_name=None):
        """
        :param as_cache_name:
        """
        super(FromUnixTimeMapper, self).__init__(as_cache_name=as_cache_name)

    def custom_logic(self):
        result = {}
        # 1. str_regex 转换
        if self.data_bean.get_data_type() == DataBeanType.Atom or self.data_bean.get_data_type() == DataBeanType.Bean:
            # 获取数据项并转化成date object
            res = copy(self.data_bean.get_data_value())
            for k in res.keys():
                try:
                    result[k] = datetime.fromtimestamp(int(res.get(k)))
                except Exception as e:
                    # TODO: log
                    logging.error("can not convert to date object." + __name__)


        result_bean = self.data_bean.copy_reset_data(result)
        return result_bean, {}


class ToUnixTimeMapper(BarkBaseTask):
    """
    支持数据从 unix timestamp 转换到 datetime.
    """
    def __init__(self, src_fmt='%Y-%m-%d', as_cache_name=None):
        """
        :param src_fmt: %Y-%m-%d
        :param as_cache_name:
        """
        self.src_format = src_fmt
        super(ToUnixTimeMapper, self).__init__(as_cache_name=as_cache_name)

    def custom_logic(self):
        result = {}
        # 1. str_regex 转换
        if self.data_bean.get_data_type() == DataBeanType.Atom or self.data_bean.get_data_type() == DataBeanType.Bean:
            # 获取数据项并转化成date object
            res = copy(self.data_bean.get_data_value())
            for k in res.keys():
                try:
                    result[k] = time.mktime(time.strptime(res.get(k), self.src_format)).conjugate()
                except Exception as e:
                    # TODO: log , and drop it.
                    logging.error("can not convert to date object." + __name__)

        result_bean = self.data_bean.copy_reset_data(result)
        return result_bean, {}

