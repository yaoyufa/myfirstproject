"""
本task只返回常数
"""
from beans.core.datainfo_bean import DataBeanType
from beans.core.datainfo_bean import BaseDataBean

from ..base.base_task import BarkBaseTask


class ConstValue(BarkBaseTask):
    """
    产生常量的Task

    参数
    ----------
    value:
    用户输入的常量，可以是任意的python数据类型

    key:
    默认为None，字符串类型。给生成的常量命名的key值

    as_cache_name:
    默认为None，字符串类型。给生成的常量命名

    举例
    --------
    >>>from bark_engine.task.base.const_value import ConstValue
    >>>from beans.core.datainfo_bean import SingleDataBean
    >>>from bark_engine.auxi.context_bean import ContextBean
    >>>data = SingleDataBean(data_name='test_const',
    ...                      data_role='at',
    ...                     data={'x':1})
    >>>t = ConstValue(value=2)
    >>>t.fill_context(data=data,context_bean=ContextBean(**{'debug':True}))
    >>>print("*"*3+"before ConstValue Task, the data is :{}".format(data.get_data_value())+"*"*3)
    ***before ConstValue Task, the data is :{'x': 1}***
    >>>result, task_context, kwargs = t.action()
    ----ConstValue--------
    2
    >>>print("*"*3+"after ConstValue Task, the data is :{}".format(result.get_data_value())+"*"*3)
    ***after ConstValue Task, the data is :2***

    >>>t = ConstValue(value=2,key='ConstValue')
    >>>t.fill_context(data=data,context_bean=ContextBean(**{'debug':True}))
    >>>print("*"*3+"before ConstValue Task, the data is :{}".format(data.get_data_value())+"*"*3)
    ***before ConstValue Task, the data is :{'x': 1}***
    >>>result, task_context, kwargs = t.action()
    >>>print("*"*3+"after ConstValue Task, the data is :{}".format(result.get_data_value())+"*"*3)
    ----ConstValue--------
    {'test_const_at_ConstValue': 2}
    ***after ConstValue Task, the data is :{'test_const_at_ConstValue': 2}***

    """
    def __init__(self, value, key=None, as_cache_name=None):
        self.value = value
        self.key = key
        super(ConstValue, self).__init__(as_cache_name=as_cache_name)

    def custom_logic(self):
        # 1. 如果没有 key， 则返回 datatype.Atom类型数据
        if self.key is None:
            return BaseDataBean(self.value), {}

        # 2. 如果有 key, 则返回 datatype.bean类型数据
        if self.data_bean.get_data_type() == DataBeanType.Bean:
            return self.data_bean.copy_reset_data({self.data_bean.prefix + self.key: self.value}), {}

        else:
            raise TypeError('the data_tasks type is not supported yet.')
