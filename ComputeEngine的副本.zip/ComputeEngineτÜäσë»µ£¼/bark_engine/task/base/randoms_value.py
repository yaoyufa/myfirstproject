# -*- coding: utf-8 -*-
"""
@Time : 2018/6/8
本task 只用来生成随机数
"""
from beans.core.datainfo_bean import DataBeanType
from utils.random.random_gen import gen_rand_np
from config import dataname_setting, json_setting
from bark_engine.task.base.base_task import BarkBaseTask


class RandomsValue(BarkBaseTask):
    """
    产生随机数的Task，支持'3c'和'car'两条业务线的随机数需求
    根据json数据中的biz节点判断是哪条业务线

    参数
    -----
    randnum -> Int类型,默认是20，表示随机数的个数

    举例
    -----
    >>> import json
    >>> from bark_engine.controller.pipeline import Pipeline
    >>> from bark_engine.task.mappers.jsonmapper import FlattenMapper
    >>> from producer.beans_factory.global_factory import GlobalFactory
    >>> from beans.core.datainfo_bean import BaseDataBean
    >>> from bark_engine.auxi.context_bean import ContextBean
    >>> from beans.globalinfo.globalinfo_bean import GlobalBean
    >>> from beans.globalinfo.appinfo_bean import AppInfoBean
    >>> from beans.globalinfo.bizinfo_bean import BizInfoBean

    >>> file = './all_in_one_demo_1.json'
    >>> with open(file) as f:
    ...      full_jsondict = json.load(f)
    >>> glb_data, map_data = GlobalFactory.build_global_ele(full_jsondict)
    >>> print(glb_data.get('idno'))
    >>> data_bean_t = BaseDataBean(data=glb_data.get('idno'))
    >>> data_bean_t1 = BaseDataBean(data=glb_data.get(None))
    >>> context_bean_t = ContextBean()
    >>> task = RandomsValue()
    >>> task.fill_context(data_bean_t,context_bean_t)
    >>> res, ctx, kwargs = task.action()
    >>> print(res.get_data_value())
    {'RANDOM_at_randint1': 104,
    'RANDOM_at_randint2': 635,
    'RANDOM_at_randint3': 82,
    'RANDOM_at_randint4': 272,
    'RANDOM_at_randint5': 802,
    'RANDOM_at_randint6': 815,
    'RANDOM_at_randint7': 337,
    'RANDOM_at_randint8': 218,
    'RANDOM_at_randint9': 8,
    'RANDOM_at_randint10': 28,
    'RANDOM_at_randint11': 236,
    'RANDOM_at_randint12': 467,
    'RANDOM_at_randint13': 59,
    'RANDOM_at_randint14': 322,
    'RANDOM_at_randint15': 171,
    'RANDOM_at_randint16': 192,
    'RANDOM_at_randint17': 498,
    'RANDOM_at_randint18': 971,
    'RANDOM_at_randint19': 207,
    'RANDOM_at_randint20': 621}


    """
    __PREFIX_COL_NAME = dataname_setting.node_random + json_setting.separator + \
                        json_setting.role_applicant + json_setting.separator + \
                        'randint'

    def __init__(self, randnum=20, as_cache_name=None):
        self.randnum = randnum
        super(RandomsValue, self).__init__(as_cache_name=as_cache_name)

    def custom_logic(self):
        if self.data_bean.get_data_type() == DataBeanType.Atom:
            try:
                seed = None if self.data_bean.get_data_value() is None else int(self.data_bean.get_data_value())
            except:
                seed = None
        else:
            raise TypeError('the data_tasks type is not supported yet.')

        rand_lst = gen_rand_np(seed, self.randnum)
        r = {self.get_randoms_prefix + str(i + 1): int(v) for i, v in enumerate(rand_lst)}

        return self.data_bean.copy_reset_data(r), {}

    @property
    def get_randoms_prefix(self):
        return self.__PREFIX_COL_NAME







