"""
本类专门用于提取 context 中的单个全局变量
"""
from enum import Enum, unique
from config.json_setting import node_appcode, node_idno, node_idtype, node_mobile, node_biz
from beans.core.datainfo_bean import BaseDataBean
from .base_task import BarkBaseTask


@unique
class GlobalKey(Enum):
    Appcode= node_appcode
    Idno = node_idno
    Idtype = node_idtype
    Mobile = node_mobile
    Biz = node_biz


class GlobalInfo(BarkBaseTask):
    """
    获取全局变量的Task, 一个申请人一个Json数据，从Json中解析出全局信息变量，比如身份证，业务线等

    参数
    -----
    key -> String类型，目前仅支持['appCode'，'idno'，'biz']

    举例
    -----
    >>> import json
    >>> from bark_engine.controller.pipeline import Pipeline
    >>> from bark_engine.task.mappers.jsonmapper import FlattenMapper
    >>> from producer.beans_factory.global_factory import GlobalFactory
    >>> from beans.core.datainfo_bean import SingleDataBean
    >>> from bark_engine.auxi.context_bean import ContextBean
    >>> from beans.globalinfo.globalinfo_bean import GlobalBean
    >>> from beans.globalinfo.appinfo_bean import AppInfoBean
    >>> from beans.globalinfo.bizinfo_bean import BizInfoBean

    >>> file = './all_in_one_demo_1.json'
    >>> with open(file) as f:
    ...      full_jsondict = json.load(f)
    >>> glb_data, map_data = GlobalFactory.build_global_ele(full_jsondict)
    >>> biz = glb_data.get('biz')
    >>> version = glb_data.get('version')
    >>> appCode = glb_data.get('appCode')
    >>> idno = glb_data.get('idno')
    >>> mobile = glb_data.get('mobile')
    >>> data_bean_t = SingleDataBean(data_name='glb',data_role='',data=glb_data)
    >>> context_bean_t = ContextBean(globalbean=GlobalBean(bizinfo=BizInfoBean(biz_type=biz, biz_prod=version),
    ...                                                    appinfo=AppInfoBean(appcode=appCode, idtype=1,
    ...                                                                        idno=idno, mobile=mobile)
    ...                                                    )
    ...                             )
    >>> task = GlobalInfo(key=GlobalKey.Biz)
    >>> task.fill_context(data_bean_t, context_bean_t)
    >>> res, ctx, kwargs =task.action()
    >>> print(res.get_data_value())
    'car_XXX'
    >>> print(data_bean_t.data.get('biz'))
    'car_XXX'

    """
    def __init__(self, key=None, as_cache_name=None, **kwargs):
        """

        :param key:
        :type key: GlobalKey
        :param as_cache_name:
        :param kwargs:
        """
        super(GlobalInfo, self).__init__(as_cache_name=as_cache_name)
        self.key = key
        self.kwargs = kwargs

    def custom_logic(self):
        value = None
        if self.key == GlobalKey.Appcode:
            value = self.task_context_bean.get_appcode()
        elif self.key == GlobalKey.Idno:
            value = self.task_context_bean.get_idno()
        elif self.key == GlobalKey.Biz:
            value = self.task_context_bean.get_biz_type()

        else:
            raise KeyError('the key you pass is not supported yet.')

        # fill into bean
        res_bean = BaseDataBean(data=value)
        return res_bean, {}
