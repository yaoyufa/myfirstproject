"""
抽象 task 类：
输入：
0. 关心的 datasource_name,  key_pattern or  keyname,  prefix,

功能：
1. task 需要指定目标dataname：default 是单个数据源的情况
2. task 需实现指定的 action操作
3. task 需要确定是否需要 cache ，以保障其 result 能跨pipeline级别复用
    3.1 task 需持有 cache 对象引用
    3.2 task 需注明 结果被cached keyname

4. 单个 task 支持两种情形：
    1. 只衍生一个字段
    2. 衍生一个数组
    3. 自动化衍生，生成一系列的各种不同的衍生结果：如：时序衍生、 统计量衍生、条件统计量衍生、条件计数等等

6. 支持逻辑操作：
    1. 如： if(task, then_task, else_task)
    2.

select('', as='')


输出：
5. 返回具名的 k-v ， 关心 prefix ？

"""
import traceback
import logging
from config.json_setting import node_dag_status, node_dag_status_fail
from beans.core.datainfo_bean import SingleDataBean
from bark_engine.auxi.context_bean import ContextBean


class BarkBaseTask(object):
    """
    所有task的基类，主要包含三个功能，按执行步骤如下：
    1. fill_context 通过该函数灌入需要的DataBean，ContextBean以及其他额外的信息，创建Task
    2. custom_logic 子类实现该函数，实现数据转换操作，返回转换后的DataBean
    3. post_logic 父类实现，子类继承，返回转换后的DataBean，自身的ContextBean，并设置Task执行状态，执行结果
    4. action 组合custom_logic 和post_logic，实现两者的集成顺序操作

    参数
    --------
    data -> DataBean类型
    contextbean -> ContextBean类型
    as_cache_name -> String类型
    kwargs -> dict类型

    """
    def __init__(self, data=None, contextbean=None, as_cache_name=None, **kwargs):
        """
        将上游传递的数据做处理， task 相关的之类，

        参数只作为配置用，因为每个 task 的目标不一样，就像 sql 的函数，没必要统一，随便用，只要对外的返回接口统一就可以实现嵌套、复用。

        应特别关注，在多层嵌套的 Executor中，copy_reset_data()是否会造成 Union 类复用 context_bean 的操作是否会受到影响。是否需要提前做 copy controller.

        :param data:
        :param contextbean:
        :param as_cache_name: if not null, the task result will be cached in cache.
        :param kwargs:
        :type data: SingleDataBean
        :type contextbean: ContextBean
        :type as_cache_name: str
        :type kwargs: dict

        """
        self.__cache_name = as_cache_name
        self.__result = None
        self.__finished = False
        self.data_bean = data
        self.task_context_bean = contextbean
        self.kwargs = None

    def get_result(self):
        return self.__result

    def set_result(self, res):
        self.__result = res

    def get_data_bean(self):
        return self.data_bean

    @property
    def cache_manager(self):
        return self.task_context_bean.get_cache_manager()

    def should_cache(self):
        if self.__cache_name is None:
            return False
        else:
            return True

    def get_cache_name(self):
        if self.__cache_name is None:
            return None
        else:
            return self.__cache_name

    # TODO: 考虑独立出 data_mgr, context_bean ? 以方便各个 task 直接获取数据，并进行处理
    def fill_context(self, data=None, context_bean=None, **kwargs):
        """
        数据由上层task 结果自动注入
        :param data:
        :type data: BaseDataBean
        :param context_bean:
        :type context_bean: ContextBean
        :param kwargs: 其它信息，可以是上游增添的信息，也可以是 本次 task 的 custom_logic 之后，不方便放入 bean 中的数据。

        :return:
        """
        self.data_bean = data
        self.task_context_bean = context_bean
        self.kwargs = kwargs

    def action(self):
        # 1. calc logic
        try:
            result, kwargs = self.custom_logic()
        except Exception as e:
            logging.error(traceback.print_exc())
            #print(e.with_traceback())
            result = self.data_bean.copy_reset_data({node_dag_status: node_dag_status_fail})
            kwargs = {}
        # 2. save result and status.
        result, task_context, kwargs = self.post_logic(result=result, **kwargs)

        return result, task_context, kwargs

    # TODO: 每个 custom_logic 都是对 data_tasks 的操作，操作完成后，会将结果更新到 databean 中， 只有特别情况下需要更新 task_context.
    # TODO: bark task 不应该接受 dataManager 的形式， 而应该是一个个简单的类：都继承自 DataObj 类，并且每个 task 都要在处理时检查支持的data类型
    # 1. 子类1：简单类型值，如 ifelse ，或者 groupby
    # 2. 子类2：dict格式的具体衍生: 如：databean
    # 3. 子类3：多个 k-v 格式的 databean,
    # 当各个 bark task 碰到时，应该知道如何处理对应的 data_tasks type(根据 DATA_TYPE 判定).
    def custom_logic(self):
        """
        返回具名的 k-v 对 或者 dict
        :return: 计算结果 和 附加结果，附加结果会在 post_logic 中被更新处理，或者 保存在 context 中
        :rtype: dict
        """
        # 1. calc result and another kwargs for post_logic.
        # 2. modify context: self.__task_context_bean

        result = None
        kwargs = {}

        return result, kwargs

    def post_logic(self, result=None, **kwargs):
        """
        built params like: beans, kwargs for next Task or embed Controller.
        :param result:
        :param kwargs:
        :return:
        """
        self.__finished = True
        # save result.
        self.set_result(result)
        # update context.
        # ...
        # 3. cache result if need.
        self.cache_result_if_need()
        # TODO: debug support.
        if self.task_context_bean.is_debug_mode():
            logging.error('----' + self.__class__.__name__ + "--------")
            logging.error(result.get_data_value())
            k = "["+self.__class__.__name__+"]"
            v = result.get_data_value()

            self.task_context_bean.set_debug_info({k: v})

        # TODO: any other data_tasks should be saved into self.__kwargs.

        return result, self.task_context_bean, self.kwargs

    def reset_data(self, default_databean=None):
        """
        注意要 shallow copy(context_bean),以确保新的result数据更新到 data_tasks 中后，不会影响 Union 类复用 不可修改的context_bean.data_tasks 的情况。

        :param default_databean:
        :return:
        """
        # no need any more.
        #self.__task_context_bean = copy(self.__task_context_bean)
        #self.__task_context_bean.get_data_bean(DataManager(default=default_databean))
        pass

    def cache_result_if_need(self):
        if self.should_cache():
            self.cache_manager.set_value(self.get_cache_name(), self.get_result())
