"""
支持各式各样的Reducer

1. group by xxx , count(xxx)
2. count(case when x then 1 else 2 end)  # 本质上是： reducer( mapper )
3. sum/avg/mean/std/entropy( case when x then 2 else 2 end)   # 本质上是： Reducer(mapper)
4. greater(x, [1,3,4,5]) :
5. 时间序列 : Series(col, Latest3, sum3,  avg3,....)
6. 频率统计 :
7.
8.

格式上：
1. GroupBy(key=[], func=[] , as='')
    1.1 key 可以是某个确定的 key， 可以使 keyarr_pattern, 也可以是 常量， 也可以是多个keys
    1.2 func 可以是任意函数, 支持对集合数据、null 数据、单个数据 做操作。 同时还需要有 name ，以支持计算结果的命名
    1.3 最后的计算结果是由各个Reducer决定的
        1. 比如 groupby(Count) 那么返回的是：{group_value1: stats_value, group_value1: stats_value}
        2. 如果是直接count() 那么返回： {'count': value}

-- 以上设计太复杂，考虑只支持对上游传递数据的简单聚合。 顶多支持上游集合数据的 cache来节省一部分计算时间。

或者 支持 foreach 操作 ?

foreach 如何实现？

"""
