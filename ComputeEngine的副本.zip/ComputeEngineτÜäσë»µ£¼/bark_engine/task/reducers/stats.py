from copy import copy
from beans.core.datainfo_bean import DataBeanType
from bark_engine.task.base.base_task import BarkBaseTask


class Count(BarkBaseTask):

    def __init__(self, rename='cnt', as_cache_name=None):
        super(Count, self).__init__(as_cache_name=as_cache_name)
        self.as_name = rename

    def custom_logic(self):
        res = {}
        # 1. type check: Bean
        if self.data_bean.get_data_type() == DataBeanType.Bean:
            res[self.data_bean.prefix + self.as_name] = len(self.data_bean.get_data_value())
        else:
            raise TypeError('the data_tasks type is not supported yet.')

        # 2. built result as DataBean.
        result_bean = self.data_bean.copy_reset_data(res)
        return result_bean, {}


class Sum(BarkBaseTask):

    def __init__(self, as_name='sum', as_cache_name=None):
        super(Sum, self).__init__(as_cache_name=as_cache_name)
        self.as_name = as_name

    def custom_logic(self):
        res = {}
        # 1. type check: Bean
        if self.data_bean.get_data_type() == DataBeanType.Bean:
            res[self.data_bean.prefix + self.as_name] = sum(self.data_bean.get_data_value().values())
        else:
            raise TypeError('the data_tasks type is not supported yet.')

        # 2. built result as DataBean.
        result_bean = self.data_bean.copy_reset_data(res)
        return result_bean, {}


class Max(BarkBaseTask):

    def __init__(self, as_name='sum', as_cache_name=None):
        super(Max, self).__init__(as_cache_name=as_cache_name)
        self.as_name = as_name

    def custom_logic(self):
        res = {}
        # 1. type check: Bean
        if self.data_bean.get_data_type() == DataBeanType.Bean:
            try:
                res[self.data_bean.prefix + self.as_name] = max(self.data_bean.get_data_value().values())
            except:
                # max() arg is an empty sequence. return no data.
                pass
        else:
            raise TypeError('the data_tasks type is not supported yet.')

        # 2. built result as DataBean.
        result_bean = self.data_bean.copy_reset_data(res)
        return result_bean, {}


class Min(BarkBaseTask):

    def __init__(self, as_name='sum', as_cache_name=None):
        super(Min, self).__init__(as_cache_name=as_cache_name)
        self.as_name = as_name

    def custom_logic(self):
        res = {}
        # 1. type check: Bean
        if self.data_bean.get_data_type() == DataBeanType.Bean:
            try:
                res[self.data_bean.prefix + self.as_name] = min(self.data_bean.get_data_value().values())
            except:
                # arg is an empty sequence
                pass
        else:
            raise TypeError('the data_tasks type is not supported yet.')

        # 2. built result as DataBean.
        result_bean = self.data_bean.copy_reset_data(res)
        return result_bean, {}


class Avg(BarkBaseTask):

    def __init__(self, as_name='avg', as_cache_name=None):
        super(Avg, self).__init__(as_cache_name=as_cache_name)
        self.as_name = as_name

    def custom_logic(self):
        res = {}
        # 1. type check: Bean
        if self.data_bean.get_data_type() == DataBeanType.Bean:
            try:
                res[self.data_bean.prefix + self.as_name] = sum(self.data_bean.get_data_value().values()) \
                                                            / len(self.data_bean.get_data_value())
            except:
                # arg is empty sequence.
                pass
        else:
            raise TypeError('the data_tasks type is not supported yet.')

        # 2. built result as DataBean.
        result_bean = self.data_bean.copy_reset_data(res)
        return result_bean, {}

