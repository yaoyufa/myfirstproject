# -*- coding: utf-8 -*-
"""
@Time : 2018/9/20
@author : pengzhu 
"""
from beans.core.datainfo_bean import DataBeanType
from bark_engine.task.base.base_task import BarkBaseTask
from beans.core.datainfo_bean import BaseDataBean


class In(BarkBaseTask):
    """

    """
    def __init__(self,op_task,value_sets):
        self.op_task = op_task
        self.value_sets = value_sets


    def custom_logic(self):
        if isinstance(self.op_task, BarkBaseTask):
            self.op_task.fill_context(data=self.data_bean, context_bean=self.task_context_bean, **self.kwargs)
            self.op_task.action()
            op_res = self.op_task.get_result().get_data_value()
        else:
            raise TypeError("op_task must be BarkBaseTask.")


        if self.data_bean.get_data_type() == DataBeanType.Atom or self.data_bean.get_data_type() == DataBeanType.Bean:
            con = None
            if isinstance(op_res, dict):
                if set(op_res.items()).issubset(self.value_sets.items()):
                    con = True
                else:
                    con = False
            else:
                if op_res in self.value_sets:
                    con = True
                else:
                    con = False
        else:
            raise TypeError("Currently, only support Atom and Bean")
        result_bean = BaseDataBean(con)
        return result_bean,{}