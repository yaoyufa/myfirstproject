"""
支持从 json dict中筛选变量, prefix 是上游 fill 在某个 bean 中传递过来的， 这里只考虑真实的
针对 key 的操作
1. 提取单个变量: Select(key='', rename='', doc_name='')
2. 提取多个变量，Array类: SelectArray(key_regex='', rename='', doc_name='', length=100, regex_num=1)
3. 提取多个变量，前缀: SelectPrefix(key='', rename='', doc_name='')

"""
import re
import numpy as np
import logging
from beans.core.datainfo_bean import DataBeanType
from ..base.base_task import BarkBaseTask


def dict_cast_type(dict_data, to_type):
    dict_new = {}
    for k, v in dict_data.items():
        if v is not None:
            try:
                if to_type == 'int':
                    dict_new[k] = int(v)
                elif to_type == 'float':
                    dict_new[k] = float(v)
                elif to_type == 'long':
                    dict_new[k] = np.long(v.replace(',', '') if isinstance(v, str) else v)
                elif to_type == 'str':
                    dict_new[k] = str(v)
                elif to_type == "tuple":
                    dict_new[k] = tuple(v)
                elif to_type == "list":
                    dict_new[k] = list(v)
                else:
                    logging.error("Currently, you input data type '{}' is not supported!!!".format(to_type))
            except ValueError as e:
                logging.error("cast_type to '{}' error".format(to_type))

    return dict_new


class Select(BarkBaseTask):
    """
    所有filter类型Task的基类，用于从每个具体的征信源json数据中查找需要的字段数据；
    输入要查找的数据在具体征信源json data中对应path(json各层级之间的key用_相连组成path)，获取要查找的值
    如果查找的值为None，则不返回

    参数
    -----
    key -> String 类型，json data的key path
    rename -> String 类型，若rename为None，则返回数据的key为原来json的key path，否则重命名为输入的rename
    cast -> String类型，若不为空，则按输入的类型对数据进行类型转换，目前只支持['int','float','long','str','tuple','list']

    举例
    -----
    >>> import json
    >>> from producer.beans_factory.global_factory import GlobalFactory
    >>> from beans.core.datainfo_bean import SingleDataBean, MultiDataBean
    >>> from bark_engine.auxi.context_bean import ContextBean
    >>> from beans.core.requirement_bean import RequirementBean, ActionType
    >>> from bark_engine.auxi.cache import CacheManager
    >>> from beans.globalinfo.globalinfo_bean import GlobalBean
    >>> from beans.globalinfo.appinfo_bean import AppInfoBean
    >>> from beans.globalinfo.bizinfo_bean import BizInfoBean
    >>> from bark_engine.dag.dag import Dag
    >>> from bark_engine.controller.pipeline import Pipeline
    >>> from bark_engine.task.mappers.jsonmapper import FlattenMapper
    >>> from bark_engine.controller.union import Union
    >>> file = './all_in_one_demo_1.json'
    >>> with open(file) as f:
    ...      full_jsondict = json.load(f)
    >>> glb_data, map_data = GlobalFactory.build_global_ele(full_jsondict)
    >>> biz = glb_data.get('biz')
    >>> version = glb_data.get('version')
    >>> idno = glb_data.get('idno')
    >>> appCode = glb_data.get('appcode')
    >>> mobile = glb_data.get('mobile')
    >>> data_info = map_data.get('tdPlCF_at')
    >>> target_name = data_info.get('data_name')
    >>> data_name = data_info.get('data_name')
    >>> data_role = data_info.get('data_role')
    >>> extra_data_info = data_info.get('extra_data_info')
    >>> data = data_info.get('data')
    >>> data_bean = SingleDataBean(data_name=data_name, data_role=data_role,
    ... ext_info=extra_data_info, data=data)
    >>> context_bean = ContextBean(cachemgr=CacheManager(),
    ...                           globalbean=GlobalBean(bizinfo=BizInfoBean(biz_type=biz, biz_prod=version),
    ...                                                 appinfo=AppInfoBean(appcode=appCode, idtype=1,
    ...                                                                     idno=idno, mobile=mobile)),
    ...                           requirementbean=RequirementBean(action_type=ActionType.Single,
    ...                           new_name=target_name)
    ...                           )
    >>> ctr = Pipeline(FlattenMapper(),
    ...          Union(Select(key='mongodbId'),
    ...                Select(key='mainData_fraudmetrixId'),
    ...                Select(key='mainData_finalDecision', rename='finalDecision'),
    ...                Select(key='mainData_finalDecision', rename='finalDecision_tuple',cast='tuple'),
    ...                Select(key='mainData_finalScore', rename='finalScore'),
    ...                SelectArray(key_path='detailDataList[{}]_ruleName', rename='detailDataList_ruleName[{}]')
    ...           )
    ...         )
    >>> dag = Dag()
    >>> dag.fill(data_bean=data_bean,context_bean=context_bean)
    >>> dag.controller = ctr
    >>> dag.action()
    >>> print(data_bean.data.get('mongodbId'))
    '5ae046212619a74ae48f2598'
    >>> print(data_bean.data.get('mainData').get('fraudmetrixId'))
    None
    >>> print(data_bean.data.get('mainData').get('finalDecision'))
    "Accept"
    >>> print(data_bean.data.get('mainData').get('finalScore'))
    0
    >>> print(data_bean.data.get('detailDataList')[0].get('ruleName'))
    "3个月内身份证在多个平台申请借款"
    >>> print(data_bean.data.get('detailDataList')[1].get('ruleName'))
    "3个月内申请人在多个平台申请借款"
    >>> print(data_bean.data.get('detailDataList')[2].get('ruleName'))
    "3个月内手机在多个平台申请借款"
    >>> print(dag.get_result())
    {'tdPlCF_at_mongodbId': '5ae046212619a74ae48f2598',
     'tdPlCF_at_finalDecision': 'Accept',
     'tdPlCF_at_finalDecision_tuple': ('A', 'c', 'c', 'e', 'p', 't'),
     'tdPlCF_at_finalScore': 0,
     'tdPlCF_at_detailDataList_ruleName[1]': '3个月内身份证在多个平台申请借款',
     'tdPlCF_at_detailDataList_ruleName[2]': '3个月内申请人在多个平台申请借款',
     'tdPlCF_at_detailDataList_ruleName[3]': '3个月内手机在多个平台申请借款',
     'tdPlCF_at_detailDataList_ruleName[4]': '第一联系人手机号命中网贷黑名单',
     'tdPlCF_at_detailDataList_ruleName[5]': '第二联系人手机号命中网贷黑名单',
     'tdPlCF_at_detailDataList_ruleName[6]': '身份证命中网贷黑名单',
     'tdPlCF_at_detailDataList_ruleName[7]': '手机号命中网贷黑名单',
     'tdPlCF_at_detailDataList_ruleName[8]': '借款身份证命中全局失信证据库',
     'tdPlCF_at_detailDataList_ruleName[9]': '借款手机号命中全局失信证据库',
     'tdPlCF_at_detailDataList_ruleName[10]': '指标获取_身份证',
     'tdPlCF_at_detailDataList_ruleName[11]': '指标获取_设备',
     'tdPlCF_at_detailDataList_ruleName[12]': '指标获取_多平台',
     'dag_status': 200}

     >>> ctr1 = Pipeline(FlattenMapper(),SelectArrayPair(group_regex='\w+detailDataList\[\d+\]_'))
     >>> dag =Dag()
     >>> dag.fill(data_bean=data_bean, context_bean=context_bean)
     >>> dag.action()
     >>> print(len(data_bean.data.get('detailDataList')))
     12
     >>> print(data_bean.data.get('detailDataList')[0])
     {'fraudmetrixDetailId': None, 'seqId': '1524647456056670S180F1F768205801', 'policyName': 'paydayloan',
     'ruleName': '3个月内身份证在多个平台申请借款', 'hitScore': 0, 'sendStatus': 1, 'reasonCode': '200:操作成功',
     'dataStatus': '00', 'createtime': 1524647456493, 'riskDicision': None,
     'ruleDetail': '[
                        {"个数":21,"描述":"3个月内身份证多平台借款平台数",
                        "详情":[
                                {"P2P网贷":"15","一般消费分期平台":"2","小额贷款公司":"1",
                                "消费金融公司":"1","理财机构":"1","银行消费金融公司":"1"
                                }
                            ]
                        }
                    ]'
     }
     >>> print(dag.get_result().keys())
     dict_keys(["['1']", "['2']", "['3']", "['4']", "['5']", "['6']", "['7']", "['8']", "['9']", "['10']",
                "['11']", "['12']", 'dag_status'])
     >>> print(dag.get_result().get("['1']"))
    {'tdPlCF_at_detailDataList[1]_fraudmetrixDetailId': None,
    'tdPlCF_at_detailDataList[1]_seqId': '1524647456056670S180F1F768205801',
    'tdPlCF_at_detailDataList[1]_policyName': 'paydayloan',
    'tdPlCF_at_detailDataList[1]_ruleName': '3个月内身份证在多个平台申请借款',
    'tdPlCF_at_detailDataList[1]_hitScore': 0,
    'tdPlCF_at_detailDataList[1]_sendStatus': 1,
    'tdPlCF_at_detailDataList[1]_reasonCode': '200:操作成功',
    'tdPlCF_at_detailDataList[1]_dataStatus': '00',
    'tdPlCF_at_detailDataList[1]_createtime': 1524647456493,
    'tdPlCF_at_detailDataList[1]_riskDicision': None,
    'tdPlCF_at_detailDataList[1]_ruleDetail': '[
                                                {"个数":21,"描述":"3个月内身份证多平台借款平台数",
                                                "详情":[
                                                        {"P2P网贷":"15","一般消费分期平台":"2","小额贷款公司":"1",
                                                        "消费金融公司":"1","理财机构":"1","银行消费金融公司":"1"
                                                        }
                                                    ]
                                                }
                                            ]'
    }

    >>> ctr2 = Pipeline(FlattenMapper(),SelectRegex(key_regex='\w+detailDataList\[\d+\]_ruleName'))
    >>> dag.controller = ctr2
    >>> dag.action()
    >>> print(dag.get_result())
    {'tdPlCF_at_detailDataList[1]_ruleName': '3个月内身份证在多个平台申请借款',
     'tdPlCF_at_detailDataList[2]_ruleName': '3个月内申请人在多个平台申请借款',
     'tdPlCF_at_detailDataList[3]_ruleName': '3个月内手机在多个平台申请借款',
     'tdPlCF_at_detailDataList[4]_ruleName': '第一联系人手机号命中网贷黑名单',
     'tdPlCF_at_detailDataList[5]_ruleName': '第二联系人手机号命中网贷黑名单',
     'tdPlCF_at_detailDataList[6]_ruleName': '身份证命中网贷黑名单',
     'tdPlCF_at_detailDataList[7]_ruleName': '手机号命中网贷黑名单',
     'tdPlCF_at_detailDataList[8]_ruleName': '借款身份证命中全局失信证据库',
     'tdPlCF_at_detailDataList[9]_ruleName': '借款手机号命中全局失信证据库',
     'tdPlCF_at_detailDataList[10]_ruleName': '指标获取_身份证',
     'tdPlCF_at_detailDataList[11]_ruleName': '指标获取_设备',
     'tdPlCF_at_detailDataList[12]_ruleName': '指标获取_多平台',
     'dag_status': 200}
    """

    def __init__(self, key=None, rename=None, doc_name=None, as_cache_name=None, cast = None):
        """

        :param key: key 值（不考虑 prefix）
        :param rename: 重命名为
        :param doc_name: 文档名
        :param as_cache_name:
        :param cast: str , for example 'int','str', 'float', etc.
        """
        super(Select, self).__init__(as_cache_name=as_cache_name)

        self.key = key
        self.rename = rename
        self.doc_name = doc_name
        self.cast = cast

    def custom_logic(self):
        """
        :return:
        """
        res = {}
        # 1. if filled Type: SingleDataBean, then handle.
        if self.data_bean.get_data_type() == DataBeanType.Bean:
            key, value = self.data_bean.filter(key=self.key, rename=self.rename)
            if key is not None:
                res[key] = value
        else:
            raise TypeError('the data_tasks type is not supported yet.')

        # 2. whether to convert data type
        if self.cast is not None:
            res = dict_cast_type(dict_data=res, to_type=self.cast)
        # 3. : result should be encapsuled in type: BaseDataBean and copy the filled databean's properties.
        result_bean = self.data_bean.copy_reset_data(res)
        return result_bean, {}


class SelectArray(BarkBaseTask):
    def __init__(self, key_path='', rename='', doc_name='', length=100, array_depth=1, as_cache_name=None, cast = None):
        """

        :param key: key 值（不考虑 prefix）
        :param rename: 重命名为
        :param doc_name: 文档名
        :param as_cache_name:
        """
        super(SelectArray, self).__init__(as_cache_name=as_cache_name)

        self.key = key_path
        self.rename = rename
        self.doc_name = doc_name
        self.length = length
        self.regex_depth = array_depth
        self.cast = cast

    def custom_logic(self):
        """

        :return:
        """

        # 1. if filled Type: SingleDataBean, then handle.
        if self.data_bean.get_data_type() == DataBeanType.Bean:
            if self.rename == '':
                raise TypeError('The param: rename can not be None or blank .')
            res = self.data_bean.filter_array(key_array_format=self.key, rename_array_format=self.rename,
                                              length=self.length, regex_depth=self.regex_depth)
        else:
            raise TypeError('the data_tasks type is not supported yet.')

        # 2. whether to convert data type
        if self.cast is not None:
            res = dict_cast_type(dict_data=res, to_type=self.cast)

        # 3. : result should be encapsuled in type: BaseDataBean and copy the filled databean's properties.
        result_bean = self.data_bean.copy_reset_data(res)
        return result_bean, {}


class SelectPrefix(BarkBaseTask):
    def __init__(self, key_regex='', rename='', doc_name='', as_cache_name=None, cast = None):
        super(SelectPrefix, self).__init__(as_cache_name=as_cache_name)
        self.name_prefix = key_regex
        self.rename = rename
        self.doc_name = doc_name
        self.cast = cast

    def custom_logic(self):
        # 1. if filled Type: SingleDataBean, then handle.
        if self.data_bean.get_data_type() == DataBeanType.Bean:
            res = self.data_bean.filter_prefix(key_regex=self.name_prefix, rename_regex=self.rename, length=self.length,
                                               regex_depth=self.regex_depth)
        else:
            raise TypeError('the data_tasks type is not supported yet.')

        # 2. whether to convert data type
        if self.cast is not None:
            res = dict_cast_type(dict_data=res, to_type=self.cast)

        # 3. : result should be encapsuled in type: BaseDataBean and copy the filled databean's properties.
        result_bean = self.data_bean.copy_reset_data(res)
        return result_bean, {}


class SelectRegex(BarkBaseTask):
    def __init__(self, key_regex='', rename='', doc_name='', as_cache_name=None, cast=None):
        super(SelectRegex, self).__init__(as_cache_name=as_cache_name)
        self.key_prefix = key_regex
        self.rename = rename
        self.doc_name = doc_name
        self.cast = cast

    def custom_logic(self):
        # 1. if filled Type: SingleDataBean, then handle.
        if self.data_bean.get_data_type() == DataBeanType.Bean:
            res = self.data_bean.filter_regex(key_regex=self.key_prefix)
        else:
            raise TypeError('the data_tasks type is not supported yet.')

        # 2. whether to convert data type
        if self.cast is not None:
            res = dict_cast_type(dict_data=res, to_type=self.cast)

        # 3. : result should be encapsuled in type: BaseDataBean and copy the filled databean's properties.
        result_bean = self.data_bean.copy_reset_data(res)
        return result_bean, {}


class SelectArrayPair(BarkBaseTask):
    def __init__(self,group_regex,rename=None,as_cache_name=None):
        super(SelectArrayPair, self).__init__(as_cache_name=as_cache_name)
        self.group_regex = group_regex
        self.rename = rename

    def custom_logic(self):
        # 1. 根据regex 的 prefix 传递的数组
        res_regex = self.data_bean.filter_regex(self.group_regex)
        # 2. 我们获取regex筛选后的结果中[\d+]构成的组合来作为分组标志，扫描一次，根据分组标记存储到指定的 分组，
        group_kv = {}
        for key in res_regex.keys():
            indexes = re.findall(r'\[(\d+)\]', key)
            # 1. 初始化分组
            x = group_kv.get(indexes.__str__())
            if x is None:
                group_kv.setdefault(indexes.__str__(), {})
            # 2. 写入分组
            group_kv.get(indexes.__str__()).setdefault(key, res_regex.get(key))

        result_bean = self.data_bean.copy_reset_data(group_kv)
        return result_bean, {}



