import jinja2 as jinja
from beans.core.datainfo_bean import DataBeanType, BaseDataBean
from bark_engine.task.base.base_task import BarkBaseTask


class DBQuery(BarkBaseTask):
    """
    需配合 RequireDB 来使用。
    1. 支持 jinja2 模板方法编写 sql
    2. 支持 全局变量注入
    3. 支持 临时 task 生成变量注入： 可以是 singledatabean / atombean, 取数时，注意区别对待。
    """
    # TODO: 支持在 context 中存储当前客户信息, 方便sql中自动注入全局信息 idno, contract_id, mobile, reg_date,
    # TODO: 支持 task 计算结果注入
    def __init__(self, sql=None, kv_task_params=None, as_name=None, as_cache_name=None):
        """

        支持 sql 查询, 默认会在环境变量中注入 idno, contract_id, mobile, reg_date,
        也可以通过 kv_task_params 注入任意 task 生成的变量，并指定了返回值的变量名，如 {"td_a": Pipeline(requireCache('td'), Select('a') )} 那么 jinja2中可用 td_a 引用, 或者 其它征信源导入的数据。
        """
        super(DBQuery, self).__init__(as_cache_name=as_cache_name)
        self.sql = sql
        self.kv_task_params = kv_task_params
        self.as_name = as_name

    def custom_logic(self):
        """
        :return:
        """
        res = {}

        if self.as_name is None:
            raise Exception('param as_name can not be None.')

        if self.data_bean.get_data_type() == DataBeanType.Atom:
            # 1. 从上游获得连接池
            pool = self.data_bean.get_data_value()

            # 2. 运行 tasks 以生成 sql 内嵌的参数
            res = self.data_bean
            merged_res = {}

            if self.kv_task_params is not None:
                for key, task in self.kv_task_params.items():
                    # data_tasks 是上一次的结果， 初次是从 datalist 中通过 RequireData 类获取的
                    task.fill_context(data=res, context_bean=self.task_context_bean, **self.kwargs)
                    res_bean, self.task_context_bean, self.kwargs = task.action()

                    # update result:
                    result = task.get_result()
                    value = result.get_data_value()
                    # case 1：单个结果, 如果是 dict, 可直接丢弃 key, 取其 value; 如果不是 dict，直接取值
                    if type(value) is not dict:
                        merged_res.update({key: value})
                    # case 2: 多个结果，先排序? 再取其 value 值，组合为 list
                    # TODO: 注意排序是 数字字符串化了之后，排序规则有变， 12会排在 2 之前， 是否考虑直接支持 未展平的json keypath 取值
                    elif len(value) == 1:
                        k, v = value.popitem()
                        merged_res.update({key: v})
                    elif len(value) > 1:
                        v = list(value.values())
                        merged_res.update({key: v})
                    else:
                        raise Exception('other cases is not supported.')

            # 3. 参数注入 sql: 包含全局信息 和 kv_task_params 返回的信息
            globalkv = self.task_context_bean.get_global_bean().to_dict()
            # TODO: 考虑 dict 中的 key 带有前缀，不适合写入 jinja2 的 具名模板中，task 中需加入部分 resetprefix元素
            globalkv.update(merged_res)

            # 4. 执行 sql
            jj = jinja.Template(source=self.sql)
            try:
                rendered_sql = jj.render(globalkv)
                db_res = pool.execute(rendered_sql)
                res = BaseDataBean({self.as_name: db_res})
            except Exception as e:
                res = BaseDataBean({self.as_name: None})
        else:
            raise TypeError('the data_tasks type is not supported yet.')

        result_bean = res
        return result_bean, {}
