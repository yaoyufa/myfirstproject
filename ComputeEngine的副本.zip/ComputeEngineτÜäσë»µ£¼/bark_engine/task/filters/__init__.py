"""
负责针对集合类型的 key的内容进行筛选， 同时提供组合操作
1. 基础的 filter
2. filter 之间的 and 和 or 操作

"""

"""
支持从 json dict中筛选变量, prefix 是上游 fill_context 在某个 bean 中传递过来的， 这里只考虑真实的
针对 key 的操作
1. 提取单个变量: Select(key='', as='', old_name='')
2. 提取多个变量，Array类: SelectArr(key='', as='', old_name='', regex_num=1, length=100)
3. 提取多个变量，前缀: SelectPrefix(key='', as='', old_name='', regex_num=1, length=100)


针对 value 的筛选：
1. 针对指定 key 的单个变量，提取多个变量：针对 value 的筛选，In 操作: WhereIn(key='', in=[], as='', old_name='')
2. 针对指定 key数组的变量，提取多个变量， 针对 value 的筛选，In 操作：WhereArrIn(key='', in=[], as='', old_name='')
3. 针对指定 key 的单个变量，提取多个变量：针对 value 的筛选，In 操作: WhereNotIn(key='', in=[], as='', old_name='')
4. 针对指定 key数组的变量，提取多个变量， 针对 value 的筛选，In 操作：WhereArrNotIn(key='', in=[], as='', old_name='')


3. 针对 value， DropMaxValue, DropMinValue.
"""
