"""
针对 value 的筛选： CaseWhenThen
1. 针对指定 key 的单个变量，提取多个变量：针对 value 的筛选，In 操作: WhenValueIn(key_regex='', value_in=[], value_not_in=[], regex_depth=1, doc_name=None, cache_name=None)
2. 针对指定 key数组的变量，提取多个变量， 针对 value 的筛选，In 操作：WhenValueInThen(key_regex='', value_in=[], value_not_in=[], pop_prefix=None, rename=None, doc_name=None, cache_name=None)

3. 针对 value， DropMaxValue, DropMinValue.
"""
from copy import copy
from beans.core.datainfo_bean import DataBeanType
from ..base.base_task import BarkBaseTask


class WhenValueIn(BarkBaseTask):
    def __init__(self, key_regex='', value_in=[], value_not_in=[], regex_depth=1, doc_name=None, as_cache_name=None):
        """

        :param key: key 值（不考虑 prefix）
        :param rename: 重命名为
        :param doc_name: 文档名
        :param as_cache_name:
        """
        super(WhenValueIn, self).__init__(as_cache_name=as_cache_name)

        self.key = key_regex
        self.value_in = value_in
        self.value_not_in = value_not_in
        self.regex_depth = regex_depth
        self.doc_name = doc_name

    def custom_logic(self):
        """
        :return:
        """
        pass
