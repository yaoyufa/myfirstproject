# -*- coding: utf-8 -*-
"""
@Time : 2018/4/26
@author : pengzhu 
"""

import json
import os
from config import json_setting,dataname_setting
from producer.disassemble import header_info, body_info
from data_engineer.handler.single import appinfo_data,renhang_data
from consumer import task_demos
from data_engineer.handler.cross import paycardvalid_data
from data_engineer.handler.base import cross_handler

from utils.json.flatten import flatten_json
"""
###test for parsing appinfo data_tasks####

#. get test json file
file = os.getcwd()+'/test_data/real_data_demo/app_test.json'

with open(file) as f:
    full_jsondict = json.load(f)

# 1.get biz, idno
biz, version = header_info.get_biz_version(full_jsondict)
# 2.get node data_tasks out.
node_data = full_jsondict[json_setting.node_data]
# 3. get 3 parts of data_tasks
idno, appinfo, dkeys = body_info.get_node_data(node_data)
# 4-1. distribute appinfo data_tasks
handler = appinfo_data.AppinfoHandler(biz=biz, data_name=json_setting.node_appinfo, data_role=None, idno=idno, data_tasks=appinfo)
r = handler.handle_all()
"""

"""
###test for parsing tondun data_tasks####
"""
file = os.getcwd()+'/test_data/real_data_demo/td_test.json'
with open(file) as f:
    full_jsondict = json.load(f)

# 1.get biz, idno
biz, version = header_info.get_biz_version(full_jsondict)
# 2.get node data_tasks out.
node_data = full_jsondict[json_setting.node_data]

# 3. get 3 parts of data_tasks
idno,appCode,mobile, appinfo, dkeys = body_info.get_node_data(node_data)

# 获取同盾的数据
name, role, extra_data_info = body_info.get_dataname_role(dkeys[0])
keydata = node_data[dkeys[0]]

# 同盾的数据有点特别，（key, value） 有些value是str，但里面包含的是可解析的list或json，第一步展平无法处理这种情况
# 在同盾后面Handler的时候，再次解析这些没解析出来的数据
flatted_td = flatten_json(keydata, key_prefix='td', sep='_')






