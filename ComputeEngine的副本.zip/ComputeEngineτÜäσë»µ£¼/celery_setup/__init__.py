from init.celery_setup import *

# register the user defined celery-tasks.
from consumer.task_demos import *
from consumer.task_handlers import *
from consumer.task_web_handlers import *