from flask_app import db
from sqlalchemy import ForeignKey
from sqlalchemy.orm import relationship, backref


class ProductConfig(db.Model):
    __tablename__ = 'product_config'
    id = db.Column(db.Integer, primary_key=True, unique=True,autoincrement=True)
    biz = db.Column(db.String(10), nullable=True)
    node = db.Column(db.String(20))
    role = db.Column(db.String(20))
    extra_info = db.Column(db.String(20), nullable=True)

    def __str__(self):
        out = """
        id='{}',biz='{}',node='{}',role='{}',extra_info='{}'
        """.format(str(self.id), self.biz, self.node, self.role, self.extra_info)
        return out

    # def __repr__(self):
    #     return '<ProductConfig %r %r %r %r %r>' % (self.id, self.biz, self.node, self.role, self.extra_info)
    #
    # def __unicode__(self):
    #     return self.biz


class ProductData(db.Model):
    __tablename__ = 'product_data'
    id = db.Column(db.Integer, primary_key=True, unique=True, autoincrement=True)
    # db.ForeignKey('product_config.id') 一对多的关系 一个id有多个json_data
    confid = db.Column(db.Integer, ForeignKey('product_config.id'))
    title = db.Column(db.String(200), nullable=True)
    note = db.Column(db.String(500), nullable=True)
    json_data = db.Column(db.Text, nullable=True)

    # backref 只是任意命名的反向链接的显示名称
    json_config = relationship("ProductConfig", backref=backref('json_data', order_by=id))

    def __str__(self):
        return str(self.title)

    # def __repr__(self):
    #     return '<ProductData %r>' % self.confid.biz
    #
    # def __unicode__(self):
    #     return self.confid.biz


class ProductCode(db.Model):
    __tablename__ = 'product_code'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    # db.ForeignKey('product_data.id')
    pid = db.Column(db.Integer, db.ForeignKey('product_data.id'))
    biz = db.Column(db.String(10), nullable=True)
    node = db.Column(db.String(20))
    role = db.Column(db.String(20))
    extra_info = db.Column(db.String(20), nullable=True)
    controller_code = db.Column(db.Text, nullable=True)
    dag_results = db.Column(db.Text, nullable=True)
    features = db.Column(db.Text, nullable=True)
    features_desc = db.Column(db.Text, nullable=True)
    uname = db.Column(db.String(20), nullable=True)
    ctime = db.Column(db.DateTime, nullable=True)
    status = db.Column(db.String(20), nullable=True)
    check_time = db.Column(db.DateTime, nullable=True)

    def __repr__(self):
        return '<ProductCode %r>' % self.pid

