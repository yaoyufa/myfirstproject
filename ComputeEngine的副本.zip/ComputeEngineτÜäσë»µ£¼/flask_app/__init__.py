# -*- coding: utf-8 -*-
"""
@Time : 2018/8/1
@author : pengzhu 
"""

from flask import Flask
from flask_sqlalchemy import SQLAlchemy

import flask_admin as admin

# Create application
app = Flask(__name__, static_folder='static', template_folder='templates')


# Create dummy secrey key so we can use sessions
app.config['SECRET_KEY'] = '123456790'

# Create in-memory database
# app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///credit_json_codes.sqlite'
# app.config['SQLALCHEMY_ECHO'] = True

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://sel_rc:sel_rc123@sba.mysql.db-yyfq.com:3331/rc?charset=utf8mb4'
# app.config['SQLALCHEMY_COMMIT_ON_TEARDOWN'] = True

db = SQLAlchemy(app)

# 创建一个Admin类实例并和Flask应用程序实例关联
admin_page = admin.Admin(app, name='welcome to backend database', template_mode='bootstrap3')

from .views.admin.code_admin_view import *
from .views.credit_json_view import *
from .views.ide_view import *

