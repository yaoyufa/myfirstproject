# -*- coding: utf-8 -*-
"""
@Time : 2018/8/1
@author : pengzhu 
"""

from flask_app import *

if __name__ == '__main__':

    # Create DB
    db.create_all()

    # Start app
    app.run(host='0.0.0.0', port=8888, debug=True)

