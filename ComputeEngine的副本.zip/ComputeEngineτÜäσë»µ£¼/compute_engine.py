import json
from flask import Flask, request, Response
from producer.distribute import send, send_task, send_full, send_web


app = Flask(__name__)

@app.route('/')
def hello_world():
    return 'Hello World!'


@app.route('/compute_engine', methods=['POST'])
def compute():
    if request.method == 'POST':
        json_dict = request.json
        #json_dict = json.loads(json_str, encoding='utf-8')
        r = send.action(json_dict)
        return r
    else:
        return 'use POST method to request pls.'


@app.route('/compute_engine_dags_dist', methods=['POST'])
def compute_pipe_test():
    if request.method == 'POST':
        json_dict = request.json
        r = send_task.action(json_dict)
        return r
    else:
        return 'use POST method to request pls.'


@app.route('/compute_engine_dags', methods=['POST'])
def compute_pipe():
    if request.method == 'POST':
        json_dict = request.json
        r = send_full.action(json_dict)
        return r
    else:
        return 'use POST method to request pls.'


@app.route('/compute_engine_web', methods=['POST'])
def compute_web():

    if request.method == 'POST':
        test_json = request.form['test_json']
        controller_code = request.form['controller_code']
        data_name = request.form['data_name']
        data_role = request.form['data_role']
        print("test_json --> {}".format(type(test_json)))
        print("code --> {}".format(type(controller_code)))
        print("name -->{}".format(data_name))
        print("role -->{}".format(data_role))
        feat_json = send_web.action(json.loads(test_json),controller_code,data_name, data_role)

        return Response(json.dumps(feat_json), mimetype='application/json')
    else:
        return 'use POST method to request pls.'


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
