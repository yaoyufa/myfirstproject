import os
from celery import Celery
from config import celery_config_dev
from config import celery_config_test
from config import celery_config_prod
from config import celery_config_docker
from celery.signals import after_setup_logger
from logging.handlers import TimedRotatingFileHandler
from logging import FileHandler
from utils.tools.log_tool import global_log_config

# define Celery object
app = Celery()

# Running_Mode is defined in celery_setup.sh.
try:
    running_mode = os.environ['Running_Mode']
except:
    running_mode = 'dev'

if running_mode == 'dev':
    app.config_from_object(celery_config_dev)
elif running_mode == 'test':
    app.config_from_object(celery_config_test)
elif running_mode == 'prod':
    app.config_from_object(celery_config_prod)
elif running_mode == 'docker':
    app.config_from_object(celery_config_docker)
else:
    app.config_from_object(celery_config_dev)


@after_setup_logger.connect
def after_setup_celery_logger(logger, **kwargs):
    """
    Sent after the setup of every global logger (not task loggers). Used to augment logging configuration.
    This function sets the 'celery' logger handler and formatter
    """
    global_log_config(logger, level='INFO', handler=TimedRotatingFileHandler(filename=celery_config_dev.worker_log))
    # global_log_config(logger, level='INFO', handler=FileHandler(filename=celery_config_dev.normal_log))


# @after_setup_task_logger.connect
# def after_setup_celery_task_logger(logger, **kwargs):
#     """ This function sets the 'celery.task' logger handler and formatter """
#     global_log_config(logger, level='DEBUG', handler=TimedRotatingFileHandler(filename=celery_config_dev.task_log))


if __name__ == '__main__':
    app.start()

