import cProfile
from pyprof2calltree import convert, visualize
from functools import wraps


def profile(orderby='time'):
    def performance(func):
        # @wraps(func)
        def test(*args, **kwargs):
            prof = cProfile.Profile()
            prof.enable()
            result = func(*args, **kwargs)
            prof.disable()
            # prof.print_stats(sort=orderby)
            prof.dump_stats(file='./output/profile_dump.output')
            # visualize(prof.getstats())
            # convert(prof.gresultetstats(), 'profiling_results.kgrind')
            return result
        return test
    return performance

