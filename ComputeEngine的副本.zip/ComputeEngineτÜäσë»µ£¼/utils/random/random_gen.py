"""
pseudo random

"""
import random
from numpy import random as np_random


def gen_rand(seed, num, start=0, end=999):
    """
    generate rand int which obey the uniform distribution.

    :param seed: the seed
    :param num:
    :param start:
    :param end:
    :return:
    """
    random.seed(seed)
    result = [random.randint(start, end) for i in range(num)]
    return result


def gen_rand_np(seed, num, start=0, end=999):
    """
    generate rand int which obey the uniform distribution.
    to get better performance. use numpy's random implementation.
    :param seed: the seed
    :param num:
    :param start:
    :param end:
    :return:
    """
    np_random.seed(seed)
    result = np_random.randint(start, end, size=num)
    return result


if __name__ == '__main__':
    """
    test the distribution of  generated random values.
    """
    col_num = 20
    import pandas as pd
    x = pd.DataFrame(columns=['col'+str(x) for x in range(col_num)])

    # gen and save to dataframe
    count = 0
    for times in range(100):
        for seed in range(1000):
            r = gen_rand(seed, col_num)
            x.loc[count] = r
            count += 1

    # uniform test.
    from scipy.stats import kstest, ks_2samp

    test = gen_rand_np(1, 1000)
    print(kstest(x['col0'], 'uniform'))
    ks_2samp(x['col0'], test)

    # plot .
    print('------begin plot -----\n')



