#!/usr/bin/env python3
"""
the goal of this module is flattening the hierarchy structure of json, transform to flattened key_value structure.

demo:
{
    "a": 1,
    "b": {
        "c": 2,
        "friends": [
            {
                "best": "Alice"
            },
            {
                "second": "Bob"
            },
            [5, 6, 7],
            [
                {"one": 1},
                {"two": 2}
            ]
        ]
    }
}


will be transformed to a kv structure and stored in a dict as follow:

root.b.c => 2
root.b.friends[0].best => Alice
root.b.friends[1].second => Bob
root.b.friends[2][0] => 5
root.b.friends[2][1] => 6
root.b.friends[2][2] => 7
root.b.friends[3][0].one => 1
root.b.friends[3][1].two => 2
root.a => 1
"""
import sys
import collections
import json


def get_flatten_func(kv_set):

    def traverse(path, obj, sep='.'):
        """
        Traverse the object recursively and print every path / value pairs.
        """
        cnt = 0
        if isinstance(obj, dict):
            d = obj
            for k, v in d.items():
                if isinstance(v, dict):
                    traverse(path + sep + k, v, sep)
                elif isinstance(v, list):
                    traverse(path + sep + k, v, sep)
                else:
                    kv_set[path + sep + k] = v
        if isinstance(obj, list):
            li = obj
            for e in li:
                cnt += 1
                if isinstance(e, dict):
                    traverse("{path}[{cnt}]".format(path=path, cnt=cnt), e, sep)
                elif isinstance(e, list):
                    traverse("{path}[{cnt}]".format(path=path, cnt=cnt), e, sep)
                else:
                    kv_set["{path}[{cnt}]".format(path=path, cnt=cnt)] = e
    return traverse


def flatten_json(json_dict, key_prefix='root', sep='.', sorted=False):
    """
    Process the given JSON dict.
    """
    if sorted:
        kv = collections.OrderedDict()
    else:
        kv = {}
    flatten = get_flatten_func(kv)
    flatten(key_prefix, json_dict, sep=sep)
    return kv

##############################################################################

if __name__ == "__main__":
    if len(sys.argv) == 1:
        print("Usage: json_path <input.json>")
        sys.exit(1)

    fname = sys.argv[1]

    def read_file(fpath):
        """
        Read the JSON file and return its content as a Python data_tasks structure.
        """
        with open(fpath) as f:
            return json.load(f)

    json_dict = read_file(fname)
    # flatten json
    result = flatten_json(json_dict)
    for i in result.keys():
        print(i, ' => ', result[i])

    # flatten json with sorted key
    result = flatten_json(json_dict, sorted=True)
    for i in result.keys():
        print(i, ' => ', result[i])

    # performance test
    import cProfile
    prof = cProfile.Profile()
    prof.enable()
    flatten_json(json_dict)
    prof.disable()
    prof.print_stats(sort='time')

    print("\n \n \n ")
    prof = cProfile.Profile()
    prof.enable()
    flatten_json(json_dict, sorted=True)
    prof.disable()
    prof.print_stats(sort='time')

    print("\n \n \n ")
    cProfile.run('flatten_json(json_dict, sorted=True)')


    def profile(orderby='time'):
        def performance(func):
            def test(*args, **kwargs):
                prof = cProfile.Profile()
                prof.enable()
                func(*args, **kwargs)
                prof.disable()
                prof.print_stats(sort=orderby)

            return test

        return performance


    @profile(orderby='time')
    def test(json_dict):
        return flatten_json(json_dict, sorted=True)

    test(json_dict)
