## 第三方征信的 demo 数据获取接口
    - http://192.168.49.213:18888/credit/query?id=5a448a4ef757c94dfcf34b77&collectionName=c_fraudmetrix_risk_info_data
    - http://192.168.49.213:18888/credit/query?id=5a4b27268989cb17803f2672&collectionName=c_fraudmetrix_risk_detail_data
    - 以上 url 中的 collectionName 是 MongoDB 测试环境的集合名，id 是集合中的 id

## MongoDB 的从库连接方式如下：
    主：dds-2ze8850bbf74ffd41.mongodb.rds.aliyuncs.com
    从：dds-2ze8850bbf74ffd42.mongodb.rds.aliyuncs.com
    端口：3717
    副本集：mgset-5057271
    用户：root
    密码：JG4aF2TSs12UzRq

## 我方开放给上游的接口



## 与上游API接口的定义
第一版：与高锡（上游开发人员）类似如下：


## 接口定义

{
    "version": "",
    
    "step": "",
    
    "buz_id": "",
    
    "data":
    {
        "jxl":{},
        "br":{},
        "mg":{}
    }

}




## 长坂坡（流程引擎）：
 1. 
 1. 
 1. 
 1. 
 1. 
 
 
## 开发侧DTO文档:
	1.  http://conf.op.mljr.com/pages/viewpage.action?pageId=15570187#space-menu-link-content
	2. http://gitlab.mljr.com/bee/docs
## 数据源文档：
    1. http://conf.op.mljr.com/pages/viewpage.action?pageId=12038311

参考：
1. 车金融秒拒的三方数据说明：http://conf.op.mljr.com/pages/viewpage.action?pageId=15579690
2. 大十字军全局架构： http://conf.op.mljr.com/display/RiskManagement
3. 接口 http://conf.op.mljr.com/pages/viewpage.action?pageId=15584333
4. 大十字军与君士坦丁堡的全局框架：http://conf.op.mljr.com/pages/viewpage.action?pageId=4039077
5. 支付中心接口说明： http://conf.op.mljr.com/pages/viewpage.action?pageId=9352660
