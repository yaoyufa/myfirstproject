## 代码编写规范
 - 文件模块命名规范
 - 变量命名规范
 - 


## git 提交编写规范
 - 开发前，创建一个新的 branch，在新 branch 上开发，再并入master，再提交
 - git commit 信息必须分类，并描述清楚更新内容 
 - 参考： 
   1. google angularjs 项目的Commit message 和 Change log 编写指南 ：http://www.ruanyifeng.com/blog/2016/01/commit_message_change_log.html
   2. 
   
