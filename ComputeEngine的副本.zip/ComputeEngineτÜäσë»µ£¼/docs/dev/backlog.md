# Backlog

## 框架
1. <s>支持不同 worker 连接失败的异常处理。</s> --> dongyun.fan
1. <s>支持task 失败的异常处理：处理过程中，失败，消息重发，重试次数。</s> --> dongyun.fan
1. 支持 tasks 的分层： 
   1) 针对第三方数据的 json 层， 
   2) 针对特定类型数据的衍生计算，
   3) task 内引入 异步 grouped task 
1. json 中的 null 数据的表达 bug，上游的默认值处理问题
1. 数据压缩与解压缩工具传递给 redis
1. 异步 IO 的重构: greenlet / tornado 
1. logger 支持，不同 task 不同 logger , 以便上线后，数据同步到大数据平台，以及问题定位
1. worker_shutdown_signal 的处理，判定是否会将当前正在执行的任务强制杀死，造成数据丢失。 参考[2]
1. celery 的重要异常处理 ：http://docs.celeryproject.org/en/latest/reference/celery.exceptions.html#celery.exceptions.WorkerLostError
1. mysql 连接池在各个 worker 上的管理
1. 将各个 task 分散到不同 tasks 中
1. 将 mysql 连接访问的task 单独一个 taskname
1. producer中使用 delay()后，当单个task 出现异常时的处理： code=500 ？
1. producer中改变原有delay()方式的异步调用，切换成更安全的方式，参考[8]
1. 返回 compute engine version 给上游
1. 


## 业务
1. 重构随机数生成，支持3C 和车业务的两种不同生成方案
1. 根据车金融秒拒文档生成各类特征（普通+数组）的 demo
1. json 的数组类数据的特征衍生通用代码
1. 车金融秒拒变量的各个征信源独立开发
1. 真实的批量数据，测试整体衍生逻辑
1. mysql 访问包：以支持yybgrk 的访问。便于变量的计算，如：pass_cnt_in_oneyear	同一合同最近一年通过次数
1. 特征衍生的配置化：支持简单变量的映射
1. 特征衍生的配置化：支持数组类型的变量衍生
1. 特征衍生的配置化：支持复杂类型的变量衍生，如：针对集合数据的时序变量、交叉变量。可以复用 数组类衍生结果。
1. 重构: 各个征信源的handler、task 的接口，以支持同一个征信接口、同一个角色，同时存在多个的情况（如极光地址：申请人有两个）。
1. 

## 测试
1. <s>框架在服务器上的稳定性测试</s>
1. <s>压力测试</s>
1. 测试横向扩展的吞吐率提升比例
1. 回归测试支持
1. nginx 配置：支持分流、支持 server alive的检测 ？
1. worker task的单元测试问题：启用task_always_eager模式，worker 会立刻被调用，参考[1]
1. 使用 funkload 做压力测试、负载测试 。 参考[3]

## 环境
1. 开发-提交-code review-test-测试环境-生产环境发版 管理流程
1. code review 在 gitlab 上的机制
1. 各个dev-test-prod环境上的环境变量、启动脚本、Redis/ Hbase 配置
1. 各个环境下的celery控制
1. <s>Redis消息大小限制</s>  --> dongyun.fan
1. flower monitor 时钟不同步问题，造成无法实时监控流量和性能
1. 使用docker来统一开发、测试、产品环境的一致性。
1. supervisord 的控制
1. 多节点发布 celery 的配置问题：log / worker/ service管理。参考[linode]
1. 

## Bark Engine
前提：先整理出现有 bark engine 设计中的问题，总结分析
1. define -> to -> temp
1. Broker 支持，支持多个数据库连接，包括连接池的管理： mysql 数据库
1. join的实现：left join ， key 与 value 的 join
1. 配置数据管理：分为 永久数据、临时数据、定时数据，celery task 之外的全局配置文件或数据引用的管理，支持集合格式的 k-v 配置，value更新，通过context_bean 引用 （更多使用场景参见程杰整理的 ins 文档）
1. Query 算子，专门用于查询sql数据库
1. switch case 以支持多种条件的展平 default case
1. sqlResultMapper 成 json 的mapper计算
1. task 的操作符重载
1. Filter 中对 list 做 top N 的计算支持： Atom list数据 和 dataBean 中 数组的 top N 计算支持
1. in操作的实现: 集合中数据的 has 判定
1. like 操作的实现： 如通话记录中出现某几个字（贷款关键字）的可能性（结合数据库等可更新配置的设计）。
1. count等reducer要增强，以使支持指定的key做聚合
1. Reducer 中的 ratio 比例的计算
1. SelectArrayPair()
1. Sort 支持

Refer:
1. task_always_eager模式: http://einverne.github.io/post/2017/05/celery-best-practice.html#%E4%BD%BF%E7%94%A8flower
1. worker_shutdown_signal  https://stackoverflow.com/questions/8138642/notify-celery-task-of-worker-shutdown
1. funkload test : http://funkload.nuxeo.org/usage-fl-run-bench.html
1. spec logger for each task: http://blog.mapado.com/task-specific-logging-in-celery/
1. celery task logger: http://docs.celeryproject.org/en/latest/reference/celery.app.log.html
1. celery task logger: http://docs.celeryproject.org/en/latest/userguide/tasks.html#logging
1. linode 发布多节点celery：
1. 异步task 的 callback 方式： https://github.com/celery/celery/issues/3577