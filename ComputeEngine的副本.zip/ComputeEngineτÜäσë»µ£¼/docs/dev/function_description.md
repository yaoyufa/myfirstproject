## 根据模块组件的详细数据流设计图、业务流程上三方数据优先级顺序，分解出如下技术功能说明书，还需根据优先级、项目期望、协作开发等因素、 设置版本里程碑。

## 功能说明书（# 概要设计中的重要关注点）
 1. 获得批量测试样例，测试数据。
 1. 为三方数据源各种数据类型提供提供通用计算衍生支持：字段组合、时序信息、类别统计、RFM
 1. 支持三种不同的启动环境自动配置：dev/test/product ；包括 celery 、 Redis、 TiDB、MongoDB、Hbase, email 通知
 1. 支持不同 worker 连接失败的异常处理。
 1. 支持task 失败的异常处理：处理过程中，失败，消息重发，重试次数。
 1. 支持 tasks 的分层： 1. 针对第三方数据的 json 层， 2.针对特定类型数据的衍生计算，3. task 内引入 异步 grouped task ？
 1. 支持随机数的生成，随机数符合0~999均匀分布。
 1. 支持 group、chord、chains、chunks 处理，并提供封装，方便使用
 1. 支持ack确认机制，以确保服务质量。acks_late, 以确保消息正确消费后才确认，而不是默认的开始消费就 ack
 1. 提供分布式框架的debug方法
 1. 提供 unittest 框架和样例
 1. 设计支持不同第三方数据源，提供编写模板，考虑如何解耦合，基础计算库的通用性
 1. 支持 json 数据的展平计算，或者不展平？ 提供类似 xpath 的访问
 1. 支持消息的compress 、提供compress 与 不 compress 的性能测试对比
 1. 提供异步计算的支持、提供异步计算的性能对比
 1. 提供 auto_reload 的方案或触发脚本，并测试通过
 1. 提供 flask 版的 web client, 并发多请求
 1. 不同的 worker 订阅不同的 queue
 1. 不同的 worker 支持不同层级的计算：如时序类、联系人并发实时查询类
 1. 支持 exchange  queue，routing1.key 的配置
 1. logger 支持
 1. hbase 基础库
 1. TiDB基础库
 1. flower 的 monitor 页面的时区问题
 1. 提供 HTTP perf 测试
 1.  docker
 1. http client
 1. 压力测试
 1. 性能测试


## 关于随机数
1. 均匀分布
1. 0~999
1. 每个用户20个
1. 3c业务线： 同一个用户多次申请，生成的随机数要求不一致。（为了通过率高）
1. 车业务线：  同一个用户多次申请，生成的随机数要求与上一次一致。（为了风险低）


参考：
*  Auto_reloader 的实现：http://docs.celeryproject.org/en/latest/userguide/extending.html
*  参数配置： http://docs.celeryproject.org/en/latest/userguide/configuration.html#std:setting1.task_compression