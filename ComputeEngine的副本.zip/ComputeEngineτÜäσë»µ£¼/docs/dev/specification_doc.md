
参考：
1. 各个征信状态说明： http://conf.op.mljr.com/pages/viewpage.action?pageId=20890081
1. 车金融秒拒的三方数据说明：http://conf.op.mljr.com/pages/viewpage.action?pageId=15579690
1. 大十字军全局架构： http://conf.op.mljr.com/display/RiskManagement
1. 接口 http://conf.op.mljr.com/pages/viewpage.action?pageId=15584333
1. 大十字军与君士坦丁堡的全局框架：http://conf.op.mljr.com/pages/viewpage.action?pageId=4039077
1. 支付中心接口说明： http://conf.op.mljr.com/pages/viewpage.action?pageId=9352660
1. 外部征信名命名标准：http://conf.op.mljr.com/pages/viewpage.action?pageId=20890023
1. 内部数据服务命名： http://conf.op.mljr.com/pages/viewpage.action?pageId=4758449
1. 力蕴秒拒接口：http://conf.op.mljr.com/pages/viewpage.action?pageId=12026672
