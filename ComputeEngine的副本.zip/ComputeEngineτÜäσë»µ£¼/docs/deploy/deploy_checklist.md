# 上线部署--检查表

## 内容版本、
1. 更新 config/version.py 文件中的：ce_version 字段
    1. 格式为 v_kernel_当前日期_jira需求id_commitid前6位_提测前后标志（P: 代表提测前、A 代表测试后） 
    1. demo : v_1.0_20180829_jira132_6045cd_A 
1. 代码版本封版前，检查确定 ce_version 已更新

## 代码 git tag规则、 git branch 命名规则与访问限制
1. 给git 加 tag
1. 将代码 git push 到指定ce_version命名的分支，并设置目标分支在 gitlab.com 只读，不接受 push

## 测试邮件发送
1. 提请测试Email
2. 提测申请

## 脚本启动进程正确性的检查点
1. 脚本中自带环境自动配置，prod 环境自动配置，启动时自动关闭原服务（redis 服务除外），确保服务启动时，各原服务都被强关闭。(修正脚本)
2. 检查进程存在性的脚本探测各项服务是否正常启动。

## 服务正常与否的检查点
1. 测试主副服务器5000端口的服务正常性：用 postman 测试服务正确性，检查 status 字段，检查 ce_version 字段与1中状态。
2. 测试ce.mljr.com服务的正确返回：用postman 测试服务正确性，检查 status 字段，检查 ce_version 字段与1中状态。
