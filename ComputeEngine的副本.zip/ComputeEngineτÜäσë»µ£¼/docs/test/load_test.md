# 压力测试

## 环境说明：
 - redis服务器（配置、内存、IP）：2 cores, 4G,  172.28.3.78   
 - worker 服务器：
 - producer 服务器：
 - 压测客户端：IP: 
 - 代码 milestone tag：
 
压测客户端：
## 并发100 ,总量100 在78
```[dongyun.fan@localhost computeengine]$ ab -c 100 -n 100  -T 'application/json' -p ./test_data/all_in_one_demo_1.json http://0.0.0.0:5000/compute_engine
This is ApacheBench, Version 2.3 <$Revision: 1430300 $>
Copyright 1996 Adam Twiss, Zeus Technology Ltd, http://www.zeustech.net/
Licensed to The Apache Software Foundation, http://www.apache.org/

Benchmarking 0.0.0.0 (be patient).....done


Server Software:        Werkzeug/0.14.1
Server Hostname:        0.0.0.0
Server Port:            5000

Document Path:          /compute_engine
Document Length:        112837 bytes

Concurrency Level:      100
Time taken for tests:   54.463 seconds
Complete requests:      100
Failed requests:        0
Write errors:           0
Total transferred:      11299500 bytes
Total body sent:        10336200
HTML transferred:       11283700 bytes
Requests per second:    1.84 [#/sec] (mean)
Time per request:       54462.683 [ms] (mean)
Time per request:       544.627 [ms] (mean, across all concurrent requests)
Transfer rate:          202.61 [Kbytes/sec] received
                        185.34 kb/s sent
                        387.95 kb/s total

Connection Times (ms)
              min  mean[+/-sd] median   max
Connect:        0    3   0.5      3       4
Processing:    52 25248 14753.1  21533   53399
Waiting:       52 25247 14753.2  21533   53399
Total:         55 25251 14753.5  21536   53403

Percentage of the requests served within a certain time (ms)
  50%  21536
  66%  30535
  75%  37042
  80%  40332
  90%  48899
  95%  51179
  98%  53347
  99%  53403
 100%  53403 (longest request) 
 ```
 
## 并发100，总量1000
```
[dongyun.fan@localhost computeengine]$ ab -c 50 -n 1000  -T 'application/json' -p ./test_data/all_in_one_demo_1.json http://0.0.0.0:5000/compute_engine
This is ApacheBench, Version 2.3 <$Revision: 1430300 $>
Copyright 1996 Adam Twiss, Zeus Technology Ltd, http://www.zeustech.net/
Licensed to The Apache Software Foundation, http://www.apache.org/

Benchmarking 0.0.0.0 (be patient)
Completed 100 requests
Completed 200 requests
Completed 300 requests
Completed 400 requests
Completed 500 requests
Completed 600 requests
Completed 700 requests
Completed 800 requests
Completed 900 requests
Completed 1000 requests
Finished 1000 requests


Server Software:        Werkzeug/0.14.1
Server Hostname:        0.0.0.0
Server Port:            5000

Document Path:          /compute_engine
Document Length:        112837 bytes

Concurrency Level:      50
Time taken for tests:   601.436 seconds
Complete requests:      1000
Failed requests:        0
Write errors:           0
Total transferred:      112995000 bytes
Total body sent:        103362000
HTML transferred:       112837000 bytes
Requests per second:    1.66 [#/sec] (mean)
Time per request:       30071.784 [ms] (mean)
Time per request:       601.436 [ms] (mean, across all concurrent requests)
Transfer rate:          183.47 [Kbytes/sec] received
                        167.83 kb/s sent
                        351.30 kb/s total

Connection Times (ms)
              min  mean[+/-sd] median   max
Connect:        0    0   0.3      0       2
Processing:  1057 28317 7820.1  29915   40921
Waiting:     1056 28317 7820.1  29914   40921
Total:       1058 28317 7820.1  29915   40921

Percentage of the requests served within a certain time (ms)
  50%  29915
  66%  32366
  75%  34088
  80%  34926
  90%  36928
  95%  38089
  98%  39093
  99%  39881
 100%  40921 (longest request)

```
