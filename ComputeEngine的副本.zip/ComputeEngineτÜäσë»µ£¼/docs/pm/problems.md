
## 问题
 - 确定当前传递的 json 属于长坂坡流程中的哪一步？ 是否最后一步。
 - 确定当前请求是否流程最后一步？ 
 - 数据源中所对应的不同身份在json 中需要提供标志来标识 当前数据是 哪一个角色的
 - 【已确认】UAT 测试环境是需要回跑数据的，那就需要考虑两种情况：
    - 1. 【已被否决，需要完整复现线上流程（洪伟）】hive->决策引擎：指定决策引擎流程版本，推入数据， 但是hive中的数据源于版本更新，可能存在多个计算版本，可能导致 UAT 测试的数据就有问题。
    - 2. 重跑计算引擎：指定 数据区间的数据，重跑计算引擎衍生，为了 UAT 测试，需要能够重跑整个流程，并提供策略人员修改数据。
 - 【待确认】对于返回的结果，需要考虑对现有决策引擎的向前兼容？ 因为现有决策引擎中使用到的字段名已经定下来了，现实存在。
 - 【待确认】对于返回的结果，需要考虑对现有Instinct 反欺诈引擎的向前兼容？ 因为现有决策引擎中使用到的字段名已经定下来了，现实存在。
 - 【待确认】洪伟提到：UAT测试时，需要完整复现线上的流程，君士坦丁堡要支持。
 - 【待确认】洪伟：决策引擎数据落地要完整保留 输入输出数据，并以【宽表】形式保留。
 - 【】
 
 
 # 策略与决策引擎侧需求
 关于大十字军系统，策略与决策引擎方面的UAT 测试需求说明如下：
1. 【UAT 测试环境】需支持以下两种测试流程：
    - 流程1：提供中间变量修改功能，以方便测试决策引擎。中间变量是指从原始字段加工后，准备传入决策引擎的输入变量。
提供两种可能的情况：
        1. 只涉及现有变量的决策流程的修改，
        2. 涉及新变量的决策流程的修改 的测试。
    - 流程2：提供全流程测试： 完整复现线上模型的流程，确保输入到计算引擎的结果能被测试，输入到决策引擎的数据及其结果也能被测试，至于其数据源头是mysql/Tidb、MongoDB 还需要多方进一步沟通确认。
    - 注： 实现上，可以提供一个流程switch，确定当前业务流程是从 流程1 的方式走， 还是流程2的全流程方式运行。
2. 【UAT 测试环境】需要支持：将当前测试通过的配置一键部署到线上（定时部署），避免人工再次线上操作带来的可能错误的风险。

3. 【UAT 测试环境】决策引擎的输入变量保存 建议作出优化，有如下建议：
    1. 提供输入变量的分类配置，只配置当前需要的变量
    1. 输入变量存储时，建议也分类存储到多个表，具体建议需与决策引擎方面的【@袁洪伟】沟通


 # null问题的处理
 1. 当 json 中出现原始key 对应的 value数据为 null 时，我们直接放弃这个字段，不返回，让 RME 根据 DCM 配置的默认值去生成一个新字段。
 2. 当 json 中的数组出现 null 字段时，我们依然直接放弃该字段，即使这会造成数组序号断层。让 RME 根据 DCM 配置的默认值去生成一个新字段。
 
 # bark engine 设计上的细节问题
 1. Select几个task里面，接口开放了doc_name但都没有用上，doc_name接口设计何用？    
 2. castmapper中，支持Atom和Bean，但逻辑中只覆盖了Bean的，若是Atom的会报错吧？    
 3. castmapper中，接口origin没有用上，接口to只设计了== 'int', 需要丰富其他类型转换    
 4. 对于第2点的问题，在datetimemapper中所有的task都有同样的问题，都需覆盖Atom的数据类型操作逻辑    
 5. datatimemapper中所有的task以及castmapper中的task都还有共同的一个问题： 
 当data_type为Bean时，get_data_value获取的是一个dict，dict的长度可能大于1. 
 但 task的逻辑是对dict中所有的项都做转换。 我们或许会是这样的需求，只对dict中某一项做转换。
 所以是否需要 重构支持这个需求？ 
 若是不重构优化，需要再多加一个Select一个Union才能完成在dict中修改某一项数据的需求     

 6.  注意检查所有 的mapper 类的task， 当data_type=Bean时，需不需要做重构优化，以支持指定的key做value map    
 7. Class BarkBaseTask 有以下几点：   
    * \_\_init\_\_ 初始化data最好更名为databean    
    * self.kwargs = None 是否应该改成self.kwargs = kwargs, 还是故意设置成None，在fill_context中才传入？    
    * reset_data( )  没有实现    
 8. Class Controller 中custom\_logic中 res = task.get_result() 没必要再加了吧    
 9. class RequireData 中res 未赋值先引用    
 
 # 生产者端的数据分解鲁棒性问题
 [2018-09-14 11:39:41,259] ERROR in app: Exception on /compute_engine_dags [POST]
Traceback (most recent call last):
  File "/usr/local/lib/python3.5/site-packages/flask/app.py", line 2292, in wsgi_app
    response = self.full_dispatch_request()
  File "/usr/local/lib/python3.5/site-packages/flask/app.py", line 1815, in full_dispatch_request
    rv = self.handle_user_exception(e)
  File "/usr/local/lib/python3.5/site-packages/flask/app.py", line 1718, in handle_user_exception
    reraise(exc_type, exc_value, tb)
  File "/usr/local/lib/python3.5/site-packages/flask/_compat.py", line 35, in reraise
    raise value
  File "/usr/local/lib/python3.5/site-packages/flask/app.py", line 1813, in full_dispatch_request
    rv = self.dispatch_request()
  File "/usr/local/lib/python3.5/site-packages/flask/app.py", line 1799, in dispatch_request
    return self.view_functions[rule.endpoint](**req.view_args)
  File "/code/ComputeEngine/compute_engine.py", line 38, in compute_pipe
    r = send_full.action(json_dict)
  File "/code/ComputeEngine/producer/distribute/send_full.py", line 57, in action
    result_data = distribute_and_merge(full_jsondict)
  File "/code/ComputeEngine/producer/distribute/send_full.py", line 25, in distribute_and_merge
    glb_data, map_data = GlobalFactory.build_global_ele(full_jsondict)
  File "/code/ComputeEngine/producer/beans_factory/global_factory.py", line 45, in build_global_ele
    node_data = data[json_setting.node_data]
TypeError: string indices must be integers