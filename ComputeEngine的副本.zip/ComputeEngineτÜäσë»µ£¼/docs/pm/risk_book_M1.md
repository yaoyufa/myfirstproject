# 风险登记册

## 架构全局问题
 1. celery + Flask 稳定性问题: 持续运行两周的50/s 的请求测试
 1. 上游数据格式异常
 1. Redis消息大小限制2M ？ 512M ，参考[1].
 1. Redis 消息中间件的内存消耗量，在消费后是否会及时删除请求+数据结果。
 1. celery 热更新的两种方式，其中--autoreload方式已被废弃，稳定性问题
 1. celery inotify 方式的时耗
 1. 针对本应用进行load test： 持续加大直到应用崩溃
 1. celery worker 内容单元测试不方便，debug不方便的问题解决？ 启用task_always_eager模式，worker 会立刻被调用，参考[2]
 1. Hbase 稳定性问题；测试环境、产品环境-->至少提前两周问明清
 1. log 供大数据平台捞取的注意事项

## 零碎问题
 1. gunicorn 的异步支持问题
 1. json展平后，key长度可能造成落地到关系型数据库的列名长度风险问题，mysql:64, hive长度: 128 . 参考【3】
 
## 其他问题
1. 间隔一段时间不给Celery 发送message，再次通过postman发送测试json数据时，出现server无法响应的问题，见截图    
	 ![github](https://raw.githubusercontent.com/StutuPig/images/master/postman.jpg)    


## 衍生数据计算方式不明确问题    
####同盾信息加工变量    

|     决策变量名     | 变量名 |             变量说明                |
| ------------ | --- | ------------------------------- |
| td_id_webloan_blk_overdue_cnt |  身份证命中网贷黑名单_逾期天数 | 默认值-9999和-1，rule_name=身份证命中网贷黑名单，rule_detail里"逾期天数"出现后的数字 |
| td_mob_webloan_blk_overdue_cnt     |  手机号命中网贷黑名单_逾期天数 | 默认值-9999和-1，rule_name=手机号命中网贷黑名单，rule_detail里"逾期天数"出现后的数字 |       |
| b003_credit_cnt |  B003_失信次数 | 默认值-9999和-1，借款人身份证命中全局失信证据库（失信次数） |
| b004_credit_cnt     |  B004_失信次数 | 默认值-9999和-1，借款人手机号命中全局失信证据库（失信次数） |       |

 "身份证命中网贷黑名单" 与 "手机号命中网贷黑名单" 这两个变量的变量说明与其实现的Java Code逻辑不一致，且Java Code逻辑计算出来的值与生存库中的数据也匹配不上。    
 
 具体查询逻辑如下：    
 ```
** 生产库 四个字段值 **  
select seq_id,
td_id_webloan_blk_overdue_cnt,
td_mob_webloan_blk_overdue_cnt,
b003_credit_cnt,
b004_credit_cnt 
from t_fraudmetrix_mid_val
where td_id_webloan_blk_overdue_cnt!=-9999 
order by createTime desc
limit 100
;

** 生产库 同盾明显 ** 
-- td_id_webloan_blk_overdue_cnt
-- 默认值-9999和-1，rule_name=身份证命中网贷黑名单，rule_detail里"逾期天数"出现后的数字
select * from t_fraudmetrix_detail where seq_id='1527027084473390S180F4F295600703' and rule_name like '%身份证命中网贷黑名单%';

-- td_mob_webloan_blk_overdue_cnt
-- 默认值-9999和-1，rule_name=手机号命中网贷黑名单，rule_detail里"逾期天数"出现后的数字
select * from t_fraudmetrix_detail where seq_id='1527224778664040S427A099A9155003' and rule_name like '%手机号命中网贷黑名单%';

-- b003_credit_cnt 失信次数
-- 默认值-9999和-1，借款人身份证命中全局失信证据库（失信次数）
select * from t_fraudmetrix_detail where seq_id='1527224778664040S427A099A9155003' and rule_name like '%身份证命中全局失信证据库%';

-- b004_credit_cnt 失信次数
-- 默认值-9999和-1，借款人手机号命中全局失信证据库（失信次数）
select * from t_fraudmetrix_detail where seq_id='1527027084473390S180F4F295600703' and rule_name like '%手机号命中全局失信证据库%';


```
 
 Refer:
 1. https://redis.io/topics/data-types
 1. http://einverne.github.io/post/2017/05/celery-best-practice.html#%E4%BD%BF%E7%94%A8flower
 1. https://www.cloudera.com/documentation/cdh/5-0-x/Impala/Installing-and-Using-Impala/ciiu_schema_objects.html
 