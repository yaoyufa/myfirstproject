# -*- coding: utf-8 -*-
"""
@Time : 2018/8/7
@author : pengzhu
"""
import logging

from celery.utils.log import get_task_logger
from consumer.safe_task import SafeTask

from init.celery_setup import *
from beans.core.datainfo_bean import SingleDataBean, MultiDataBean
from bark_engine.auxi.context_bean import ContextBean
from beans.core.requirement_bean import RequirementBean, ActionType
from bark_engine.auxi.cache import CacheManager
from bark_engine.dag.dag import Dag
from beans.globalinfo.globalinfo_bean import GlobalBean
from beans.globalinfo.appinfo_bean import AppInfoBean
from beans.globalinfo.bizinfo_bean import BizInfoBean
from producer.beans_factory.global_factory import GlobalFactory
from config import json_setting

# 保证exec在解析代码时，不会找不到相应的task
from bark_engine import *

task_soft_time_limit = 60  # 60 seconds
task_max_retries = 0  # 0 times

"""
Note that Loggers are never instantiated directly, but always through the module-level function logging.getLogger(name).
Multiple calls to getLogger() with the same name will always return a reference to the same Logger object.
"""
task_log = get_task_logger("celery_task")
task_log.selLevel = logging.ERROR


def exec_code(controller_code):
    loc = locals()
    exec(compile(controller_code, '<string>', mode='exec'))
    controller = loc['controller']
    return controller


def distribute(full_jsondict, controller_code,action_type='Single', **kwargs):
    result = {}
    debug_info = ''

    # get global data info and detail data info
    glb_data, map_data = GlobalFactory.build_global_ele(full_jsondict)

    # get kwargs
    if action_type == 'Single':
        data_name = kwargs.get('data_name')
        data_role = kwargs.get('data_role')
        if data_name is None or data_role is None:
            raise Exception("when Single task, you must input data_name and data_role through kwargs")
        else:
            key_prefix = data_name + json_setting.separator + data_role
            if key_prefix in map_data.keys():
                key_data = map_data.get(key_prefix)
                result, debug_info = handle(target=data_name,
                                            role=data_role,
                                            glb_data=glb_data,
                                            key_data=key_data,
                                            controller_code=controller_code,
                                            action_type='Single')

                # callbacks_list[key_prefix] = result

            else:
                raise Exception("{}_{} not in your test json data.".format(data_name, data_role))
    elif action_type == 'Cross':
        # # throw cross-task 必须指定要做交叉衍生的数据源
        # for example ,kwargs={'new_name':'pcv','new_role':'mt','cross_nodes':['pc','appinfo_cn']}
        new_name = kwargs.get('new_name')
        new_role = kwargs.get('new_role')
        cross_nodes = kwargs.get('cross_nodes')
        if new_name is None or new_role is None or cross_nodes is None:
            raise Exception("could not do Cross, you must input new_name, new_role, cross_nodes through kwargs.")
        else:
            if set(cross_nodes).issubset(map_data.keys()):
                result, debug_info = handle(target=new_name,
                                            role=new_role,
                                            glb_data=glb_data,
                                            key_data=[v for k, v in map_data.items()
                                                      if k in cross_nodes
                                                      ],
                                            controller_code=controller_code,
                                            action_type='Cross')

                # callbacks_list[new_name] = result

            else:
                raise Exception("your input Cross nodes through kwargs is not the subsets of map_data.keys().")

    else:
        raise Exception("action_type must in ['Single','Cross'].")

    return result, debug_info


@app.task(bind=True, name="web_dags", max_retries=task_max_retries, soft_time_limit=task_soft_time_limit,
          base=SafeTask)
def web_dags(self, data_info, controller_code, action_type='Single', **kwargs):
    """

    :param self:
    :param glb_data:
    :param data_info: (data_name,data_role, extra_data_info,data)
    :return:
    """

    # 1. 获取 full json
    # 2. 组装 global bean
    # 3. 分解各个 data, send data
    # 4. 逐个解析，计算.
    # 5. 合并结果，返回
    res, debug_value = distribute(data_info, controller_code, action_type, **kwargs)
    return {'results': res, 'debug_info': debug_value}


def handle(target, role, glb_data, key_data, controller_code, action_type='Single'):
    target_name = target
    target_role = role

    dag = Dag()

    data_bean = None
    context_bean = None
    controller = None

    biz = glb_data.get('biz')
    version = glb_data.get('version')
    idno = glb_data.get('idno')
    appCode = glb_data.get('appcode')
    mobile = glb_data.get('mobile')

    if action_type == 'Single':
        data_name = key_data.get('data_name')
        data_role = key_data.get('data_role')
        extra_data_info = key_data.get('extra_data_info')
        data = key_data.get('data')
        data_bean = SingleDataBean(data_name=data_name, data_role=data_role,
                                   ext_info=extra_data_info, data=data)

        context_bean = ContextBean(cachemgr=CacheManager(),
                                   globalbean=GlobalBean(bizinfo=BizInfoBean(biz_type=biz, biz_prod=version),
                                                         appinfo=AppInfoBean(appcode=appCode, idtype=1,
                                                                             idno=idno, mobile=mobile)),
                                   requirementbean=RequirementBean(action_type=ActionType.Single, new_name=target_name),
                                   **{'debug': True}
                                   )

    elif action_type == 'Cross':
        data_bean = MultiDataBean()
        size = len(key_data)
        for i in range(size):
            data_name = key_data[i].get('data_name')
            data_role = key_data[i].get('data_role')
            extra_data_info = key_data[i].get('extra_data_info')
            data = key_data[i].get('data')

            data_bean.append_databean(
                SingleDataBean(data_name=data_name, data_role=data_role,
                               ext_info=extra_data_info, data=data)
            )
        #TODO : 做交叉时，需指明哪个征信源为主征信源，将此征信源的data_role 作为RequirementBean的role_name
        context_bean = ContextBean(cachemgr=CacheManager(),
                                   globalbean=GlobalBean(bizinfo=BizInfoBean(biz_type=biz, biz_prod=version),
                                                         appinfo=AppInfoBean(appcode=appCode, idtype=1,
                                                                             idno=idno, mobile=mobile)),
                                   requirementbean=RequirementBean(action_type=ActionType.Cross,
                                                                   new_name=target_name,
                                                                   role_name=target_role),
                                   **{'debug': True}
                                   )

    dag.fill(data_bean, context_bean)

    dag.controller = exec_code(controller_code)

    try:
        dag.action()
        res = dag.get_result()
        debug_info = dag.get_debug_info()
        return res, debug_info
    except:
        return {}, None

if __name__ == '__main__':


    controller_code = """controller = Pipeline(
        FlattenMapper(),
        Select(key='mongodbId', rename='mongodbId')
        # Pipeline(
        #     RequireCache(dataname='mg_flattened'),
        #     Union(
        #         Select(key='mongodbId', rename='mongodbId'),
        #         Select(key='createTime', rename='createTime'),
        #         Select(key='id', rename='id', doc_name=''),
        #         Pipeline(
        #             Select(key='success', rename='returnStatus'),
        #             ValueMapper(kv_map={True: 1, False: -1})
        #         ),
        #         Select(key='blknamewithidcard', rename='blknamewithidcard'),
        #         Select(key='blknamewithphone', rename='blknamewithphone'),
        #         Pipeline(
        #             Select(key='blkcategory', rename='blkcategory'),
        #             StringMapper(func=lambda x: x[:20] if len(x) > 20 else x)
        #         )
        #     )
        # 
        # )
    )
    """

    file = '/Users/pengzhu/Documents/mljr/ComputeEngine/test_data/web_demo_data.json'

    import json
    with open(file) as f:
        full_jsondict = json.load(f)

    config = {'data_name': 'mg',
              'data_role': 'at'}

    action_type = 'Single'

    result = web_dags(full_jsondict, controller_code, action_type, **config)

    print(result)



