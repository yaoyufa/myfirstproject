# -*- coding: utf-8 -*-
"""
@Time : 2018/8/9
@author : pengzhu 
"""
from .dataname_setting import *

action_type_single = 'Single'
action_type_cross = 'Cross'

TYPE_MAPPING = {
            node_random: action_type_single,

            node_bairongsl: action_type_single,

            node_miguanbl: action_type_single,

            node_renhang: action_type_single,

            node_gzt: action_type_single,

            node_bonne: action_type_single,

            node_tongdun: action_type_single,

            node_appinfo: action_type_single,

            node_paycenter: action_type_single,

            node_paycenter_cross: action_type_cross,

            node_miaoju: action_type_single
} 