## Broker settings.
broker_url = 'redis://redis_service:6379/'

# List of modules to import when the Celery worker starts.
#imports = ('myapp.tasks',)

## Using the database to store task state and results.
result_backend = 'redis://redis_service:6379/'


result_expires = 120

# 并发worker数
#worker_concurrency = 4

# 每个worker最多执行万100个任务就会被销毁，可防止内存泄露
worker_max_tasks_per_child = 1000

task_annotations = {'tasks.add': {'rate_limit': '10/s'}}

# task or result could be serialized to json (default), pickle, yaml, msgpack, or any custom serialization methods that have been registered with kombu.serialization.registry
task_serializer = 'json'

# task or result Can be compressed as gzip, bzip2
CELERY_TASK_COMPRESSION = 'gzip'

# UTC
CELERY_ENABLE_UTC = False

# TIMEZone
TIMEZONE = 'Asia/Shanghai'

# Enables error emails.
CELERY_SEND_TASK_ERROR_EMAILS = True

# Name and email addresses of recipients
ADMINS = (
    ("pz", "zhu.peng@mljr.com"),
    ("dongyun", "dongyun.fan@mljr.com"),
)

# The format to use for log messages.
WORKER_LOG_FORMAT = '[%(asctime)s: %(levelname)s/%(processName)s] %(message)s'

# The format to use for log messages logged in tasks. Can be overridden using the --loglevel option to celeryd.
WORKER_TASK_LOG_FORMAT = '[%(asctime)s: %(levelname)s/%(processName)s][%(task_name)s(%(task_id)s)] %(message)s'

# time rotate log file
task_log = './output/task.log'

# worker log file
worker_log = './output/worker.log'

# normal log file
normal_log = './output/normal.log'




