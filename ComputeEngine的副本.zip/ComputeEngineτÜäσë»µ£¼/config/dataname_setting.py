# refer: http://conf.op.mljr.com/pages/viewpage.action?pageId=20890023

# 随机数 node for random values
node_random = 'RANDOM'

# 百荣Black list
node_bairongsl = 'brBL'

# 蜜罐Black list
node_miguanbl = 'jxlMgBL'

# 自有 华昌的人行征信报告
node_renhang = 'hcPR'

# 国政通爰金整合
node_gzt = 'zhGyBL'

# 抱抱的力蕴重复API
node_bonne = 'BDLY'

# 同盾贷前
node_tongdun = 'tdPlCF'

# AppInfo
node_appinfo = 'APPINFO'

# 支付中心：内部 API： 看征信中心内部数据的文档
node_paycenter = 'zfBCR'

node_paycenter_cross = 'zfBCRc'

# 秒拒: RC 表示风控；其中秒拒记录用 RF : Rapid Filter
node_miaoju = 'RCRF'
