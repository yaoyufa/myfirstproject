# 此处的配置仅影响 sql 中需注入的变量命名，与 json 中的 key 无关，请注意，不要轻易改
key_appcode = "appcode"
key_idtype = "idtype"
key_idno = "idno"
key_mobile = "mobile"

key_biztype = "biz_type"
key_bizprod = "biz_prod"

key_sep = 'sep'
