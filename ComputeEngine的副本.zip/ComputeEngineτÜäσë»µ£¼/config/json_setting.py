"""
 defines the data_tasks nodes' key name.

"""
# the sep of  role and data_tasks name in keys
separator = '_'

# global key name in json.
node_biz = 'biz'
node_version = 'version'
node_code = 'code'
#node_data = 'data_tasks'
node_data = 'data'
node_ce_version = 'ce_version' # compute engine: ce
node_dag_status = 'dag_status'
node_dag_status_success = 200
node_dag_status_fail = 500

# app info node name.
node_applicant = 'applicant'
node_idtype = 'idType'
node_idno = 'idno'
node_appcode = 'appCode'
node_mobile = 'mobile'


# role name settings only for key distribution.
role_applicant = 'at'
role_spouse = 'mt'
role_guarantor = 'gt'
role_contract_number = 'cn'
