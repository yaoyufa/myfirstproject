
ce_version = 'V0.1_2018-11-09_5ba60a1c'
