# 数据接口说明文档

## 支付中心
1. 支付中心三、四要素权鉴： http://conf.op.mljr.com/pages/viewpage.action?pageId=12029521
1. http://conf.op.mljr.com/pages/viewpage.action?pageId=12029535

## 秒拒接口
1. 力蕴秒拒接口: http://conf.op.mljr.com/pages/viewpage.action?pageId=12026672
