# -*- coding:utf-8 -*-

from producer.beans_factory.global_factory import GlobalFactory
from bark_engine.auxi.context_bean import ContextBean
from beans.core.datainfo_bean import SingleDataBean
from bark_engine.auxi.cache import CacheManager
from beans.globalinfo.globalinfo_bean import GlobalBean
from beans.globalinfo.appinfo_bean import AppInfoBean
from beans.globalinfo.bizinfo_bean import BizInfoBean
from beans.core.requirement_bean import RequirementBean, ActionType
from bark_engine.task.mappers.jsonmapper import JsonMapper
from bark_engine.task.mappers.resetprefix import ResetPrefix
import json
import platform
import time
import os
import numpy as np
## 测试用例json


class Test_json():
    DEBUG = False
    DATA_NAME = 'td_at'

    @staticmethod
    def replace_fun(dic):
        for key in dic.keys():
            value = dic[key]
            if isinstance(value,'str'):
                value = value.replace(':',';')
                dic.update({key:value})
        return dic

    @classmethod
    def setup_class(cls):
        ## load json
        if 'Linux' in platform.system():
            file = '../test_data/all_in_one_demo_1.json'
        else:
            file = 'D:\\ComputeEngine\\ComputeEngine\\test_data\\all_in_one_demo_1.json'

        with open(file, encoding='utf-8') as f:
            content = f.readlines()
            td_str = ''.join(content)
            full_jsondict = json.loads(td_str, encoding='utf-8')

        cls.glb_data,cls.map_data = GlobalFactory.build_global_ele(full_jsondict)

        ## specifical glb_data information
        cls.biz = cls.glb_data.get('biz')
        cls.version = cls.glb_data.get('version')
        cls.idno = cls.glb_data.get('idno')
        cls.appCode = cls.glb_data.get('appcode')
        cls.mobile = cls.glb_data.get('mobile')

        ## specifical map_data information
        cls.data_info = cls.map_data.get(cls.DATA_NAME)
        cls.data_name = cls.data_info.get('data_name')
        cls.data_role = cls.data_info.get('data_role')
        cls.extra_data_info = cls.data_info.get('extra_data_info')
        cls.data = cls.data_info.get('data')

        print('setup_class()',cls.__name__)
        return cls


    @classmethod
    def teardown_class(cls):
        print('teardown_class()',cls.__name__)



    def setup_method(self,method):
        ## data_bean context_bean
        self.data_bean = SingleDataBean(data_name=self.data_name,
                                   data_role=self.data_role,
                                   ext_info=self.extra_data_info,
                                   data=self.data)

        self.context_bean = ContextBean(cachemgr=CacheManager(),
                                   globalbean=GlobalBean(bizinfo=BizInfoBean(biz_type=self.biz, biz_prod=self.version),
                                                         appinfo=AppInfoBean(appcode=self.appCode, idtype=1,
                                                                             idno=self.idno, mobile=self.mobile)),
                                   requirementbean=RequirementBean(action_type=ActionType.Single,new_name="reset"),
                                   debug=self.DEBUG)

        print('setup_method() ',method.__name__)
        self.post_setup()

    def post_setup(self):
        pass

    def teardown_method(self,method):
        print('teardown_class()',method.__name__)

    def test_broker(self):
        pass

    def test_filter_Select(self,key_regex = 'mainData'):
        SR = Select(key_regex=key_regex)
        SR.fill_context(data=self.data_bean,context_bean=self.context_bean)
        SR.action()
        SR_result = SR.get_result()
        assert '"final_score":0' in SR_result.get_data_value()[key_regex]['detailJson']

    def test_filter_SelectPrefix(self,key_regex = 'mainData'):
        SP = SelectPrefix(key_regex=key_regex)
        SP.fill_context(data=self.data_bean,context_bean=self.context_bean)
        SP.action()
        SP_result = SP.get_result()
        assert '"final_score":0' in SP_result.get_data_value()[key_regex]['detailJson']

    def test_filter_SelectRegex(self,key_regex = 'mainData'):
        SR = SelectRegex(key_regex=key_regex)
        SR.fill_context(data=self.data_bean,context_bean=self.context_bean)
        SR.action()
        SR_result = SR.get_result()
        assert '"final_score":0' in SR_result.get_data_value()[key_regex]['detailJson']

    def test_mappers_jsonmapper(self):
        JM = JsonMapper(key_regex='username')
        JM.fill_context(data=self.data_bean,context_bean=self.context_bean)
        JM.action()
        JM_result = JM.get_result()
        assert '"final_decision":"Accept"' in JM_result.get_data_value()['mainData']['detailJson']

    def test_mappers_FlattenMapper(self):
        FM = JsonMapper(key_regex='username')
        FM.fill_context(data=self.data_bean,context_bean=self.context_bean)
        FM.action()
        JM_result = FM.get_result()
        assert '"final_decision":"Accept"' in JM_result.get_data_value()['mainData']['detailJson']

    def test_mapper_ResetPrefix(self):
        ## 需要对context_bean中的requirementbean进行设置
        RP = ResetPrefix()
        RP.fill_context(data=self.data_bean,context_bean=self.context_bean)
        RP.action()
        RP_result = RP.get_result()
        assert 'reset_None_s' in RP_result.get_data_value().keys()


    def test_mapper_StringMapper(self):
        VM = StringMapper(func=self.replace_fun())
        VM.fill_context(data=self.data_bean,context_bean=self.context_bean)
        VM.action()
        VM_result = VM.get_result()
        assert '\'creditCode\'; \'300\'' in VM_result.get_data_value()['mainData']['detailJson']

    def test_mapper_ValueMapper(self):
        VM = ValueMapper(kv_map={'200':'300'})
        VM.fill_context(data=self.data_bean,context_bean=self.context_bean)
        VM.action()
        VM_result = VM.get_result()
        assert '\'creditCode\': \'300\'' in VM_result.get_data_value()['mainData']['detailJson']

    def test_mapper_CastMapper(self):
        CM = CastMapper(to='int')
        CM.fill_context(data=self.data_bean,context_bean=self.context_bean)
        CM.action()
        CM_result = CM.get_result()


    def test_mapper_DateTimeMapper(self):
        ## 进行类型转化后，不适合抛出异常
        DM = DateTimeMapper(src_fmt='%m/%d/%y', dst_fmt='%Y-%m-%d')
        self.data_bean.data = {}
        DM.fill_context(data=self.data_bean,
                        context_bean=self.context_bean)
        DM.action()
        DM_result = DM.get_result()
        assert DM_result.get_data_value() == {}


    def test_mapper_DateTimeFormatterMapper(self):
        DFM = DateTimeFormatterMapper(dst_fmt='%Y-%m-%d', src_type='datetime')
        self.data_bean.data = None
        DFM.fill_context(data=self.data_bean,
                         context_bean=self.context_bean)
        DFM.action()
        DFM_result = DFM.get_result()
        assert DFM_result.get_data_value() == {}

    def test_mapper_FromUnixTimeMapper(self):
        FUT = FromUnixTimeMapper()
        self.data_bean.data = {}
        FUT.fill_context(data= self.data_bean,
                         context_bean= self.context_bean)
        FUT.action()
        FUT_result = FUT.get_result()
        assert FUT_result.get_data_value() == {}

    def test_mapper_ToUnixTimeMapper(self):
        TUT = FromUnixTimeMapper()
        self.data_bean.data = {'a':None}
        TUT.fill_context(data= self.data_bean,
                         context_bean=self.context_bean)
        TUT.action()
        TUT_result = TUT.get_result()
        assert TUT_result.get_data_value() == {}


