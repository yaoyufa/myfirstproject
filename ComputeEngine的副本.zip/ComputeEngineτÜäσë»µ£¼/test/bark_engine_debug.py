"""bark_engine_debug
Usage:
bark_engine_debug.py  <data_name>  <cross_or_single>

Options:
  -h --help     Show this screen.
  --version     Show version.

demos:
1. bark_engine_debug.py   td_at  single
2. bark_engine_debug.py   td_at  cross

@author: fan
"""

from docopt import docopt
import json
from config import dataname_setting
from beans.core.requirement_bean import RequirementBean, ActionType
from beans.globalinfo.globalinfo_bean import GlobalBean
from beans.globalinfo.appinfo_bean import AppInfoBean
from beans.globalinfo.bizinfo_bean import BizInfoBean
from config import json_setting
from data_engineer.data_controllers.appinfo_controller import AppInfoCtl
from data_engineer.data_controllers.bonne_controller import BonneCtl
from data_engineer.data_controllers.br_controller import BaiRongCtl
from data_engineer.data_controllers.cr_controller import RenHangCtl
from data_engineer.data_controllers.default_controller import DefaultCtl
from data_engineer.data_controllers.gztyj_controller import GztCtl
from data_engineer.data_controllers.mg_controller import MiGuanCtl
from data_engineer.data_controllers.mj_controller import MiaoJuCtl
from data_engineer.data_controllers.pc_controller import PayCenterCtl
from data_engineer.data_controllers.randoms_controller import RandomsCtl
from data_engineer.data_controllers.td_controller import TongDunCtl
from producer.beans_factory.global_factory import GlobalFactory
# test celery task functionality
from bark_engine.dag.dag import Dag
from beans.core.datainfo_bean import SingleDataBean, MultiDataBean
from bark_engine.auxi.context_bean import ContextBean
from bark_engine.auxi.cache import CacheManager
from test.db_controller_test import DBCtl
from bark_engine.auxi.conn_pool import DBPoolManager
from bark_engine.config.conn_url import *

# shell script options supported.
arguments = docopt(__doc__, version='bark engine')
spec_data_name = arguments['<data_name>']
spec_is_cross = arguments['<cross_or_single>']
print('arg1:', spec_data_name, ", arg2: ", spec_is_cross)

# Done: remember to delete
# spec_data_name = 'fahaishixin_at'
# spec_is_cross = 'single'

db_pool = DBPoolManager().pools

file = './test_data/all_in_one_demo_1.json'
with open(file, encoding='utf-8') as f:
    content = f.readlines()
    td_str = ''.join(content)
    full_jsondict = json.loads(td_str, encoding='utf-8')

callbacks_list = []

# 1. get global data info and detail data info
glb_data, map_data = GlobalFactory.build_global_ele(full_jsondict)


# 2. unpack global data, prepare for ContextBean.
biz = glb_data.get('biz')
version = glb_data.get('version')
idno = glb_data.get('idno')
appCode = glb_data.get('appcode')
mobile = glb_data.get('mobile')

# 3. get specified data
if spec_is_cross == 'cross':
    action_type = 'Cross'
else:
    action_type = 'Single'

target_name, data_info = None, None
if action_type is "Single":
    target_name = map_data.get(spec_data_name).get('data_name')
    data_info = map_data.get(spec_data_name)

    # 3. init data bean, context bean
    # 3.1. unpack datainfo, prepare for DataBean.
    data_name = data_info.get('data_name')
    data_role = data_info.get('data_role')
    extra_data_info = data_info.get('extra_data_info')
    data = data_info.get('data')

    data_bean = SingleDataBean(data_name=data_name,
                               data_role=data_role,
                               ext_info=extra_data_info, data=data)

    context_bean = ContextBean(cachemgr=CacheManager(),
                               globalbean=GlobalBean(bizinfo=BizInfoBean(biz_type=biz, biz_prod=version),
                                                     appinfo=AppInfoBean(appcode=appCode, idtype=1,
                                                                         idno=idno, mobile=mobile)),
                               requirementbean=RequirementBean(action_type=ActionType.Single),
                               dbpool= db_pool,
                               debug=True
                               )

else:
    # cross data, which contains multi data bean.
    if spec_data_name.startswith('pc'):
        data_info = [v for k, v in map_data.items()
                     if v.get('data_name') in (dataname_setting.node_appinfo, dataname_setting.node_paycenter)
                    ]
        target_name = "pcv"
        target_role = json_setting.role_applicant
    else:
        raise Exception("Cross feature generation, Not supported yet...")

    data_bean = MultiDataBean()
    size = len(data_info)
    for i in range(size):
        data_name = data_info[i].get('data_name')
        data_role = data_info[i].get('data_role')
        extra_data_info = data_info[i].get('extra_data_info')
        data = data_info[i].get('data')

        data_bean.append_databean(
            SingleDataBean(data_name=data_name, data_role=data_role,
                           ext_info=extra_data_info, data=data)
        )

    context_bean = ContextBean(cachemgr=CacheManager(),
                               globalbean=GlobalBean(bizinfo=BizInfoBean(biz_type=biz, biz_prod=version),
                                                     appinfo=AppInfoBean(appcode=appCode, idtype=1,
                                                                         idno=idno, mobile=mobile)),
                               requirementbean=RequirementBean(action_type=ActionType.Cross,
                                                               new_name=target_name, role_name=target_role),
                               dbpool=db_pool,
                               debug=True
                               )


# 4. pick specified controller.
controller = None
if target_name == dataname_setting.node_random:
    controller = RandomsCtl().controller

elif target_name == dataname_setting.node_appinfo:
    controller = AppInfoCtl().controller

elif target_name == dataname_setting.node_gzt:
    controller = GztCtl().controller

elif target_name == dataname_setting.node_miguanbl:
    controller = MiGuanCtl().controller

elif target_name == dataname_setting.node_bairongsl:
    controller = BaiRongCtl().controller

elif target_name == dataname_setting.node_tongdun:
    controller = TongDunCtl().controller

elif target_name == dataname_setting.node_renhang:
    controller = RenHangCtl().controller

elif target_name == dataname_setting.node_miaoju:
    controller = MiaoJuCtl().controller
elif target_name == dataname_setting.node_bonne:
    controller = BonneCtl().controller

elif target_name == dataname_setting.node_paycenter_cross:
    controller = PayCenterCtl().controller

else:
    controller = DBCtl().controller

# 5. create dag
dag = Dag()
dag.fill(data_bean, context_bean)
dag.controller = controller
dag.action()
print(dag.get_result())
