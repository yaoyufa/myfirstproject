# -*- coding: utf-8 -*-
"""
@Time : 2018/4/19
@author : pengzhu 
"""

import pytest
from assertpy import assert_that

from utils.json.flatten import flatten_json

"""

测试输入：
    demo:
    {
        "a": 1,
        "b": {
            "c": 2,
            "friends": [
                {
                    "best": "Alice"
                },
                {
                    "second": "Bob"
                },
                [5, 6, 7],
                [
                    {"one": 1},
                    {"two": 2}
                ]
            ]
        }
    }
    
测试单元函数traverse
     
"""


tjson = [{'a':1},{'a':''},{'a':None},{'a.b','c.d'},
          {"b": {"c": 2,"friends": [
                                    {
                                        "best": "Alice"
                                    },
                                    {
                                        "second": "Bob"
                                    },
                                    [5, 6, 7],
                                    [
                                        {"one": 1},
                                        {"two": 2}
                                    ]
            ]}
           },
          [['a','b'],{'a1':'b1'}]
          ]

@pytest.fixture(scope="function",params=tjson)
def in_json(request):
    return request.param


def traverse(path, obj, sep='.',kv_set = {}):
    """
    Traverse the object recursively and print every path / value pairs.
    """
    cnt = -1
    if isinstance(obj, dict):
        d = obj
        for k, v in d.items():
            if isinstance(v, dict):
                traverse(path + sep + k, v)
            elif isinstance(v, list):
                traverse(path + sep + k, v)
            else:
                kv_set[path + sep + k] = v
    if isinstance(obj, list):
        li = obj
        for e in li:
            cnt += 1
            if isinstance(e, dict):
                traverse("{path}[{cnt}]".format(path=path, cnt=cnt), e)
            elif isinstance(e, list):
                traverse("{path}[{cnt}]".format(path=path, cnt=cnt), e)
            else:
                kv_set["{path}[{cnt}]".format(path=path, cnt=cnt)] = e
    return kv_set



def test_traverse(in_json):
    """
    测试用例 - 测试 traverse() 函数
    :param in_params:
    :return:
    """

    kv_set = traverse('root', in_json)
    if in_json=={'a':1}:
        assert_that(kv_set).is_not_none()
        assert_that(kv_set).is_equal_to({'root.a':1})
    elif in_json=={'a':''}:
        assert_that(kv_set).is_not_none()
        assert_that(kv_set).is_equal_to({'root.a': ''})
    elif in_json=={'a':None}:
        assert_that(kv_set).is_not_none()
        assert_that(kv_set).is_equal_to({'root.a': None})
    elif in_json =={'a.b':'c.d'}:
        assert_that(kv_set).is_not_none()
        assert_that(kv_set).is_equal_to({'root.a.b': 'c.d'})
    elif in_json=={"b": {"c": 2,"friends": [
                                    {
                                        "best": "Alice"
                                    },
                                    {
                                        "second": "Bob"
                                    },
                                    [5, 6, 7],
                                    [
                                        {"one": 1},
                                        {"two": 2}
                                    ]
            ]}
           }:
        assert_that(kv_set).is_not_none()
    elif in_json==[['a','b'],{'a1':'b1'}]:
        assert_that(kv_set).is_not_none()


def test_flatten_json():
    """
    test flatten.py
    :return:
    """
    a = flatten_json(json_dict={'a':1},sorted=True)
    b = flatten_json(json_dict={'a':1},sorted=False)
    assert_that(a).is_instance_of(list)
    assert_that(a).is_equal_to(b)



if __name__ == '__main__':
    pytest.main()
