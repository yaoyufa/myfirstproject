# -*- coding: utf-8 -*-
"""
@Time : 2018/4/21
@author : pengzhu 
"""
import numpy as np
from assertpy import assert_that

from data_engineer.handler.single.random_data import RandomHandler
from utils.random.random_gen import gen_rand,gen_rand_np


def test_gen_rand_np():
    """
    test case for function gen_rand_np(seed, num, start=0, end=999)
    :return:
    """
    x = gen_rand_np(seed=1,num=10)
    y = gen_rand_np(seed=1,num=1)
    z = gen_rand_np(seed=1,num=(2,3))
    assert_that(x).is_instance_of(np.ndarray)
    assert_that(y).is_instance_of(np.ndarray)
    assert_that(x[0]).is_equal_to(y[0])
    assert_that(y[0]).is_instance_of(np.int64)
    assert_that(x.shape[0]).is_equal_to(10)
    assert_that(z.shape[0]).is_equal_to(2)
    assert_that(z.shape[1]).is_equal_to(3)
    assert_that(z[0][0]).is_equal_to(y[0])


def test_gen_rand():
    """
    test case for function gen_rand(seed, num, start=0, end=999)
    :return:
    """
    x = gen_rand(1, 10, start=0, end=999)
    y = gen_rand(1, 1, start=0, end=999)
    assert_that(x).is_instance_of(list)
    assert_that(x).is_length(10)
    assert_that(y).is_length(1)
    assert_that(y).is_instance_of(list)
    assert_that(x[0]).is_equal_to(y[0])

def test_RandomHandler():
    """
    test case for Class RandomHandler(SingleHandler)
    :return:
    """
    randobj = RandomHandler(biz=None, data_name=None, data_role=None, idno="410782198112103676")
    x = randobj.handle_all()
    assert_that(x).is_instance_of(dict)
    assert_that(x).is_length(20)








