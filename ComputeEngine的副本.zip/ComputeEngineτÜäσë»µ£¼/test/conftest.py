# -*- coding: utf-8 -*-
"""
@Time : 2018/4/19
@author : pengzhu 
"""

import pytest
import sys
import os

params = [{'a':1},{'a':''},{'a':None},{'a.b','c.d'},
          {"b": {"c": 2,"friends": [
                                    {
                                        "best": "Alice"
                                    },
                                    {
                                        "second": "Bob"
                                    },
                                    [5, 6, 7],
                                    [
                                        {"one": 1},
                                        {"two": 2}
                                    ]
            ]}
           },
          [['a','b'],{'a1':'b1'}]
          ]

@pytest.fixture(scope="function",params=params)
def in_params(request):
    return request.param



# 在function测试中增加setup和teardown
@pytest.fixture(scope='function')
def setup_function(request):
    def teardown_function():
        print("teardown_function called.")

    # 这个内嵌的函数做tearDown的工作
    request.addfinalizer(teardown_function)
    print('setup_function called.')

@pytest.fixture(scope='function',autouse=False)
def setup_module():
    file = os.getcwd()
    print("\n  test_funcs located in %s" %(file))

