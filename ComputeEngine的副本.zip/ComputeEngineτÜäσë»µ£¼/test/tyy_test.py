# -*- coding: utf-8 -*-
"""
@Time : 2018/05/22
@author : yangyang.tang
"""

import json
import os

from config import json_setting
from data_engineer.config.featuresmapping.tongdun import TongDunFeatures
from data_engineer.config.featuresmapping.bonne import BonneFeatures
from data_engineer.config.featuresmapping.renhang import RenHangFeatures
from data_engineer.handler.single.tongdun_data import TongDunHandler
from data_engineer.handler.single.bonne_data import BonneHandler
from data_engineer.handler.single.renhang_data import RenHangHandler
from producer.disassemble import header_info, body_info
from utils.json.flatten import flatten_json

#file = os.getcwd()+'/test_data/real_data_demo/br_test.json'
#file = os.getcwd()+'/test_data/real_data_demo/mg_test.json'
#file = os.getcwd()+'/test_data/real_data_demo/renhang_test.json'

#file = os.getcwd()+'/test_data/real_data_demo/td_test.json'

file = os.getcwd() + '/test_data/all_in_one_demo_1.json'

with open(file) as f:
    full_jsondict = json.load(f)

biz, version = header_info.get_biz_version(full_jsondict)

node_data = full_jsondict[json_setting.node_data]

idno, appinfo, keys = body_info.get_node_data(node_data)

for key in keys:
    print(body_info.get_dataname_role(key))

# dataname, role, tmp = body_info.get_dataname_role('bonne_sqr')
# keydata = node_data['bonne']
dataname, role, tmp = body_info.get_dataname_role('rh_sqr')
keydata = node_data['rh']

flt_data = flatten_json(keydata, key_prefix=dataname+'_'+role, sep='_')


#  测试 on 2018-05-22 bonne
# handler = BonneHandler(biz=biz, data_name=dataname, data_role=role, idno=idno, data_tasks=keydata, sep='_')
# flattened_dict = super(BonneHandler, handler).handle_all()
# features_simple_maps = BonneFeatures.get_simple_features_map(handler.prefix)
# simple_features = handler.handle_simple(flattened_dict, features_simple_maps)
# features_array_maps = BonneFeatures.get_array_features_map(handler.prefix)
# array_features = handler.handle_array(flattened_dict, features_array_maps)

#  测试 on 2018-05-23 renhang
handler = RenHangHandler(biz=biz, data_name=dataname, data_role=role, idno=idno, data=keydata, sep='_')
flattened_dict = super(RenHangHandler, handler).handle_all()
features_simple_maps = RenHangFeatures.get_simple_features_map(handler.prefix)
simple_features = handler.handle_simple(flattened_dict, features_simple_maps)
features_array_maps = RenHangFeatures.get_array_features_map(handler.prefix)
array_features = handler.handle_array(flattened_dict, features_array_maps)

complex_features = {}

# 4. merge simple/array features
merge_dict = simple_features.copy()
merge_dict.update(array_features)
merge_dict.update(complex_features)