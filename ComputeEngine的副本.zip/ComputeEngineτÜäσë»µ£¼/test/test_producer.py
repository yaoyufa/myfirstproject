# -*- coding: utf-8 -*-
"""
@Time : 2018/4/21
@author : pengzhu 
"""
import pytest
from assertpy import assert_that
from producer.disassemble.body_info import *
from producer.disassemble.header_info import *
import numpy as np

jsondict=[{
  "ce_version": "1.0.0",
  "biz": "car_XXX",
  "data_tasks": {
    "appinfo": {
      "applicant": {
        "appCode": "PDL",
        "creditcardNo": "6222600260001072444",
        "idType": "0",
        "idno": "410782198112103676",
        "mobile": "1521698543201",
        "proppserName": "潘英杰"
      }
    }
  }
},
    {"biz": "car_XXX",
  "data_tasks": {
    "appinfo": {
      "applicant": {
        "appCode": "PDL",
        "creditcardNo": "6222600260001072444",
        "idType": "0",
        "idno": "410782198112103676",
        "mobile": "1521698543201",
        "proppserName": "潘英杰"
      }
    }
  }}
]


@pytest.fixture(scope='function',params=jsondict)
def in_json(request):
    return request.param

def test_get_biz_version(in_json):
    """
    test case for function get_biz_version(jsondict)
    :return:
    """
    a = get_biz_version(in_json)
    if in_json=={
          "ce_version": "1.0.0",
          "biz": "car_XXX",
          "data_tasks": {
            "appinfo": {
              "applicant": {
                "appCode": "PDL",
                "creditcardNo": "6222600260001072444",
                "idType": "0",
                "idno": "410782198112103676",
                "mobile": "1521698543201",
                "proppserName": "潘英杰"
              }
            }
          }
        } :
        assert_that(a).is_instance_of(tuple)
        assert_that(a).is_length(2)
        assert_that(a).is_equal_to(('car_XXX','1.0.0'))

    if in_json=={"biz": "car_XXX",
              "data_tasks": {
                "appinfo": {
                  "applicant": {
                    "appCode": "PDL",
                    "creditcardNo": "6222600260001072444",
                    "idType": "0",
                    "idno": "410782198112103676",
                    "mobile": "1521698543201",
                    "proppserName": "潘英杰"
                  }
                }
              }}:
        assert_that(a).is_equal_to(None)


def test_get_idno_keys():
    """
    test case for function get_idno_keys(node_data)
    :return:
    """
    idno,keys = get_idno_keys({
        "appinfo": {
      "applicant": {
        "appCode": "PDL",
        "creditcardNo": "6222600260001072444",
        "idType": "0",
        "idno": "410782198112103676",
        "mobile": "1521698543201",
        "proppserName": "潘英杰"
      },
      "applicantSpouse": {
        "idType": "0",
        "idno": "450331199101013712",
        "mobile": "1521698532253",
        "relativesName": "楚天涯"
      },
      "guarantee": {
        "guaranteeName": "楚天涯",
        "idType": "0",
        "idno": "450331199101013712"
      }
    },"miguan_applicant": {
      "success": True,
      "creditCode": "200"}
    ,"bairong_applicant": {
      "success": True,
      "creditCode": "200"}


    })
    assert_that(idno).is_length(18)
    assert_that(idno).is_equal_to("410782198112103676")
    assert 'appinfo' in keys
    assert 'miguan_applicant' in keys
    assert 'bairong_applicant' in keys



def test_get_dataname_role():
    """
    test case for function get_dataname_role(key_in_nodedata)
    :param key_in_nodedata:
    :return:
    """
    keys=['appinfo','miguan_applicant','bairong_applicant']
    for i in range(len(keys)):
        key = keys[i]
        name,role = get_dataname_role(key)
        if key == 'appinfo':
            assert name=='appinfo' and role=='applicant'
        elif key == 'miguan_applicant':
            assert name=='miguan' and role == 'applicant'
        elif key == 'bairong_applicant':
            assert name=='bairong' and role == 'applicant'
        else:
            assert name is None and role is None









