测试说明文档
==================== 

前言    
---- 
**测试是指通过编写独立于业务代码的测试代码来验证程序中是否有错误**     

    1. 测试可以保证代码**在预想得到的情况**下正常工作，测试并不能100%保证没有bug产生     
    2. 确保代码的改动不会破坏现有的功能    
    3. 良好的测试要求业务代码模块化，代码耦合度低  	    

**借鉴\"web开发实战\"作者的看法**   
      
> 1. 软件质量不是测试出来的, 而是设计和维护出来的         
> 2. 不需要对所有的模块添加单元测试, 但是核心业务一定要添加测试      
> 3. 保持测试的独立性. 测试用例之间最好不要有相互依赖, 也不要前后次序的区分    

相关概念
---

###Assert断言    
    对于测试来讲，不管是功能测试，自动化测试，还是单元测试。一般都会预设一个正确的预期结果，而在测试执行的过程中会得到一个实际的结果。测试的成功与否就是拿实际的结果与预期的结果进行比较。这个比的过程实际就是断言。    

    unittest单元测试框架中提供了丰富的断言方法，例如assertEqual()、assertIn()、assertTrue()、assertIs()等    

    pytest单元测试框架中并没提供特殊的断言方法，而是直接使用python的assert进行断言    

    要不要把内置的断言语句换成可读性更好功能更强大的第三方断言，完全取决于实际情况。比如你真的需要验证某个东西并且很关心验证结果，那么必须不能用简单的assert；如果你只是担心某个点可能有坑或者让IDE认识某个对象，用内置的assert既简单又方便。

推荐使用的第三方断言 -  **assertpy**    

   * 安装方法 `pip install assertpy`    
   * 参考链接 [assertpy](https://github.com/ActivisionGameScience/assertpy)    
    
###单元测试    
    什么是单元测试  针对的是程序内部代码和结构问题   
    
###集成测试    
    什么是集成测试  针对的是模块和模块之间的接口和参数传递规则的问题
    
###系统测试
    什么是系统测试  针对的是整个系统，模拟用户最终使用时可能出现的问题
    
###测试工具
    
    1. unittest - python自带的单元测试框架
    2. pytest - 第三方单元测试框架
    通过对比两个测试框架的优缺点，选择pytest作为我们的测试框架 


pytest使用介绍 
--- 

#优点 

1. 自动发现需要测试的模块和函数
2. 支持运行由nose, unittest 等模块编写的测试用例
3. 第三方插件支持丰富,并且自定义插件方便
4. 容易与持续集成工具结合
5. 可以细粒度的控制需要测试的测试用例
6. 帮助我们定位到测试失败的位置,并告诉我们预期值和实际值
7. 命令行功能非常丰富,可以测试整个目录/单文件/ 单文件下的某个测试用例/ 测试用例下的单个方法

#pytest如何识别测试用例  
* 文件名   - 以test\_\*.py 或\*_test.py命名 
* 文件内部 - 方法或函数以test_开头
* 文件内部 - 类名以Test_开头

#pytest几大特点
* setup vs teardown
* fixtures
* conftest.py
* marker
* ExitCode


##setup & teardown 
 
**pytest 实现的setup和teardown有三种级别，分别是：**       

* **模块级别** 

    作用于一个模块内的所有class和def，对于所有class和def，setup和teardown只执行一次  
    
     ```python
     	def setup_module(module):
	    """ setup any state specific to the execution of the given module.""" 
	    
		def teardown_module(module):
		""" teardown any state that was previously setup with a setup_module
		method.
		""" 
     ``` 
    
* **类级别**

	作用于一个class内中的所有测试用例,所有用例只执行一次setup，当所有用例执行完成后，才会执行teardown
	
	 ```
	 # test_fixture.py
	 
	 import pytest
	 
	 def add(a,b):
    	return a+b
    	
    class TestMath(object):

	    def setup(self):
	        print("setup - 运行在调用函数之前 " )
	
	    def teardown(self):
	        print("teardown - 运行在调用函数之后 ")
	
	    def setup_class(cls):
	        print("setup_class - 运行在类开始前 class:%s" % cls.__name__)
	
	    def teardown_class(cls):
	        print("teardown_class - 运行在类结束后 class:%s" % cls.__name__)
	
	    def setup_method(self, method):
	        print("setup_method - 运行在类中的函数之前 method:%s" % method.__name__)
	
	    def teardown_method(self, method):
	        print("teardown_method -运行在类中的函数之后 method:%s" % method.__name__)
	
	    def test_add(self):
	        x = add(3,2)
	        assert x==6
	
	    def test_sub(self):
	        x=2
	        assert x==3
	 
	 ```
	 
	 **运行结果如下：**   
	 ![github](https://raw.githubusercontent.com/StutuPig/images/master/mk.jpg)    
	

* **方法或函数级别**    

	作用于单个测试用例，在用例开始前执行setup，在用例结束后执行teardown，若用例没有执行（如被skip了）或失败了，则不会执行teardown。不可用于Class内的测试用例。     
	
	```
	import pytest

	def multiply(a, b):
		return a * b
		
	def setup_module():
    print("setup_module=============>")
	
	def teardown_module():
	    print("teardown_module=============>")
	
	
	def setup_function():
	    print("setup_function------>")
	
	
	def teardown_function():
	    print("teardown_function--->")
	    
	
	def test_numbers_3_4():
	    print('test_numbers_3_4')
	    assert multiply(3, 4) == 12
	
	
	def test_strings_a_3():
	    print('test_strings_a_3')
	    assert multiply('a', 3) == 'aaa'
	
	```
	 **运行结果如下：**     
	![github](https://raw.githubusercontent.com/StutuPig/images/master/mk.jpg)     
	
	**NOTE**    
	*测试用例中的函数名以test\_开头，类名以Test\_开头，才会被识别*



##fixtures

**为可靠的和可重复执行的测试提供固定的基线。可以理解为测试的固定配置，使不同范围的测试都能够获得统一的配置。**   
> * 有独立的命名，可以按照测试的用途来激活，比如用于session/functions/modules/classes甚至整个project         
> * 按模块单元的方式实现，每个fixture name可以触发一个fixture function，每个fixture function本身也能调用其他的fixture function。（相互调用，不只是用于test_func()）  
> * fixture的范围覆盖简单的单元测试到复杂的功能测试，可用于参数传入function或者class、module及test session范围内的复用

* 定义方式
	- 设计
* 作用域   
  * **session**     : Run once per session 
  * **function**    : Run once per test case  
  * **class**       : Run once per class of tests 
  * **module**      : Run once per module    
* 使用方式

	* 用fixture实现setup & teardown

	
	
* 高级配置方式   


##conftest.py文件  

    conftest.py 文件是一个单独的存放fixtures的文件。  
    对于function，class和module来说，把fixture代码放到和测试用例同样的文件中完全合理的，但是对于session，就不再合理了。
    当遇到session作用域的fixture时，需要把他们放在conftest.py文件中，它是一个pytest会寻找的一个有特定名字的文件。

##marker机制

##ExitCode含义        
- Exit code 0 所有用例执行完毕，全部通过
- Exit code 1 所有用例执行完毕，存在Failed的测试用例
- Exit code 2 用户中断了测试的执行
- Exit code 3 测试执行过程发生了内部错误
- Exit code 4 pytest 命令行使用错误
- Exit code 5 未采集到可用测试用例文件

##执行方式

* 通过包执行测试 
    
   ```
   pytest --pyargs pkgname
   ```
   * 这条命令会自动导入包pkgname，并使用该包所在的目录，执行包下面的测试用例
     
* 指定测试目录  

   ```
   pytest test 
   ```
   * 执行test目录下的所有测试用例

* 指定测试模块

   ```
   pytest test/test_mod.py
   ```
   * 执行test_mod.py模块下所有的测试用例

* 指定测试用例

	```
	pytest test/test_mod.py::test_func
	pytest test/test_mod.py::TestClass::test_method
	```    
	* 执行test\_mod.py模块下的测试用例test_func
	* 执行test\_mod.py模块下的测试用例TestClass类中的方法test_method

* 通过关键字表达式过滤执行  

	```
	pytest -k "MyClass and not method"
	```    
	* 这条命令会匹配文件名、类名、方法名匹配表达式的用例，这里这条命令会运行TestMyClass.test\_something， 不会执行 TestMyClass.test\_method\_simple

* 通过标记表达式执行  

	```
	pytest -m slow
	```  
	* 这条命令会执行被装饰器@pytest.mark.slow装饰的所有测试用例

##测试报告
* 输出到指定文件   `pytest testcase.py ----resultlog=./log.txt`
* 输出到指定xml   `pytest testcase.py --junitxml=./log.xml`
* 生成web测试报告 `pytest testcase.py --pastebin=all`    



