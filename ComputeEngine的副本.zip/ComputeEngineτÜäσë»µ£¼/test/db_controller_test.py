# -*- coding: utf-8 -*-
"""
@Time : 2018/6/4
@author : pengzhu 
"""
from config.json_setting import *
from bark_engine.controller.define import Define
from bark_engine.controller.union import Union
from bark_engine.controller.pipeline import Pipeline
from bark_engine.task.mappers.jsonmapper import FlattenMapper, JsonMapper
from bark_engine.task.broker.requiredata import RequireCache
from bark_engine.task.filters.selectfilter import *
from bark_engine.task.base.const_value import ConstValue
from bark_engine.controller.foreach import Foreach
from bark_engine.controller.judge import JudgeValue
from bark_engine.controller.ifelse import CaseWhen
from bark_engine.task.reducers.stats import Count, Sum, Max
from bark_engine.task.mappers.valueMapper import ValueMapper
from bark_engine.task.mappers.castmapper import CastMapper
from bark_engine.task.broker.db import RequireDB
from bark_engine.task.broker.requiredata import RequireData,RequireCache
from bark_engine.task.filters.dbfilter import DBQuery
from bark_engine.config.conn_url import DB_name_bgrk, DB_name_app

class DBCtl(object):
    """

    """
    __CONTROLLER = Union(
        # Pipeline(
        #     RequireDB(dbname=DB_name_bgrk),
        #     DBQuery(sql=""" select * from test """, as_name='test')
        # ),
        Define(FlattenMapper(as_cache_name='fahaishixin')),
        Pipeline(
            RequireDB(dbname=DB_name_bgrk),
            DBQuery(sql=""" select * from test where id= {{id}} """, kv_task_params={
                'id': Pipeline(
                    RequireCache('fahaishixin'),
                    #Select(key='id')
                    ConstValue(1)
                )
            }, as_name='test')
        )
    )


    @property
    def controller(self):
        return self.__CONTROLLER
