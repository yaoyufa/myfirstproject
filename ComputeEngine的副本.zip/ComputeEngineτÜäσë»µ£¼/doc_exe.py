# -*- coding: utf-8 -*-
"""
@Time : 2018/9/25
@author : pengzhu 
"""

from bark_engine.task.base.const_value import ConstValue
from beans.core.datainfo_bean import SingleDataBean
from bark_engine.auxi.context_bean import ContextBean

data = SingleDataBean(data_name='test_const',
                      data_role='at',
                      data={'x':1})

t = ConstValue(value=2,key='ConstValue')

t.fill_context(data=data,context_bean=ContextBean(**{'debug':True}))

print("*"*3+"before ConstValue Task, the data is :{}".format(data.get_data_value())+"*"*3)

result, task_context, kwargs = t.action()
print("*"*3+"after ConstValue Task, the data is :{}".format(result.get_data_value())+"*"*3)

import os
import json
file = os.getcwd()+'/test_data/all_in_one_demo_1.json'
with open(file) as f:
    full_jsondict = json.load(f)

from producer.beans_factory.global_factory import GlobalFactory
glb_data, map_data = GlobalFactory.build_global_ele(full_jsondict)
for key_prefix, key_data in map_data.items():
    print(key_prefix)

biz = glb_data.get('biz')
version = glb_data.get('version')
idno = glb_data.get('idno')
appCode = glb_data.get('appcode')
mobile = glb_data.get('mobile')

data_info = map_data.get('brBL_mt')
action_type = 'Single'
target_name = data_info.get('data_name')
from beans.core.datainfo_bean import SingleDataBean, MultiDataBean
from bark_engine.auxi.context_bean import ContextBean
from beans.core.requirement_bean import RequirementBean, ActionType
from bark_engine.auxi.cache import CacheManager
from beans.globalinfo.globalinfo_bean import GlobalBean
from beans.globalinfo.appinfo_bean import AppInfoBean
from beans.globalinfo.bizinfo_bean import BizInfoBean
from bark_engine.dag.dag import Dag

if action_type == 'Single':
    data_name = data_info.get('data_name')
    data_role = data_info.get('data_role')
    extra_data_info = data_info.get('extra_data_info')
    data = data_info.get('data')
    data_bean = SingleDataBean(data_name=data_name, data_role=data_role,
                               ext_info=extra_data_info, data=data)

    context_bean = ContextBean(cachemgr=CacheManager(),
                               globalbean=GlobalBean(bizinfo=BizInfoBean(biz_type=biz, biz_prod=version),
                                                     appinfo=AppInfoBean(appcode=appCode, idtype=1,
                                                                         idno=idno, mobile=mobile)),
                               requirementbean=RequirementBean(action_type=ActionType.Single, new_name=target_name)
                               )

elif action_type == 'Cross':
    data_bean = MultiDataBean()
    size = len(data_info)
    for i in range(size):
        data_name = data_info[i].get('data_name')
        data_role = data_info[i].get('data_role')
        extra_data_info = data_info[i].get('extra_data_info')
        data = data_info[i].get('data')

        data_bean.append_databean(
            SingleDataBean(data_name=data_name, data_role=data_role,
                           ext_info=extra_data_info, data=data)
        )
    # TODO : 做交叉时，需指明哪个征信源为主征信源，将此征信源的data_role 作为RequirementBean的role_name
    role = 'at'
    context_bean = ContextBean(cachemgr=CacheManager(),
                               globalbean=GlobalBean(bizinfo=BizInfoBean(biz_type=biz, biz_prod=version),
                                                     appinfo=AppInfoBean(appcode=appCode, idtype=1,
                                                                         idno=idno, mobile=mobile)),
                               requirementbean=RequirementBean(action_type=ActionType.Cross,
                                                               new_name=target_name,
                                                               role_name=role)
                               )

from bark_engine.controller.pipeline import Pipeline
from bark_engine.task.mappers.jsonmapper import FlattenMapper
controller = Pipeline(FlattenMapper(as_cache_name='br_flattened'))

dag = Dag()
dag.fill(data_bean, context_bean)
dag.controller = controller
try:
    dag.action()
    res = dag.get_result()
    print(res)
except:
    print("error")


from bark_engine.task.filters.selectfilter import *
from bark_engine.controller.union import Union
ctr = Pipeline(FlattenMapper(),
               Union(# td_final_decision
                Select(key='mainData_finalDecision', rename='mainData_finalDecision', doc_name='td_final_decision'),
                # td_final_score
                Select(key='mainData_finalScore', rename='mainData_finalScore', doc_name='td_final_score'),
                # ruleName
                SelectArray(key_path='detailDataList[{}]_ruleName', rename='detailDataList_ruleName[{}]')
               )
             )
dag = Dag()
dag.fill(data_bean=data_bean,context_bean=context_bean)
dag.controller = ctr
dag.action()






