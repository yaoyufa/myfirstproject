"""
 load json and get the important keys such as: biz / idcard .
"""
from config import json_setting


def get_biz_version(jsondict):
    if isinstance(jsondict, dict):
        keys = jsondict.keys()
        # if json_setting.node_biz in keys and json_setting.node_version in keys:
        #     biz = jsondict[json_setting.node_biz]
        #     version = jsondict[json_setting.node_version]
        #     return biz, version
        # else:
        #     return None,None

        biz = jsondict[json_setting.node_biz] if json_setting.node_biz in keys else None
        version = jsondict[json_setting.node_version] if json_setting.node_version in keys else None
        return biz, version
    else:
        return None, None
