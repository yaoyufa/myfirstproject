
"""
 pass in the data_tasks element of json, get the idcardno,  key name /role name out of data_tasks from 3rd party.
"""
from config import json_setting


def get_node_data(node_data):
    """
    get 3 parts from node_data:
        1. idno of applicant
        2. the data_tasks of 'appinfo'-[json_setting.node_appinfo]
        3. the other keys in node_data except for 'appinfo'
    :param node_data:
    :return:
    """
    keys = node_data.keys()
    if json_setting.node_appinfo in keys:
        idno = node_data[json_setting.node_appinfo][json_setting.node_applicant][json_setting.node_idno]
        # add on 5.23 for miaoju features
        appCode = node_data[json_setting.node_appinfo][json_setting.node_applicant][json_setting.node_appcode]
        mobile = node_data[json_setting.node_appinfo][json_setting.node_applicant][json_setting.node_mobile]
        appdata = node_data[json_setting.node_appinfo]
        dkeys = [i for i in keys if i != json_setting.node_appinfo]
        return idno,appCode,mobile, appdata, dkeys
    else:
        return None, None, None


def get_dataname_role(key_in_nodedata):
    """
    format of key: jiguang_sqr_jzd
    which will be cracked as: 'jiguang', 'sqr', 'jzd'

    :param key_in_nodedata:
    :return: tuple(data_name, role_name, extra_data_info)
    """

    key_arr = key_in_nodedata.split(sep=json_setting.separator)
    arr_len = len(key_arr)
    if arr_len == 1:
        return key_arr[0], None, None
    elif arr_len == 2:
        return key_arr[0], key_arr[1], None
    elif arr_len == 3:
        return key_arr[0], key_arr[1], key_arr[2]
    else:
        return None, None, None
