
class DataFactory(object):
    """
    根据传入的 data_tasks, bizinfo , 自动构造出对应的 目标 data_tasks , 或者 datalist bean.
    """
    def __init__(self):
        pass

    def build_data_bean(self):
        pass

    def build_datalist_bean(self):
        pass
