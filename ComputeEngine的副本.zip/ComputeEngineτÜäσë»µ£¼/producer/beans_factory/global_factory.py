from beans.globalinfo.appinfo_bean import AppInfoBean
from beans.globalinfo.bizinfo_bean import BizInfoBean
from config import json_setting, dataname_setting
from producer.disassemble import header_info, body_info


class GlobalFactory(object):
    """
    根据传入的 json ,自动构造出对应的global beans: bizinfobean, appinfo bean, config bean, sysinfo bean.
    """

    def __init__(self):
        pass

    @classmethod
    def build_bizinfo_bean(cls, data):
        biz, version = header_info.get_biz_version(data)
        return BizInfoBean(biz_type=biz, biz_prod=version)

    @classmethod
    def build_appinfo_bean(cls, data):
        node_data = data[json_setting.node_data]
        idno, appCode, mobile, appinfo, dkeys = body_info.get_node_data(node_data)
        return AppInfoBean(appcode=appCode, idtype='1', idno=idno, mobile=mobile)

    @classmethod
    def build_config_bean(cls, data):
        pass

    @classmethod
    def build_sysinfo_bean(cls, data):
        pass

    @classmethod
    def build_data_bean(cls, data_name=None, data_role=None, extinfo=None, data=None):
        return {'data_name': data_name, 'data_role': data_role,
         'extra_data_info': extinfo, 'data': data}

    @classmethod
    def build_global_ele(cls, data):
        global_data = {}
        map_data = {}

        biz, version = header_info.get_biz_version(data)
        node_data = data[json_setting.node_data]
        keys = node_data.keys()

        # 1. fetch dataname, data role, extra  from data keys.
        for key in keys:
            data_name, data_role, extra_data_info = body_info.get_dataname_role(key)
            data = node_data[key]
            map_data.update({key: {'data_name':data_name, 'data_role':data_role,
                                   'extra_data_info':extra_data_info, 'data': data}})

        # 2. fetch global info from appinfo
        idno = ''
        appCode = ''
        mobile = ''

        for key in keys:
            if key.startswith(dataname_setting.node_appinfo):
                idno = node_data[key][json_setting.node_applicant][json_setting.node_idno]
                # add on 5.23 for miaoju features
                appCode = node_data[key][json_setting.node_applicant][json_setting.node_appcode]
                mobile = node_data[key][json_setting.node_applicant][json_setting.node_mobile]
            else:
                pass
                #print("appinfo schema error", key)

        global_data.update({'biz': biz, 'version': version,
                            'idno': idno, 'appcode': appCode,
                            'mobile': mobile
                            })

        return global_data, map_data
