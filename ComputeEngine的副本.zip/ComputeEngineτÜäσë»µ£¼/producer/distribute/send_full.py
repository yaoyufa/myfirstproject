# -*- coding: utf-8 -*-
"""
@Time : 2018/7/25
@author : dongyun.fan
"""

import json
from config.version import ce_version
from config import json_setting, dataname_setting

from producer.beans_factory.global_factory import GlobalFactory
from consumer.task_handlers import feature_engineer_dag2


def distribute_and_merge(full_jsondict):
    features_result_dict = {}
    # send full json
    result = feature_engineer_dag2.delay(target=None,
                                        glb_data=None,
                                        data_info=full_jsondict,
                                        action_type=None)

    # 5. merge features returned.
    # get global data info and detail data info
    glb_data, map_data = GlobalFactory.build_global_ele(full_jsondict)
    # unpack glb_data
    biz = glb_data.get('biz')
    version = glb_data.get('version')

    features_result_dict[json_setting.node_biz] = biz
    features_result_dict[json_setting.node_version] = version
    features_result_dict[json_setting.node_code] = 200
    features_result_dict[json_setting.node_ce_version] = ce_version

    features_result_dict[json_setting.node_data] = {}

    # 5.2. retrieve generated features.
    # TODO: timeout exception handler.
    # TODO: use callback to avoid waiting: AsyncResult.then(callback, on_error=None, weak=False)
    try:
        # 1. get result
        features_result_dict[json_setting.node_data] = result.get(timeout=60)

        # 2. check dag_status in each data_name, tag global status when all() == True.
        for key in features_result_dict[json_setting.node_data].keys():
            status = features_result_dict[json_setting.node_data][key].get(json_setting.node_dag_status)
            if status == json_setting.node_dag_status_fail:
                features_result_dict[json_setting.node_code] = json_setting.node_dag_status_fail
                break
    except Exception as e:
        features_result_dict[json_setting.node_code] = json_setting.node_dag_status_fail

    return features_result_dict


def action(full_jsondict):
    result_data = distribute_and_merge(full_jsondict)
    # build json and return .
    feat_json = json.dumps(result_data)
    return feat_json


if __name__ == '__main__':
    file = '/Users/pengzhu/Documents/mljr/ComputeEngine/test_data/real_data_demo/td_test.json'
    with open(file) as f:
        full_jsondict = json.load(f)
    r = action(full_jsondict)
    print(r)
