# -*- coding: utf-8 -*-
"""
@Time : 2018/08/06
@author : zhu.peng
"""

import json
from config import json_setting
from config import version as config_version
from producer.beans_factory.global_factory import GlobalFactory
from consumer.task_web_handlers import web_dags


def distribute_and_merge(test_json, controller_code, data_name,data_role, **kwargs):

    # send full json
    result = web_dags.delay(data_info=test_json,
                            controller_code=controller_code,
                            data_name=data_name,
                            data_role=data_role,
                            **kwargs)
    # get results , include data and debug info
    task_dict = result.get(timeout=60)

    # update data by adding biz ,version, etc.
    results_dict = task_dict.copy()
    results_dict['results'] = {}

    # get global data info and detail data info
    glb_data, map_data = GlobalFactory.build_global_ele(test_json)
    # unpack glb_data
    biz = glb_data.get('biz')
    version = glb_data.get('version')
    results_dict['results'][json_setting.node_biz] = biz
    results_dict['results'][json_setting.node_version] = version
    results_dict['results'][json_setting.node_code] = 200
    results_dict['results'][json_setting.node_ce_version] = config_version.ce_version

    try:
        # 1. get result
        results_dict['results'][json_setting.node_data] = task_dict.get('results')

        # 2. check dag_status in each data_name, tag global status when all() == True.
        for key in results_dict['results'][json_setting.node_data].keys():
            if key == json_setting.node_dag_status:
                status = results_dict['results'][json_setting.node_data][key]
                if status == json_setting.node_dag_status_fail:
                    results_dict['results'][json_setting.node_code] = json_setting.node_dag_status_fail
                    break
    except Exception as e:
        results_dict['results'][json_setting.node_code] = json_setting.node_dag_status_fail

    return results_dict


def action(test_json, controller_code, data_name,data_role, **kwargs):
    result_data = distribute_and_merge(test_json, controller_code, data_name,data_role, **kwargs)
    return result_data


if __name__ == '__main__':
    file = '/Users/pengzhu/Documents/mljr/ComputeEngine/test_data/web_demo_data.json'
    with open(file) as f:
        full_jsondict = json.load(f)

    config = {'new_name': 'pcv',
              'new_role': 'at',
              'cross_nodes':['appinfo_cn','pc_at']}

    mg_code = """controller = Pipeline(
            # 1. flatten , cache
            Define(FlattenMapper(as_cache_name='mg_flattened')),
            # 2. get specified key.
            Pipeline(
                RequireCache(dataname='mg_flattened'),
                Union(
                    Select(key='mongodbId', rename='mongodbId'),
                    Select(key='createTime', rename='createTime'),
                    Select(key='id', rename='id', doc_name=''),
                    Pipeline(
                        Select(key='success', rename='returnStatus'),
                        ValueMapper(kv_map={True: 1, False: -1})
                    ),
                    Select(key='blknamewithidcard', rename='blknamewithidcard'),
                    Select(key='blknamewithphone', rename='blknamewithphone'),
                    Pipeline(
                        Select(key='blkcategory', rename='blkcategory'),
                        StringMapper(func=lambda x: x[:20] if len(x) > 20 else x)
                    )
                )

            )
        )
        """

    pcv_code = """controller = Union(
        # 1. flatten , cache
        Define(
            Pipeline(
                RequireData(data_name=node_paycenter, role=json_setting.role_applicant),
                FlattenMapper(as_cache_name='pc_flattened'))
        ),
        Define(
            Pipeline(
                RequireData(data_name=node_appinfo, role=json_setting.role_contract_number),
                FlattenMapper(as_cache_name='appinfo_flattened'))
        ),

        IfElse(
            # 2. get specified key.
            Pipeline(
                RequireCache(dataname='appinfo_flattened'),
                JudgeValue(
                    Select(key='applicant_creditcardType', doc_name=''), ConstValue(1), judge_func=lambda x, y: x == y)
            ),
            Pipeline(
                RequireCache(dataname='pc_flattened'),
                Union(
                    Select(key='mongodbId', rename='mongodbId', doc_name=''),
                    Select(key='createTime', rename='createTime', doc_name=''),
                    Select(key='id', rename='id', doc_name=''),

                    # 银联智慧信用卡报告返回状态
                    Pipeline(Select(key='success', rename='credit_returnStatus', doc_name='ylzh_credit_status'),
                    ValueMapper(kv_map={True: 1, False: -1})
                             ),
                    # 银联验证返回结果
                    Select(key='bodyEntity_retCode', rename='credit_resp_status',
                           doc_name='ylzh_credit_resp_status', cast='int')
                ),
                ResetPrefix()
            ),
            Pipeline(
                RequireCache(dataname='pc_flattened'),
                Union(
                    Select(key='mongodbId', rename='mongodbId', doc_name=''),
                    Select(key='createTime', rename='createTime', doc_name=''),
                    Select(key='id', rename='id', doc_name=''),

                    # 银联智慧信用卡报告返回状态
                    Pipeline(Select(key='success', rename='debit_returnStatus', doc_name='ylzh_credit_status'),
                             ValueMapper(kv_map={True: 1, False: -1})
                             ),
                    # 银联验证返回结果
                    Select(key='bodyEntity_retCode', rename='debit_resp_status',
                           doc_name='ylzh_credit_resp_status', cast='int')
                ),
                ResetPrefix()
            )
        )

    )
    """
    controller_code = pcv_code
    data_name = 'pcv'
    data_role = 'at'
    r = action(full_jsondict, controller_code, data_name, data_role)

    print(r.get('debug_info'))
    print(r.get('results'))
