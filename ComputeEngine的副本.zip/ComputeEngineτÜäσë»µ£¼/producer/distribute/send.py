
"""
distribute all kinds of data_tasks from 3rd parties to corresponding task.
"""
import json
from config.version import ce_version
from config import json_setting
from config import dataname_setting
from consumer import task_demos
from producer.disassemble import header_info, body_info


def distribute_and_merge_func(features_result_dict):
    """
    use closure to trigger combination of features which generated and got back from celery workers.
    """
    def distribute_and_merge(full_jsondict):

        callbacks_list = []

        # 1.get biz, idno
        biz, version = header_info.get_biz_version(full_jsondict)

        # 2.get node data_tasks out.
        node_data = full_jsondict[json_setting.node_data]

        # 3. get 3 parts of data_tasks
        idno, appCode, mobile, appinfo, dkeys = body_info.get_node_data(node_data)

        # 4. distribute to consumers

        # 4-1. distribute appinfo data_tasks
        result_appinfo = task_demos.feature_engineer2.delay(biz=biz, idno=idno, dataname=json_setting.node_appinfo,
                                                            role=None, data=appinfo)
        callbacks_list.append((json_setting.node_appinfo, result_appinfo))

        # 4-2. distribute zhengxin data_tasks
        for key in dkeys :
            name, role, extra_data_info = body_info.get_dataname_role(key)
            keydata = node_data[key]
            # TODO: 1. take cross data_tasks out of here
            # TODO: 2. refactor for cross features which should be based on configuration (origin_data, cross_data).
            if key in dataname_setting.node_miaoju:
                kds = {'mobile': mobile, 'appCode': appCode}
                result = task_demos.feature_engineer2.delay(biz=biz, idno=idno, dataname=name, role=role, data=keydata,
                                                            extra_data_info=extra_data_info,
                                                            **kds)
            else:
                result = task_demos.feature_engineer2.delay(biz=biz, idno=idno, dataname=name, role=role, data=keydata,
                                                            extra_data_info=extra_data_info)
            callbacks_list.append((key, result))

        # 4-3. distribute idcardno to consumer for random values generation.
        result_randoms = task_demos.feature_engineer2.delay(biz=biz, idno=idno, dataname=dataname_setting.node_random,
                                                            role=json_setting.role_applicant, data=None)
        callbacks_list.append((dataname_setting.node_random, result_randoms))

        # 4-4. distribute cross data_tasks for paycenter.
        new_name = dataname_setting.node_paycenter_cross
        origin_data = node_data[dataname_setting.node_paycenter]
        datalist = [{'data_name': dataname_setting.node_appinfo, 'data_role': None,
                     'data_tasks': node_data[dataname_setting.node_appinfo], "kwargs": {}}]
        result_pc_cross = task_demos.feature_engineer_cross.delay(biz=biz, idno=idno, dataname=dataname_setting.node_paycenter,
                                                            role=json_setting.role_applicant, data=origin_data,
                                                             new_name=new_name, datalist=datalist)

        callbacks_list.append((dataname_setting.node_paycenter_cross, result_pc_cross))

        # 5. merge features returned.
        # 5.1. store to result for return back
        features_result_dict[json_setting.node_biz] = biz
        features_result_dict[json_setting.node_version] = version
        features_result_dict[json_setting.node_code] = json_setting.node_dag_status_success
        features_result_dict[json_setting.node_ce_version] = ce_version

        features_result_dict[json_setting.node_data] = {}

        # 5.2. retrieve generated features.
        # TODO: timeout exception handler.
        # TODO: use callback to avoid waiting: AsyncResult.then(callback, on_error=None, weak=False)
        try:
            for name, func in callbacks_list:
                features_result_dict[json_setting.node_data][name] = func.get(timeout=60)
        except Exception as e:
            features_result_dict[json_setting.node_code] = json_setting.node_dag_status_fail

    return distribute_and_merge


def action(full_jsondict):
    """
    send out json and get features back.
    :param full_jsondict:
    :return: jsondict: features in a json
    """
    result_data = {}
    distribute_merge = distribute_and_merge_func(result_data)
    distribute_merge(full_jsondict)

    # build json and return .
    feat_json = json.dumps(result_data)

    return feat_json


if __name__ == '__main__':
    file_path = '../../test_data/all_in_one_demo_1.json'
    json_file = open(file_path, encoding='utf-8')
    json_all_in_one = json.load(json_file)
    r = action(json_all_in_one)
    print(r)
