from consumer import task_demos

# simple task
for i in range(1000):
    result = task_demos.add.delay(i, i)
    y = result.get()
    print(y)

# group task


# chains task


# chord task


# chunks task

