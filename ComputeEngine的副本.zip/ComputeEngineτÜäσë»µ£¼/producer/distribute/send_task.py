# -*- coding: utf-8 -*-
"""
@Time : 2018/5/30
@author : pengzhu
"""

import json
from config.version import ce_version
from config import json_setting, dataname_setting

from producer.beans_factory.global_factory import GlobalFactory
from consumer.task_demos import feature_engineer_dag


def distribute_and_merge_func(features_result_dict):
    """
    use closure to trigger combination of features which generated and got back from celery workers.
    """

    def distribute_and_merge(full_jsondict):

        callbacks_list = []
        # get global data info and detail data info
        glb_data, map_data = GlobalFactory.build_global_ele(full_jsondict)

        # unpack glb_data
        biz = glb_data.get('biz')
        version = glb_data.get('version')

        # throw random-task
        # TODO:
        result = feature_engineer_dag.delay(target=dataname_setting.node_random,
                                            glb_data=glb_data,
                                            data_info=GlobalFactory.build_data_bean(data_name="randoms", data={}),
                                            action_type='Single')

        callbacks_list.append(('randoms', result))

        # throw each data_task
        for key_prefix, key_data in map_data.items():
            result = feature_engineer_dag.delay(target=key_data.get('data_name'),
                                                glb_data=glb_data,
                                                data_info=key_data,
                                                action_type='Single')

            callbacks_list.append((key_prefix, result))

        # # throw cross-task
        result = feature_engineer_dag.delay(target=dataname_setting.node_paycenter_cross,
                                            glb_data=glb_data,
                                            data_info=[v for k, v in map_data.items()
                                                       if v.get('data_name') in (dataname_setting.node_appinfo,
                                                                                 dataname_setting.node_paycenter)
                                                       ],
                                            action_type='Cross')

        callbacks_list.append((dataname_setting.node_paycenter_cross, result))

        # 5. merge features returned.
        # 5.1. store to result for return back
        features_result_dict[json_setting.node_biz] = biz
        features_result_dict[json_setting.node_version] = version
        features_result_dict[json_setting.node_code] = json_setting.node_dag_status_success
        features_result_dict[json_setting.node_ce_version] = ce_version

        features_result_dict[json_setting.node_data] = {}

        # 5.2. retrieve generated features.
        # TODO: timeout exception handler.
        # TODO: use callback to avoid waiting: AsyncResult.then(callback, on_error=None, weak=False)
        try:
            for name, func in callbacks_list:
                features_result_dict[json_setting.node_data][name] = func.get(timeout=60)
        except Exception as e:
            features_result_dict[json_setting.node_code] = json_setting.node_dag_status_fail

    return distribute_and_merge


def action(full_jsondict):
    result_data = {}
    distribute_merge = distribute_and_merge_func(result_data)
    distribute_merge(full_jsondict)
    # build json and return .
    feat_json = json.dumps(result_data)
    return feat_json


if __name__ == '__main__':
    file = '/Users/pengzhu/Documents/mljr/ComputeEngine/test_data/real_data_demo/td_test.json'
    with open(file) as f:
        full_jsondict = json.load(f)
    r = action(full_jsondict)
    print(r)
