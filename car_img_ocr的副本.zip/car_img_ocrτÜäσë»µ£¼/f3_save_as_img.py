#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan 29 17:48:54 2019

@author: fan
"""
import os
import requests
import pandas as pd


## 基于拉取在职的销售数据后，


## join 发现，在职销售 对应的 img_key


## 获取在职销售对应的申请人的合影数据，并拉取对应的合影图片，idno 身份证图片
file_df = pd.read_pickle('100_url_heying.pkl')



## 逐个下载各类图片

num=0
for row in file_df.itertuples():
    filename = 'data/1000_appid/{}.jpg'.format(row[1])
    if os.path.exists(filename):
        continue
    img_file = requests.get(row[2], stream = True)
    img = img_file.raw.read()
    
    with open(filename,'wb') as f:
        f.write(img)

