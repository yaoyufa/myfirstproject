#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Wed Feb 13 16:52:20 2019

@author: fan
"""

import pickle
pk = pickle.load(open('pickle_usersinfo_decomposite.pickle'))

import pandas as pd

df = pd.DataFrame(pk)
df.to_pickle('pickle_usersinfo_decomposite_df.pkl')
