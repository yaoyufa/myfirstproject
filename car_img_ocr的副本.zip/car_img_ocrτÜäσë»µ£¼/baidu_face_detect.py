#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jan 28 16:05:05 2019

@author: fan
"""
import base64
from aip import AipFace

config = {
    'appId': '15504272',
    'apiKey': 'N7fHmwMQuaPiIv4zMVgGn2Qu',
    'secretKey': '4MUYGMtBDj6Txr4FHzXDHsGkbF2riYIf'
}

client = AipFace(**config)

def get_file_content(file):
    with open(file, 'rb') as fp:
        return fp.read()

def img_to_str(image_path):
    image = get_file_content(image_path)
    image64 = base64.b64encode(image)
    
    imageType = "BASE64"
    
    """ 调用人脸检测 """
    result = client.detect(image64, imageType);
    
    return result

    #if 'words_result' in result:
    #    return '\n'.join([w['words'] for w in result['words_result']])


if __name__=="__main__":
    from glob import glob
    image_files = glob('./data/faces/*.jpg')
    
    for image_file in sorted(image_files):
        print(image_file)
        print(image_file, ":\n\n", img_to_str(image_file))

    