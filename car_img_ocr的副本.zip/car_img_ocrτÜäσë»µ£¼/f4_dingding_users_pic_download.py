#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Wed Feb 13 15:55:36 2019

@author: fan
"""

import pickle
pk = pickle.load(open('pickle_usersinfo.pickle'))

userlist = []

for deptid, content in pk.iteritems():
    for i in content['userlist']:
        userlist.append(i)


print(len(userlist))
fp = open('pickle_usersinfo_decomposite.pickle', 'wb')
pickle.dump(userlist, fp)
fp.close()


## 拉取头像，并保存为 `userid`.jpg
import requests
n = 0
j = 0 
for i in userlist:
    print(i['name'], i['mobile'], i['userid'],  i['avatar'])
    if not i.has_key('jobnumber'):
        j+=1
    if not i['avatar'].startswith('https'):
        continue
    n = n+1
    try:
        r = requests.get(i['avatar']) 
        with open('./data/pics/'+i['jobnumber'] + '.jpg','wb') as f:
            f.write(r.content)
    except:
        pass
    
print(j)
print(n)
