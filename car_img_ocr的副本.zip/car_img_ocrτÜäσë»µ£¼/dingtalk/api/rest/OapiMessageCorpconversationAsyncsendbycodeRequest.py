'''
Created by auto_sdk on 2018.07.25
'''
from dingtalk.api.base import RestApi
class OapiMessageCorpconversationAsyncsendbycodeRequest(RestApi):
	def __init__(self,url=None):
		RestApi.__init__(self,url)
		self.agent_id = None
		self.code = None
		self.dept_id_list = None
		self.msgcontent = None
		self.msgtype = None
		self.to_all_user = None
		self.user_id_list = None

	def getHttpMethod(self):
		return 'POST'

	def getapiname(self):
		return 'dingtalk.oapi.message.corpconversation.asyncsendbycode'
