'''
Created by auto_sdk on 2019.01.13
'''
from dingtalk.api.base import RestApi
class OapiDingTaskCreateRequest(RestApi):
	def __init__(self,url=None):
		RestApi.__init__(self,url)
		self.task_send_v_o = None

	def getHttpMethod(self):
		return 'POST'

	def getapiname(self):
		return 'dingtalk.oapi.ding.task.create'
