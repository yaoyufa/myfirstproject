'''
Created by auto_sdk on 2018.07.25
'''
from dingtalk.api.base import RestApi
class CorpConferenceDetailsQueryRequest(RestApi):
	def __init__(self,url=None):
		RestApi.__init__(self,url)
		self.caller_user_id = None
		self.limit = None
		self.member_user_id = None
		self.since_time = None

	def getHttpMethod(self):
		return 'POST'

	def getapiname(self):
		return 'dingtalk.corp.conference.details.query'
