#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Dec 11 10:03:10 2018

@author: lee1984
"""

import numpy as np
import pandas as pd
import requests
import json
import base64
import time
import gc
import sys

start_time = time.time()

img_code = 'odometer'

img_url_df = pd.read_pickle('./data/img_url_df.pkl')
img_zy     = pd.read_pickle('./data/img_zy.pkl')
img_qd     = pd.read_pickle('./data/img_qd.pkl')

id_front_zy = img_zy[img_zy['img_code'] == img_code]
id_front_qd = img_qd[img_qd['img_code'] == img_code]

id_front_zy = id_front_zy.merge(img_url_df, how = 'inner', on = 'img_key')
id_front_qd = id_front_qd.merge(img_url_df, how = 'inner', on = 'img_key')

id_front_total = pd.concat([id_front_zy, id_front_qd])
id_front_total.to_pickle(img_code + '_total.pkl')

del img_url_df, img_zy, img_qd, id_front_zy, id_front_qd, id_front_total
gc.collect()

id_front_total = pd.read_pickle(img_code + '_total.pkl')

id_front_split = np.array_split(id_front_total, id_front_total.shape[0] / 100)
suffix_length = len(str(len(id_front_split)))

split = 0
for s in id_front_split:
    split += 1
    num = 0
    img_base64_dict = {}
    img_base64_dict['img_key'   ] = []
    img_base64_dict['img_base64'] = []
    
    for row in s.itertuples():
        num += 1
        print('split: ' + str(split).zfill(suffix_length) + ', num: ' + str(num))
        img_file = requests.get(row[3], stream = True)
        img_base64 = base64.b64encode(img_file.raw.read())
        
        img_base64_dict['img_key'   ].append(row[2])
        img_base64_dict['img_base64'].append(img_base64)
    
    img_base64_df = pd.DataFrame(img_base64_dict)
    img_base64_df.to_pickle(img_code + '_base64_' + str(split).zfill(suffix_length) + '.pkl')
    
    del img_base64_dict
    gc.collect()

print("- Time consumed: %s seconds" % int(time.time() - start_time))
gc.collect()







