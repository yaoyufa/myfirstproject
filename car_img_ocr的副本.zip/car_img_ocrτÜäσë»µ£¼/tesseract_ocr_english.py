#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jan 28 16:10:45 2019

@author: fan
"""

from PIL import Image
import pytesseract

class Languages:
    CHS = 'chi_sim'
    CHT = 'chi_tra'
    ENG = 'eng'

def img_to_str(image_path, lang=Languages.ENG):
    return pytesseract.image_to_string(Image.open(image_path), lang)

print('\n\n\n\n1. 带数字+英文的仪表盘：\n')
print(img_to_str('./data/odometer1.jpg', lang=Languages.ENG))

print('\n\n\n\n2. 标准背景的英文 字体1：\n')
print(img_to_str('./data/English_test1.jpg', lang=Languages.ENG))

print('\n\n\n\n2. 标准背景的英文 字体2：\n')
print(img_to_str('./data/English_test2.jpg', lang=Languages.ENG))

print('\n\n\n\n3. 标准背景的中文识别：\n')
print(img_to_str('./data/Chinese_test1.jpg', lang=Languages.CHS))


from glob import glob
image_files = glob('./data/*.jpg')

for image_file in sorted(image_files):
    print(image_file, ":\n\n", img_to_str(image_file, lang=Languages.CHS))

