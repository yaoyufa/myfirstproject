#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Nov 28 15:32:40 2018

@author: lee1984
"""

import numpy as np
import pandas as pd
import sqlalchemy
import requests
import multiprocessing
import json
import time
import gc
import sys

start_time = time.time()

query_zy = """
select distinct img_code, img_key
from dwh_stg.stg_i006_ca_app_annex_img
where img_code in ('car_nameplate', 'odometer', 'b_nameplate', 'car_reg_cert', 'dri_permit_cerf', 'gps_car_nameplate', 
                   'wired_gps_num', 'wireless_gps_num', 'id_front', 'id_back', 'b_b_card_front', 'b_card_back', 
                   'in_drive_cert', 'm_id_front', 'm_id_back', 'g_id_front', 'g_id_back', 'mar_license', 'div_license', 
                   'house_cert', 'cat_invoice', 'bo_business_license')
"""

query_qd = """
select distinct img_code, img_key
from dwh_stg.stg_s004_ca_app_annex_img
where img_code in ('car_nameplate', 'odometer', 'b_nameplate', 'car_reg_cert', 'dri_permit_cerf', 'gps_car_nameplate', 
                   'wired_gps_num', 'wireless_gps_num', 'id_front', 'id_back', 'b_b_card_front', 'b_card_back', 
                   'in_drive_cert', 'm_id_front', 'm_id_back', 'g_id_front', 'g_id_back', 'mar_license', 'div_license', 
                   'house_cert', 'cat_invoice', 'bo_business_license')
"""

hive_engine = 'hive://crusader:crusader.MLJR@hlt-data-171.mljr.com:10000/default'

def concurrent_download(query_and_engine_dict):
    start_time = time.time()
    engine = sqlalchemy.create_engine(query_and_engine_dict['connection_string'], connect_args = {'auth': 'LDAP'}) \
        if query_and_engine_dict['connection_string'][:4] == 'hive' else sqlalchemy.create_engine(query_and_engine_dict['connection_string'])
    pd.read_sql(query_and_engine_dict['query'], engine).to_pickle(query_and_engine_dict['save_as'] + '.pkl')
    return '- Download ' + query_and_engine_dict['save_as'] + ' time consumed: %s seconds' % int(time.time() - start_time)

query_list = []
query_list.append({'query': query_zy, 'connection_string': hive_engine, 'save_as': 'img_zy'})
query_list.append({'query': query_qd, 'connection_string': hive_engine, 'save_as': 'img_qd'})

if __name__ == '__main__':
    start_time = time.time()
    
    #%% download data
#    multiprocessing.freeze_support()
#    with multiprocessing.Pool(2) as p:
#        print(p.map(concurrent_download, query_list))
    
    del hive_engine, query_list, query_zy, query_qd
    gc.collect()
    
    print("- Download time: %s seconds" % int(time.time() - start_time))
    
    #%% get unique image keys from both img_zy and img_qd
#    img_zy = pd.read_pickle('img_zy.pkl')
#    img_qd = pd.read_pickle('img_qd.pkl')
#    
#    img_zy['img_key'] = img_zy['img_key'].str.replace(' ', '')
#    img_zy = img_zy[img_zy['img_key'].notnull() & (img_zy['img_key'] != '')]
#    
#    img_qd['img_key'] = img_qd['img_key'].str.replace(' ', '')
#    img_qd = img_qd[img_qd['img_key'].notnull() & (img_qd['img_key'] != '')]
#    
#    unique_img_key = pd.concat([img_zy[['img_key']].drop_duplicates(), img_qd[['img_key']].drop_duplicates()], sort = False)
#    
#    del img_zy, img_qd
#    gc.collect()
#    
#    unique_img_key.drop_duplicates('img_key', inplace = True)
#    unique_img_key.to_pickle('unique_img_key.pkl')
    
    #%% get image url from carrier.mljr.com
    unique_img_key = pd.read_pickle('unique_img_key.pkl')
    
    publicKey_str = 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC61Kw3LHVkQBSl0KhDV9KIK5JpEIE/N1eZeW1JVlNoayDDNYTWcSvywf6HgJRzeP6jr' \
        + 'DsZHvZT5RrzP/JLoQHG1Tt4vvO/eEqWCII/326/NImvmugl/7AkilYTLD+r9kOnIevpGFvt+ZvTNdrwMIau+2shtofXToQOE1ddVVug2wIDAQAB'
    post_url = 'http://carrier.mljr.com/filetransfer/image/url'
    
    img_key_list = list(unique_img_key['img_key'])
    num_uuid = 50
    
    del unique_img_key
    gc.collect()
    
    img_url_dict = {}
    img_url_dict['img_key'] = []
    img_url_dict['img_url'] = []
    
    for i in range(0, len(img_key_list), num_uuid):
        print(str(i))
        uuids = ','.join(img_key_list[i : i + num_uuid])
        post_data = {'uuids': uuids, 'caller': 'carrier-mljr', 'publicKey': publicKey_str}
        response = requests.post(post_url, data = post_data)
        
        json_dict = json.loads(response.text)
        
        if json_dict['errorCode'] == 0:
            for j in json_dict['data'].keys():
                img_url_dict['img_key'].append(j)
                img_url_dict['img_url'].append(json_dict['data'][j])
    
    img_url_df = pd.DataFrame(img_url_dict)
    img_url_df.to_pickle('img_url_df.pkl')
    
    print("- Time consumed: %s seconds" % int(time.time() - start_time))
    gc.collect()





